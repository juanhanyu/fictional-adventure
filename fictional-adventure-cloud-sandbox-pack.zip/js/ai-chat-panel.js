/* =========================================================================
   转生千金 · 原生游戏内 Galgame 角色灵魂交谈抽屉 (Direct Gemini API + Proxy 双模)
   利用 Gemini responseSchema 一次返回 { action, reply, emotion, causal_deltas, memory_echo }
   实时驱动舞台立绘表情切换与 S.causal 命运暗流演化
   ========================================================================= */
(function (root) {
  'use strict';

  var CFG_KEY = 'ojousama_gemini_cfg_v1';
  var CONV_KEY = 'ojousama_native_ai_conv_v1';

  var EMO_LABELS = {
    normal: '平静',
    smile: '浅笑',
    happy: '欣喜',
    shy: '微赧',
    serious: '凝重',
    sad: '黯然',
    surprised: '微怔',
    teary: '含泪',
    wink: '狡黠'
  };

  var activeAbort = null;
  var busy = false;
  var vignetteSession = null;        // 抽屉开启小场景横幅期间的活跃会话
  var pendingVignetteContext = null; // 跨抽屉收起保留至舞台继续按钮消费的累积结果
  var drawerEl = null;

  function mergeSessionOutcome(prev, cur) {
    if (!cur) return prev;
    if (!prev) return Object.assign({}, cur);
    return {
      applied: !!(prev.applied || cur.applied),
      emotion: cur.emotion || prev.emotion || 'normal',
      axisChanged: !!(prev.axisChanged || cur.axisChanged),
      clueUnlocked: !!(prev.clueUnlocked || cur.clueUnlocked),
      echoSaved: !!(prev.echoSaved || cur.echoSaved)
    };
  }

  function currentSceneId() {
    return (typeof currentScene !== 'undefined' && currentScene) || 'free-roam';
  }

  /**
   * 解除小场景对抽屉下拉框与横幅的锁定（关闭抽屉、切换场景、开新档时均会调用）
   */
  function clearVignetteLock(wipePending) {
    vignetteSession = null;
    if (wipePending) pendingVignetteContext = null;
    if (drawerEl) {
      var banner = drawerEl.querySelector('#aid-vignette-banner');
      if (banner) banner.classList.add('hidden');
    }
  }

  function loadConfig() {
    var onLocalServer = (typeof location !== 'undefined' && /^https?:/i.test(location.protocol) && location.port === '8787');
    var defaultProxy = onLocalServer ? '/api/chat' : 'http://localhost:8787/api/chat';
    var base = {
      provider: onLocalServer ? 'codex' : 'openai', // 本机 8787 默认走 chatgpt-2 订阅桥接（零 API Key）
      mode: onLocalServer ? 'proxy' : 'direct',     // 'proxy' | 'direct'
      baseUrl: 'https://api.openai.com/v1',
      apiKey: '',
      proxyUrl: defaultProxy,
      model: 'gpt-4.1'
    };
    try {
      var raw = JSON.parse(localStorage.getItem(CFG_KEY) || '{}');
      if (raw && typeof raw === 'object') return Object.assign(base, raw);
    } catch (e) {}
    return base;
  }

  function saveConfig(cfg) {
    try { localStorage.setItem(CFG_KEY, JSON.stringify(cfg)); } catch (e) {}
  }

  function loadConversations() {
    try {
      var data = JSON.parse(localStorage.getItem(CONV_KEY) || '{}');
      if (data && typeof data === 'object' && !Array.isArray(data)) return data;
    } catch (e) {}
    return {};
  }

  function saveConversations(convs) {
    var entries = Object.entries(convs || {}).slice(-36);
    try { localStorage.setItem(CONV_KEY, JSON.stringify(Object.fromEntries(entries))); } catch (e) {}
  }

  /**
   * 实时采集当前舞台与探索状态快照（安全隔离，不含未来剧本，仅附带安全布尔进度标记）
   */
  function collectLiveSnapshot() {
    var gs = typeof document !== 'undefined' ? document.getElementById('game-screen') : null;
    var playing = !!(gs && !gs.classList.contains('hidden'));
    var st = (typeof S !== 'undefined' && S) ? S : root.S;
    if (!st) return { playing: false, people: [] };

    var curSc = currentSceneId();
    if (vignetteSession && (st.freeRoam || (vignetteSession.sceneAtStart && curSc !== vignetteSession.sceneAtStart))) {
      clearVignetteLock(true);
    } else if (pendingVignetteContext && (st.freeRoam || (pendingVignetteContext.sceneAtStart && curSc !== pendingVignetteContext.sceneAtStart))) {
      pendingVignetteContext = null;
    }

    var stageIds = [];
    if (typeof stage !== 'undefined' && Array.isArray(stage)) {
      stage.forEach(function (p) {
        if (p && p.id && p.id !== 'sylvia' && stageIds.indexOf(p.id) === -1) stageIds.push(p.id);
      });
    }
    if (!stageIds.length && st.freeRoam && typeof whoIsHere === 'function') {
      whoIsHere().forEach(function (id) {
        if (id && id !== 'sylvia' && stageIds.indexOf(id) === -1) stageIds.push(id);
      });
    }
    if (vignetteSession && vignetteSession.charId && stageIds.indexOf(vignetteSession.charId) === -1) {
      stageIds.unshift(vignetteSession.charId);
    }

    var charsDict = (typeof CHARS !== 'undefined' && CHARS) ? CHARS : (root.__CHARS || {});
    var locsDict = (typeof LOCS !== 'undefined' && LOCS) ? LOCS : (root.__LOCS || {});
    var todsArr = (typeof TODS !== 'undefined' && TODS) ? TODS : ['清晨', '上午', '下午', '傍晚', '夜晚'];
    var tiersArr = (typeof TIERS !== 'undefined' && TIERS) ? TIERS : ['无', '初级', '中级', '高级', '圣级', '王级', '帝级', '神级'];

    var people = stageIds.filter(function (id) { return !!charsDict[id]; }).map(function (id) {
      return {
        id: id,
        name: charsDict[id].name,
        short: charsDict[id].short,
        role: charsDict[id].role,
        age: id === 'beatrice' ? st.ageY + 2 : id === 'alice' ? Math.max(0, st.ageY - 2) : null,
        know: (st.know && st.know[id]) || 0,
        love: (st.love && st.love[id]) || 0
      };
    });

    var spkEl = typeof document !== 'undefined' ? document.getElementById('speaker') : null;
    var txtEl = typeof document !== 'undefined' ? document.getElementById('text') : null;
    var rawSpk = spkEl ? String(spkEl.textContent || '').trim() : '';
    var curSpk = (typeof curSpeakerId !== 'undefined' && curSpeakerId && charsDict[curSpeakerId])
      ? charsDict[curSpeakerId].name
      : rawSpk;
    var curTxt = (typeof fullText !== 'undefined' && fullText)
      ? fullText
      : (txtEl ? txtEl.textContent : '');

    var safeFlags = (root.AI_PERSONAS && typeof root.AI_PERSONAS.extractSafeFlags === 'function')
      ? root.AI_PERSONAS.extractSafeFlags(st.flags)
      : {};

    return {
      playing: playing,
      scene: curSc,
      location: (locsDict[st.loc] && locsDict[st.loc].name) || st.loc || '',
      description: (locsDict[st.loc] && locsDict[st.loc].desc) || '',
      phase: st.phase || 'prologue',
      flags: safeFlags,
      player: {
        name: st.alias || st.name || '希尔维亚',
        age: st.ageY || 0,
        year: st.year || 0,
        month: st.month || 3,
        day: st.day || 1,
        time: todsArr[st.tod] || '',
        tier: tiersArr[st.tier] || '无',
        hp: st.hp,
        mp: st.mp,
        stamina: st.st,
        level: st.lv
      },
      speaker: curSpk || '',
      rawSpeaker: rawSpk || '',
      text: String(curTxt || '').slice(0, 2500),
      people: people,
      causal: root.BranchingDirector ? root.BranchingDirector.getCausalSnapshot(st) : undefined
    };
  }

  function convKeyFor(snap, charId) {
    if (!snap || !charId) return '';
    return JSON.stringify([snap.scene, snap.location, snap.player && snap.player.year, snap.player && snap.player.month, charId]);
  }

  /**
   * 解析并净水结构化模型输出
   */
  function parseStructuredModelOutput(rawTextOrObj, charId) {
    var obj = rawTextOrObj;
    if (typeof obj === 'string') {
      var trimmed = obj.trim().replace(/^```json\s*/i, '').replace(/```\s*$/, '').trim();
      obj = JSON.parse(trimmed);
    }
    if (!obj || typeof obj !== 'object') {
      throw new Error('模型响应格式无法解析');
    }
    var Personas = root.AI_PERSONAS;
    var sanitize = (Personas && Personas.sanitizeNarrativeOutput) ? Personas.sanitizeNarrativeOutput : function (s) { return String(s || '').trim(); };
    var normEmo = (Personas && Personas.normalizeEmotion) ? Personas.normalizeEmotion : function (_, e) { return e || 'normal'; };

    var action = sanitize(String(obj.action || '')).slice(0, 300);
    var reply = sanitize(String(obj.reply || '')).slice(0, 800);
    if (!reply) throw new Error('角色未返回有效台词');

    var deltas = (obj.causal_deltas && typeof obj.causal_deltas === 'object') ? obj.causal_deltas : {};
    return {
      action: action,
      reply: reply,
      emotion: normEmo(charId, obj.emotion),
      causal_deltas: {
        axis: String(deltas.axis || 'none').trim(),
        delta: Math.max(0, Math.min(2, Math.round(Number(deltas.delta) || 0))),
        clue: String(deltas.clue || 'none').trim()
      },
      memory_echo: sanitize(String(obj.memory_echo || '')).slice(0, 80)
    };
  }

  /**
   * 发起 Gemini 结构化对话请求（支持 Direct 直连与 Proxy 代理双模）
   */
  async function requestStructuredDialogue(params) {
    var snap = params.snapshot;
    var charId = params.characterId;
    var history = params.history || [];
    var userText = params.text;
    var cfg = params.config || loadConfig();
    var signal = params.signal;
    var fetchImpl = params.fetchImpl || root.fetch.bind(root);

    var Personas = root.AI_PERSONAS;
    if (!Personas) throw new Error('灵魂卡模块尚未加载。');
    if (!snap || !snap.playing) throw new Error('请先开始游戏或继续存档。');
    var person = (snap.people || []).find(function (p) { return p.id === charId; });
    if (!person) throw new Error('当前角色不在场，请先走近角色或切换对象。');
    if (!userText || !String(userText).trim()) throw new Error('请先输入想对角色说的话。');

    if (cfg.mode === 'proxy') {
      var url = String(cfg.proxyUrl || '').trim();
      if (!url) throw new Error('请先填写本地/云端代理服务地址。');
      var headers = { 'Content-Type': 'application/json' };
      if (cfg.apiKey && cfg.apiKey.trim()) {
        headers['X-OpenAI-Api-Key'] = cfg.apiKey.trim();
        headers['X-Gemini-Api-Key'] = cfg.apiKey.trim();
      }
      if (cfg.baseUrl && cfg.baseUrl.trim()) {
        headers['X-OpenAI-Base-Url'] = cfg.baseUrl.trim();
      }
      var resp = await fetchImpl(url, {
        method: 'POST',
        headers: headers,
        signal: signal,
        body: JSON.stringify({
          provider: cfg.provider || 'openai',
          baseUrl: String(cfg.baseUrl || '').trim(),
          snapshot: snap,
          characterId: charId,
          history: history.slice(-12),
          text: String(userText).trim().slice(0, 2000),
          causal: snap.causal,
          model: cfg.model || 'gpt-4.1'
        })
      });
      var respJson = await resp.json().catch(function () { return {}; });
      if (!resp.ok) {
        throw new Error(respJson.error || '代理请求失败，请确认本地代理服务已启动。');
      }
      return parseStructuredModelOutput(respJson, charId);
    }

    var key = String(cfg.apiKey || '').trim();
    if (!key) {
      throw new Error('请先在面板「API 连接设置」填入您的 GPT / OpenAI API Key，或切换为本地代理模式。');
    }
    var model = String(cfg.model || 'gpt-4.1').trim();
    var isCustomRelay = !!(cfg.baseUrl && !/api\.openai\.com/i.test(cfg.baseUrl));
    var useLegacyGemini = (cfg.provider === 'gemini') || (/^gemini/i.test(model) && !isCustomRelay);
    var sysText = Personas.buildPersonaSystemPrompt(charId, snap, snap.causal);
    var activeHint = vignetteSession ? vignetteSession.hint : (pendingVignetteContext ? pendingVignetteContext.hint : undefined);
    var sceneContextObj = {
      scene: snap.scene,
      location: snap.location,
      description: snap.description,
      phase: snap.phase,
      flags: snap.flags,
      player: snap.player,
      people: snap.people,
      speaker: snap.speaker,
      text: snap.text,
      causal: snap.causal,
      vignetteHint: activeHint,
      target: person
    };

    if (!useLegacyGemini) {
      // 主通道：直连 GPT / OpenAI 兼容 Chat Completions API（支持官方 OpenAI 及任意兼容中转站）
      var baseUrl = String(cfg.baseUrl || 'https://api.openai.com/v1').trim().replace(/\/+$/, '');
      var openaiUrl = /\/chat\/completions$/i.test(baseUrl) ? baseUrl : (baseUrl + '/chat/completions');
      var jsonContract = '\n\n【严格 JSON 输出格式】仅输出一个合法 JSON 对象，字段必须包含：' +
        '{"action":"简洁舞台神态动作","reply":"角色台词（贴合原著口吻、不出现禁词）","emotion":"normal|smile|happy|shy|serious|sad|surprised|teary|wink",' +
        '"causal_deltas":{"axis":"none或有效因果轴键","delta":0,"clue":"none或有效线索键"},"memory_echo":"20字以内留白回声或空字符串"}。';
      var messages = [
        { role: 'system', content: sysText + jsonContract },
        { role: 'user', content: '当前游戏场景资料：\n' + JSON.stringify(sceneContextObj) + '\n请严格按上述 JSON 格式回应。' },
        {
          role: 'assistant',
          content: JSON.stringify({
            action: person.name + '在原地停下动作，抬眼望了过来。',
            reply: '……嗯。',
            emotion: 'normal',
            causal_deltas: { axis: 'none', delta: 0, clue: 'none' },
            memory_echo: ''
          })
        }
      ];
      history.slice(-12).forEach(function (turn) {
        messages.push({
          role: turn.role === 'assistant' ? 'assistant' : 'user',
          content: turn.structured ? JSON.stringify(turn.structured) : String(turn.content || '').slice(0, 3000)
        });
      });
      messages.push({ role: 'user', content: String(userText).trim().slice(0, 2000) });

      var gptResp = await fetchImpl(openaiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ' + key
        },
        signal: signal,
        body: JSON.stringify({
          model: model,
          messages: messages,
          temperature: 0.72,
          max_tokens: 768,
          response_format: { type: 'json_object' }
        })
      });
      if (!gptResp.ok) {
        throw new Error(gptResp.status === 429
          ? 'GPT API 调用频率或额度受限，请稍后再试。'
          : '直连 GPT API 失败（HTTP ' + gptResp.status + '），请检查 API Key、Base URL 与模型名。');
      }
      var gptData = await gptResp.json();
      var gptText = (((gptData.choices || [])[0] || {}).message || {}).content || '';
      return parseStructuredModelOutput(gptText, charId);
    }

    // 兼容旧配置：显式指定 gemini 时保留回退支持
    var contents = [
      {
        role: 'user',
        parts: [{ text: '当前游戏场景资料：\n' + JSON.stringify(sceneContextObj) + '\n请严格按 JSON Schema 返回物理动作、角色台词、舞台表情与因果微澜。' }]
      },
      {
        role: 'model',
        parts: [{ text: JSON.stringify({
          action: person.name + '在原地停下动作，抬眼望了过来。',
          reply: '……嗯。',
          emotion: 'normal',
          causal_deltas: { axis: 'none', delta: 0, clue: 'none' },
          memory_echo: ''
        }) }]
      }
    ];

    history.slice(-12).forEach(function (turn) {
      contents.push({
        role: turn.role === 'assistant' ? 'model' : 'user',
        parts: [{ text: turn.structured ? JSON.stringify(turn.structured) : String(turn.content || '').slice(0, 3000) }]
      });
    });
    contents.push({
      role: 'user',
      parts: [{ text: String(userText).trim().slice(0, 2000) }]
    });

    var endpoint = 'https://generativelanguage.googleapis.com/v1beta/models/' + encodeURIComponent(model) + ':generateContent';
    var directResp = await fetchImpl(endpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-goog-api-key': key
      },
      signal: signal,
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: sysText }] },
        contents: contents,
        generationConfig: {
          temperature: 0.72,
          maxOutputTokens: 768,
          responseMimeType: 'application/json',
          responseSchema: Personas.RESPONSE_SCHEMA
        }
      })
    });

    if (!directResp.ok) {
      throw new Error(directResp.status === 429
        ? 'API 调用频率或额度已达上限，请稍后再试。'
        : '直连 API 失败（HTTP ' + directResp.status + '），请检查 API Key 是否有效。');
    }
    var directData = await directResp.json();
    var rawText = (((directData.candidates || [])[0] || {}).content || {}).parts
      ? directData.candidates[0].content.parts.map(function (p) { return p.text || ''; }).join('')
      : '';
    return parseStructuredModelOutput(rawText, charId);
  }

  // =========================================================================
  // UI 构建与实时交互绑定
  // =========================================================================

  var SVG_CAUSAL_ICON =
    '<svg viewBox="0 0 20 20" width="17" height="17" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' +
      '<circle cx="10" cy="10" r="6.8"/>' +
      '<ellipse cx="10" cy="10" rx="6.8" ry="2.6" transform="rotate(-24 10 10)"/>' +
      '<circle cx="10" cy="10" r="1.4" fill="currentColor" stroke="none"/>' +
    '</svg>';

  var SVG_SPARK_ICON =
    '<svg viewBox="0 0 20 20" width="17" height="17" fill="none" stroke="currentColor" stroke-width="1.55" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' +
      '<path d="M10 2.5L11.9 8.1L17.5 10L11.9 11.9L10 17.5L8.1 11.9L2.5 10L8.1 8.1Z"/>' +
    '</svg>';

  var SVG_GEAR_ICON =
    '<svg viewBox="0 0 20 20" width="15" height="15" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' +
      '<circle cx="10" cy="10" r="2.8"/>' +
      '<path d="M10 3.2v1.6M10 15.2v1.6M3.2 10h1.6M15.2 10h1.6M5.2 5.2l1.1 1.1M13.7 13.7l1.1 1.1M14.8 5.2l-1.1 1.1M6.3 13.7l-1.1 1.1"/>' +
    '</svg>';

  var SVG_SIGIL_CREST =
    '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' +
      '<polygon points="12,2.5 20,12 12,21.5 4,12"/>' +
      '<circle cx="12" cy="12" r="3.4"/>' +
      '<path d="M12 5.5v3M12 15.5v3M5.5 12h3M15.5 12h3"/>' +
    '</svg>';

  function ensureHUDButtons() {
    if (typeof document === 'undefined') return;
    var hudRight = document.querySelector('#hud .hud-right');
    if (!hudRight) return;

    if (!document.getElementById('btn-causal-quick')) {
      var btnCausal = document.createElement('button');
      btnCausal.id = 'btn-causal-quick';
      btnCausal.className = 'chip chip-causal';
      btnCausal.title = '命运暗流星盘';
      btnCausal.setAttribute('aria-label', '命运暗流星盘');
      btnCausal.innerHTML = SVG_CAUSAL_ICON;
      btnCausal.onclick = function () {
        if (typeof openPanel === 'function') openPanel('causal');
      };
      hudRight.insertBefore(btnCausal, hudRight.firstChild);
    }

    if (!document.getElementById('btn-ai-drawer')) {
      var btnAi = document.createElement('button');
      btnAi.id = 'btn-ai-drawer';
      btnAi.className = 'chip chip-ai';
      btnAi.title = '灵魂交谈 · 自由对话';
      btnAi.setAttribute('aria-label', '灵魂交谈');
      btnAi.innerHTML = SVG_SPARK_ICON;
      btnAi.onclick = function () {
        toggleDrawer();
      };
      hudRight.insertBefore(btnAi, hudRight.firstChild);
    }
  }

  /**
   * 统一收束当前小场景自由对话（抽屉金色按钮与舞台继续按钮共用，保留已产生的因果倾向）
   */
  function finishActiveVignette() {
    var ctx = vignetteSession || pendingVignetteContext;
    clearVignetteLock(true);
    if (drawerEl) {
      drawerEl.classList.add('hidden');
      if (typeof document !== 'undefined' && document.body) {
        document.body.classList.remove('ai-drawer-open');
      }
      refreshBadge();
    }
    if (typeof document !== 'undefined') {
      var chBox = document.getElementById('choices');
      if (chBox) chBox.innerHTML = '';
    }
    if (typeof awaitingChoice !== 'undefined') awaitingChoice = false;
    if (ctx && typeof ctx.onComplete === 'function') {
      ctx.onComplete(ctx.lastOutcome || null);
      return true;
    }
    return false;
  }

  function ensureDrawerDOM() {
    if (typeof document === 'undefined') return null;
    if (drawerEl) return drawerEl;
    var app = document.getElementById('app') || document.body;
    if (!app) return null;

    var cfg = loadConfig();
    var aside = document.createElement('aside');
    aside.id = 'ai-drawer';
    aside.className = 'ai-drawer hidden';
    aside.setAttribute('aria-label', '角色灵魂交谈抽屉');
    aside.innerHTML =
      '<div class="aid-head">' +
        '<div class="aid-title-wrap">' +
          '<span class="aid-spark">' + SVG_SPARK_ICON + '</span>' +
          '<div><h3 class="aid-title">灵魂交谈</h3><p class="aid-sub" id="aid-gate-tag">等待角色登场</p></div>' +
        '</div>' +
        '<div class="aid-head-btns">' +
          '<button type="button" id="aid-btn-cfg" class="aid-icon-btn" title="API 连接设置" aria-label="API 连接设置">' + SVG_GEAR_ICON + '</button>' +
          '<button type="button" id="aid-btn-close" class="aid-icon-btn" title="收起抽屉" aria-label="收起抽屉">×</button>' +
        '</div>' +
      '</div>' +
      '<div id="aid-cfg-box" class="aid-cfg hidden">' +
        '<div class="aid-cfg-row">' +
          '<label>连接方式</label>' +
          '<select id="aid-mode">' +
            '<option value="codex"' + (cfg.mode === 'proxy' && cfg.provider === 'codex' ? ' selected' : '') + '>本机 chatgpt-2 订阅桥接（免 API Key · 推荐）</option>' +
            '<option value="direct"' + (cfg.mode === 'direct' ? ' selected' : '') + '>浏览器直连 GPT / OpenAI 兼容 API</option>' +
            '<option value="proxy"' + (cfg.mode === 'proxy' && cfg.provider !== 'codex' ? ' selected' : '') + '>连接本地/云端 OpenAI 代理</option>' +
          '</select>' +
        '</div>' +
        '<div class="aid-cfg-row" id="aid-baseurl-row">' +
          '<label>GPT API Base URL <small>（支持官方或任意 OpenAI 兼容中转站）</small></label>' +
          '<input type="text" id="aid-baseurl" placeholder="https://api.openai.com/v1"/>' +
        '</div>' +
        '<div class="aid-cfg-row" id="aid-key-row">' +
          '<label>GPT / OpenAI API Key <small>（仅存本机浏览器）</small></label>' +
          '<input type="password" id="aid-apikey" placeholder="粘贴 sk-... 密钥" autocomplete="off"/>' +
        '</div>' +
        '<div class="aid-cfg-row" id="aid-proxy-row">' +
          '<label>Proxy 端点地址</label>' +
          '<input type="text" id="aid-proxy" placeholder="http://localhost:8787/api/chat"/>' +
        '</div>' +
        '<div class="aid-cfg-row">' +
          '<label>GPT 模型名 <small>（可直接输入任意兼容模型）</small></label>' +
          '<input type="text" id="aid-model" list="aid-model-list" placeholder="gpt-4.1"/>' +
          '<datalist id="aid-model-list">' +
            '<option value="gpt-5"></option>' +
            '<option value="gpt-4.1"></option>' +
            '<option value="gpt-4o"></option>' +
            '<option value="gpt-5-mini"></option>' +
          '</datalist>' +
        '</div>' +
        '<div class="aid-cfg-foot">' +
          '<button type="button" id="aid-cfg-save" class="aid-btn primary">保存配置</button>' +
        '</div>' +
      '</div>' +
      '<div class="aid-target-bar">' +
        '<div class="aid-sigil-badge" id="aid-sigil-badge" aria-hidden="true">' + SVG_SIGIL_CREST + '</div>' +
        '<img id="aid-avatar" class="aid-avatar" alt=""/>' +
        '<div class="aid-target-meta">' +
          '<select id="aid-target" aria-label="选择在场对话角色"></select>' +
          '<div id="aid-axis-mini" class="aid-axis-mini"></div>' +
        '</div>' +
      '</div>' +
      '<div id="aid-vignette-banner" class="aid-vignette-banner hidden">' +
        '<span id="aid-vignette-text"></span>' +
        '<button type="button" id="aid-vignette-finish" class="aid-btn gold">织入命运并继续剧情 ▸</button>' +
      '</div>' +
      '<div id="aid-log" class="aid-log" role="log" aria-live="polite"></div>' +
      '<div id="aid-status" class="aid-status">就绪 · 结构化表情与命运暗流实时联动</div>' +
      '<div class="aid-compose">' +
        '<textarea id="aid-input" maxlength="2000" rows="2" placeholder="对眼前的角色说点什么……（Ctrl + Enter 发送）"></textarea>' +
        '<div class="aid-actions">' +
          '<button type="button" id="aid-send" class="aid-btn primary">发送</button>' +
          '<button type="button" id="aid-cancel" class="aid-btn hidden">取消</button>' +
          '<button type="button" id="aid-clear" class="aid-btn ghost">清空</button>' +
        '</div>' +
      '</div>';

    app.appendChild(aside);
    drawerEl = aside;

    // 初始化表单值
    aside.querySelector('#aid-baseurl').value = cfg.baseUrl || 'https://api.openai.com/v1';
    aside.querySelector('#aid-apikey').value = cfg.apiKey || '';
    aside.querySelector('#aid-proxy').value = cfg.proxyUrl || '';
    aside.querySelector('#aid-model').value = cfg.model || 'gpt-4.1';
    syncCfgRows();

    // 绑定事件
    aside.querySelector('#aid-btn-close').onclick = function () { closeDrawer(); };
    aside.querySelector('#aid-btn-cfg').onclick = function () {
      aside.querySelector('#aid-cfg-box').classList.toggle('hidden');
    };
    aside.querySelector('#aid-mode').onchange = syncCfgRows;
    aside.querySelector('#aid-cfg-save').onclick = function () {
      var selMode = aside.querySelector('#aid-mode').value;
      var nextCfg = {
        provider: selMode === 'codex' ? 'codex' : 'openai',
        mode: selMode === 'direct' ? 'direct' : 'proxy',
        baseUrl: aside.querySelector('#aid-baseurl').value.trim() || 'https://api.openai.com/v1',
        apiKey: aside.querySelector('#aid-apikey').value.trim(),
        proxyUrl: aside.querySelector('#aid-proxy').value.trim() || '/api/chat',
        model: aside.querySelector('#aid-model').value.trim() || 'gpt-4.1'
      };
      saveConfig(nextCfg);
      aside.querySelector('#aid-cfg-box').classList.add('hidden');
      setStatus(selMode === 'codex'
        ? '已切换为本机 chatgpt-2 订阅桥接（免 API Key）'
        : '已保存 GPT 连接配置（' + (nextCfg.mode === 'proxy' ? '代理模式' : '直连模式') + ' · ' + nextCfg.model + '）');
    };
    aside.querySelector('#aid-target').onchange = function () {
      refreshBadge();
      renderTranscript();
    };
    aside.querySelector('#aid-send').onclick = function () { handleSend(); };
    aside.querySelector('#aid-cancel').onclick = function () {
      if (activeAbort) activeAbort.abort();
    };
    aside.querySelector('#aid-clear').onclick = function () {
      var snap = collectLiveSnapshot();
      var cid = aside.querySelector('#aid-target').value;
      var convs = loadConversations();
      delete convs[convKeyFor(snap, cid)];
      saveConversations(convs);
      renderTranscript();
      setStatus('已清空当前场景交谈记录');
    };
    aside.querySelector('#aid-vignette-finish').onclick = function () {
      finishActiveVignette();
    };
    // 抽屉容器级键盘隔离：阻止所有输入/选择控件按键穿透到底层游戏快捷键，并支持 Escape 关闭抽屉
    aside.addEventListener('keydown', function (ev) {
      if (ev.key === 'Escape') {
        ev.stopPropagation();
        ev.preventDefault();
        closeDrawer({ wipePending: true });
        return;
      }
      ev.stopPropagation();
    });
    var inputEl = aside.querySelector('#aid-input');
    inputEl.addEventListener('keydown', function (ev) {
      if (ev.key === 'Escape') return;
      ev.stopPropagation();
      if (ev.ctrlKey && ev.key === 'Enter' && !ev.isComposing) {
        ev.preventDefault();
        handleSend();
      }
    });

    // 开始新游戏时重置对话缓存与小场景锁定状态
    var btnNew = document.getElementById('btn-new');
    if (btnNew && !btnNew.__aidBound) {
      btnNew.__aidBound = true;
      btnNew.addEventListener('click', function () {
        clearVignetteLock(true);
        saveConversations({});
        if (drawerEl) {
          refreshBadge();
          renderTranscript();
        }
      });
    }

    return drawerEl;
  }

  function syncCfgRows() {
    if (!drawerEl) return;
    var mode = drawerEl.querySelector('#aid-mode').value;
    drawerEl.querySelector('#aid-proxy-row').classList.toggle('hidden', mode === 'direct');
    drawerEl.querySelector('#aid-baseurl-row').classList.toggle('hidden', mode === 'codex');
    drawerEl.querySelector('#aid-key-row').classList.toggle('hidden', mode === 'codex');
  }

  function setStatus(msg) {
    if (!drawerEl) return;
    var el = drawerEl.querySelector('#aid-status');
    if (el) el.textContent = msg;
  }

  function isMysterySpeakerRaw(raw) {
    var s = String(raw || '').trim();
    return s === '？？？' || s === '???' || /^？+$/.test(s) || /^\?+$/.test(s);
  }

  function isIdentityHidden(charId, snap, st) {
    if (!charId) return false;
    var stateObj = st || ((typeof S !== 'undefined' && S) ? S : root.S);
    var flags = (stateObj && stateObj.flags) || (snap && snap.flags) || {};
    var age = snap && snap.player ? snap.player.age : (stateObj ? (stateObj.ageY || 0) : 0);
    var spkMystery = snap ? (isMysterySpeakerRaw(snap.rawSpeaker) || isMysterySpeakerRaw(snap.speaker)) : false;
    // 婴儿期（0岁尚未取名）或当前台词仍处于「？？？」盲声期：严禁剧透全名与家族身份
    if (!flags.named && age === 0 && (charId === 'sophia' || charId === 'claude')) return true;
    if (spkMystery && typeof curSpeakerId !== 'undefined' && curSpeakerId === charId) return true;
    if (spkMystery && stateObj && !flags.named && (charId === 'sophia' || charId === 'claude')) return true;
    var knowVal = (stateObj && stateObj.know && stateObj.know[charId]) || 0;
    if (spkMystery && knowVal <= 0) return true;
    return false;
  }

  function maskedPersonLabel(charId) {
    if (charId === 'sophia') return '温柔的陌生声音（???）';
    if (charId === 'claude') return '低沉的陌生声音（???）';
    return '陌生声音（???）';
  }

  function maskedPersonShort(charId) {
    if (charId === 'sophia') return '温柔的声音（???）';
    if (charId === 'claude') return '低沉的声音（???）';
    return '？？？';
  }

  function refreshBadge() {
    if (!drawerEl) return;
    var snap = collectLiveSnapshot();
    var st = (typeof S !== 'undefined' && S) ? S : root.S;
    var sel = drawerEl.querySelector('#aid-target');
    var prev = sel.value;
    sel.innerHTML = '';
    (snap.people || []).forEach(function (p) {
      var opt = document.createElement('option');
      opt.value = p.id;
      opt.textContent = isIdentityHidden(p.id, snap, st)
        ? maskedPersonLabel(p.id)
        : (p.name + (p.role ? ' · ' + p.role : ''));
      sel.appendChild(opt);
    });
    if (vignetteSession && vignetteSession.charId && Array.from(sel.options).some(function (o) { return o.value === vignetteSession.charId; })) {
      sel.value = vignetteSession.charId;
    } else if (Array.from(sel.options).some(function (o) { return o.value === prev; })) {
      sel.value = prev;
    }
    if (!sel.options.length) {
      var emptyOpt = document.createElement('option');
      emptyOpt.value = '';
      emptyOpt.textContent = '当前场景暂无可交谈人物';
      sel.appendChild(emptyOpt);
    }

    var cid = sel.value;
    var avatar = drawerEl.querySelector('#aid-avatar');
    var gateTag = drawerEl.querySelector('#aid-gate-tag');
    var axisMini = drawerEl.querySelector('#aid-axis-mini');
    var hiddenId = cid && isIdentityHidden(cid, snap, st);

    if (avatar) {
      if (cid && !hiddenId && typeof resolvePortrait === 'function') {
        var src = resolvePortrait(cid, 'normal');
        avatar.src = src || '';
      } else {
        avatar.removeAttribute('src');
      }
      avatar.style.display = 'none';
    }

    if (hiddenId) {
      gateTag.textContent = '时间锁：初生盲听 · 尚未识名';
    } else if (cid && root.AI_PERSONAS) {
      var gate = root.AI_PERSONAS.getTemporalGate(cid, snap, snap.causal);
      gateTag.textContent = gate.isChenglanDisguise && (cid === 'jilan' || cid === 'ji')
        ? '认知锁：澄岚 · 仅识「渔」'
        : '时间锁：' + snap.player.age + '岁 · ' + (snap.location || '当前场景');
    } else {
      gateTag.textContent = snap.playing ? (snap.location + ' · 等待角色登场') : '请先进入游戏场景';
    }

    if (hiddenId) {
      axisMini.innerHTML = '<span style="opacity:.72">✧ 声线尚浅 · 身份未明</span>';
    } else if (cid && root.BranchingDirector) {
      var summary = root.BranchingDirector.getAxisSummary(cid);
      if (summary) {
        axisMini.innerHTML = '<span>' + summary.leftLabel + ' <b>' + summary.leftVal + '</b></span>' +
          '<i class="aid-mini-bar"><b style="left:' + summary.ratio + '%"></b></i>' +
          '<span><b>' + summary.rightVal + '</b> ' + summary.rightLabel + '</span>';
      } else {
        axisMini.innerHTML = '<span style="opacity:.72">✧ 专属灵魂卡已装载</span>';
      }
    } else {
      axisMini.innerHTML = '';
    }

    var bannerEl = drawerEl.querySelector('#aid-vignette-banner');
    if (bannerEl) bannerEl.classList.toggle('hidden', !vignetteSession);

    drawerEl.querySelector('#aid-send').disabled = busy || !snap.playing || !cid;
    sel.disabled = busy || !snap.people.length || !!vignetteSession;
    drawerEl.querySelector('#aid-input').disabled = busy;
    drawerEl.querySelector('#aid-cancel').classList.toggle('hidden', !busy);
  }

  function renderTranscript() {
    if (!drawerEl) return;
    var log = drawerEl.querySelector('#aid-log');
    log.innerHTML = '';
    var snap = collectLiveSnapshot();
    var cid = drawerEl.querySelector('#aid-target').value;
    var convs = loadConversations();
    var turns = convs[convKeyFor(snap, cid)] || [];

    if (!turns.length) {
      var hint = document.createElement('div');
      hint.className = 'aid-empty';
      hint.textContent = cid
        ? '已同步角色灵魂卡与当前场景。输入话语即可展开贴合人设的自由互动，角色神态与命运暗流将实时响应。'
        : '当场景中有其他角色登场时，可在此展开自由对话。';
      log.appendChild(hint);
      return;
    }

    turns.forEach(function (t) {
      var item = document.createElement('div');
      item.className = 'aid-turn ' + (t.role === 'user' ? 'is-user' : 'is-ai');

      var head = document.createElement('div');
      head.className = 'aid-turn-head';
      var speakerStrong = document.createElement('strong');
      var stObj = (typeof S !== 'undefined' && S) ? S : root.S;
      var aiLabel = (cid && isIdentityHidden(cid, snap, stObj)) ? maskedPersonShort(cid) : (t.name || '角色');
      speakerStrong.textContent = t.role === 'user' ? (snap.player.name || '希尔维亚') : aiLabel;
      head.appendChild(speakerStrong);

      if (t.structured && t.structured.emotion) {
        var emoBadge = document.createElement('span');
        emoBadge.className = 'aid-emo-tag';
        emoBadge.textContent = EMO_LABELS[t.structured.emotion] || t.structured.emotion;
        head.appendChild(emoBadge);
      }
      item.appendChild(head);

      if (t.structured && t.structured.action) {
        var actP = document.createElement('p');
        actP.className = 'aid-turn-action';
        actP.textContent = t.structured.action;
        item.appendChild(actP);
      }

      var bodyP = document.createElement('p');
      bodyP.className = 'aid-turn-reply';
      bodyP.textContent = t.structured ? t.structured.reply : t.content;
      item.appendChild(bodyP);

      if (t.causalNote) {
        var cNote = document.createElement('div');
        cNote.className = 'aid-turn-causal';
        cNote.textContent = t.causalNote;
        item.appendChild(cNote);
      }

      log.appendChild(item);
    });
    log.scrollTop = log.scrollHeight;
  }

  async function handleSend() {
    if (busy || !drawerEl) return;
    var inputEl = drawerEl.querySelector('#aid-input');
    var text = inputEl.value.trim();
    if (!text) return;

    var snap = collectLiveSnapshot();
    var cid = drawerEl.querySelector('#aid-target').value;
    if (!cid) return;

    var cfg = loadConfig();
    if (cfg.mode === 'direct' && !cfg.apiKey) {
      drawerEl.querySelector('#aid-cfg-box').classList.remove('hidden');
      setStatus('请先填入 Gemini API Key，或切换为代理模式后再发送。');
      return;
    }

    busy = true;
    activeAbort = typeof AbortController !== 'undefined' ? new AbortController() : null;
    refreshBadge();
    setStatus('角色正在思索与回应……');

    try {
      var cKey = convKeyFor(snap, cid);
      var convs = loadConversations();
      var prevTurns = Array.isArray(convs[cKey]) ? convs[cKey] : [];
      var structured = await requestStructuredDialogue({
        snapshot: snap,
        characterId: cid,
        history: prevTurns,
        text: text,
        config: cfg,
        signal: activeAbort ? activeAbort.signal : undefined
      });

      var person = (snap.people || []).find(function (p) { return p.id === cid; }) || { name: cid };
      var outcomeRes = root.BranchingDirector
        ? root.BranchingDirector.applyAIOutcome(cid, structured)
        : { emotion: structured.emotion };

      if (vignetteSession && vignetteSession.charId === cid) {
        vignetteSession.lastOutcome = mergeSessionOutcome(vignetteSession.lastOutcome, outcomeRes);
      }
      if (pendingVignetteContext && pendingVignetteContext.charId === cid) {
        pendingVignetteContext.lastOutcome = mergeSessionOutcome(pendingVignetteContext.lastOutcome, outcomeRes);
      }

      // 更新抽屉头像为最新表情
      var avatar = drawerEl.querySelector('#aid-avatar');
      if (avatar && typeof resolvePortrait === 'function') {
        var newSrc = resolvePortrait(cid, structured.emotion);
        if (newSrc) avatar.src = newSrc;
      }

      var notes = [];
      if (outcomeRes && outcomeRes.axisChanged && structured.causal_deltas && structured.causal_deltas.axis !== 'none') {
        notes.push('✦ 命运倾向变动：' + structured.causal_deltas.axis + ' +' + structured.causal_deltas.delta);
      }
      if (outcomeRes && outcomeRes.clueUnlocked) {
        notes.push('✦ 点亮关键暗线拼图');
      }
      if (outcomeRes && outcomeRes.echoSaved) {
        notes.push('✦ 往昔回声已铭刻');
      }

      var stNow = (typeof S !== 'undefined' && S) ? S : root.S;
      var saveName = isIdentityHidden(cid, snap, stNow) ? maskedPersonShort(cid) : (person.short || person.name);

      convs[cKey] = prevTurns.concat([
        { role: 'user', content: text },
        {
          role: 'assistant',
          name: saveName,
          content: (structured.action ? structured.action + ' ' : '') + structured.reply,
          structured: structured,
          causalNote: notes.join(' · ')
        }
      ]).slice(-24);
      saveConversations(convs);

      inputEl.value = '';
      renderTranscript();
      setStatus('已回应 · 舞台神态已切至「' + (EMO_LABELS[structured.emotion] || structured.emotion) + '」');
    } catch (err) {
      if (err && err.name === 'AbortError') {
        setStatus('已取消发送 · 输入文字已保留');
      } else {
        setStatus((err && err.message) ? err.message : '请求失败，请检查网络连接或 API Key。输入已保留。');
      }
    } finally {
      busy = false;
      activeAbort = null;
      refreshBadge();
    }
  }

  function openDrawer(preferCharId) {
    ensureHUDButtons();
    var el = ensureDrawerDOM();
    if (!el) return;
    el.classList.remove('hidden');
    if (typeof document !== 'undefined' && document.body) {
      document.body.classList.add('ai-drawer-open');
    }
    refreshBadge();
    if (preferCharId) {
      var sel = el.querySelector('#aid-target');
      if (Array.from(sel.options).some(function (o) { return o.value === preferCharId; })) {
        sel.value = preferCharId;
        refreshBadge();
      }
    }
    renderTranscript();
  }

  function closeDrawer(opts) {
    var options = opts || {};
    clearVignetteLock(!!options.wipePending);
    if (typeof document !== 'undefined' && document.body) {
      document.body.classList.remove('ai-drawer-open');
    }
    if (!drawerEl) return;
    drawerEl.classList.add('hidden');
    refreshBadge();
  }

  function toggleDrawer() {
    var el = ensureDrawerDOM();
    if (!el) return;
    if (el.classList.contains('hidden')) openDrawer();
    else closeDrawer();
  }

  /**
   * 供小场景「灵魂交谈」分支调用：打开抽屉并绑定收束剧情按钮
   */
  function openForVignette(opts) {
    var curSc = currentSceneId();
    var sessObj = {
      vignetteId: opts.vignetteId,
      charId: opts.charId,
      hint: opts.hint || '',
      onComplete: opts.onComplete,
      lastOutcome: null,
      sceneAtStart: curSc
    };
    vignetteSession = sessObj;
    pendingVignetteContext = sessObj;
    openDrawer(opts.charId);
    if (drawerEl) {
      var banner = drawerEl.querySelector('#aid-vignette-banner');
      var txt = drawerEl.querySelector('#aid-vignette-text');
      txt.textContent = '小场景自由推进中：可与角色多聊几轮，随后点击下方按钮织入剧情';
      banner.classList.remove('hidden');
      drawerEl.querySelector('#aid-input').focus();
    }
  }

  function init() {
    ensureHUDButtons();
    ensureDrawerDOM();
  }

  var API = {
    init: init,
    openDrawer: openDrawer,
    closeDrawer: closeDrawer,
    toggleDrawer: toggleDrawer,
    openForVignette: openForVignette,
    finishActiveVignette: finishActiveVignette,
    clearVignetteLock: clearVignetteLock,
    refreshBadge: refreshBadge,
    collectLiveSnapshot: collectLiveSnapshot,
    parseStructuredModelOutput: parseStructuredModelOutput,
    requestStructuredDialogue: requestStructuredDialogue,
    loadConfig: loadConfig,
    saveConfig: saveConfig
  };

  root.AIChatPanel = API;
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = API;
  }

  if (typeof document !== 'undefined') {
    init();
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', init);
    }
  }
})(typeof globalThis !== 'undefined' ? globalThis : (typeof window !== 'undefined' ? window : this));
