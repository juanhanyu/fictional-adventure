/* =========================================================
   转生千金 · 原著向策略智斗引擎 (js/combat-engine.js)
   核心闭环：双轨施法路径 × 动态反应架势AI × 100%原著魔战循环 × 冰晶宫殿两步推演 × 晦轮杖折光与暴露风险
   ========================================================= */
(function (global) {
  'use strict';

  const ARENA_SAVE_KEY = 'ojousama_arena_records_v1';

  const ELEM_LABEL = {
    ice: '冰系',
    water: '水系',
    fire: '火系',
    wind: '风系',
    earth: '土系',
    dark: '暗系',
    light: '光系',
    phys: '剑术',
  };

  const ELEM_COUNTER = {
    water: 'fire',
    fire: 'ice',
    ice: 'wind',
    wind: 'earth',
    earth: 'water',
    light: 'dark',
    dark: 'light',
  };

  function getElemMult(atkElem, defElem) {
    if (!atkElem || !defElem || atkElem === 'phys' || defElem === 'phys') return 1.0;
    if (ELEM_COUNTER[atkElem] === defElem) return 1.5;
    if (ELEM_COUNTER[defElem] === atkElem) return 0.75;
    return 1.0;
  }

  const PATH_META = {
    HAND: { tag: '【经手构筑】', short: '经手构筑', desc: '稳固无气泡、正面高倍率与厚重防线，但具标准施法前摇' },
    REMOTE: { tag: '【隔空瞬凝】', short: '隔空瞬凝', desc: '零前摇于敌身侧生成！唯命中【双手控场】触发截断破招，盲丢严密防反仅30%威力且易遭反制' },
    SWORD: { tag: '【霁馆剑步】', short: '霁馆剑步', desc: '沉身卸力专克【贴身突袭】，享体能与物攻加成，且不产生冰系外显暴露波动' },
    INSIGHT: { tag: '【看破专武】', short: '冰宫看破', desc: '经由冰晶宫殿两步微推理锁定敌方死角后解锁的单次针对性绝杀' },
  };

  const STANCE_META = {
    DUAL_CAST: {
      badge: '双手控场 · 侧翼真空',
      hint: '宜用「隔空瞬凝」零前摇突袭 → 触发截断破招',
    },
    CLOSE_LUNGE: {
      badge: '贴身突袭 · 高速扑杀',
      hint: '宜用「霁馆剑步 / 残像」 → 触发卸力闪反',
    },
    HEAVY_WINDUP: {
      badge: '蓄力重击 · 重心前压',
      hint: '宜立盾稳固防线，或以冰宫看破掀翻重心',
    },
    GUARD_COUNTER: {
      badge: '严密防反 · 零留白守势',
      hint: '忌盲丢隔空瞬凝，宜用「经手构筑」正面破防',
    },
    UNDER_SEEP: {
      badge: '诡道杀机 · 暗流越位',
      hint: '致命机制！宜开启冰晶宫殿推演破绽，切忌无防备强压',
    },
    STAGGERED: {
      badge: '架势崩解 · 破招失衡',
      hint: '敌方本回合行动已中断且防线松动，承受伤害提升',
    },
  };

  const CB_SVG = {
    crystal: '<svg viewBox="0 0 20 20" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M10 2v16M3 6l14 8M17 6L3 14"/><polygon points="10,4.5 14.8,7.2 14.8,12.8 10,15.5 5.2,12.8 5.2,7.2"/></svg>',
    wand: '<svg viewBox="0 0 20 20" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 16L13.5 6.5"/><circle cx="14.5" cy="5.5" r="2.6"/><path d="M10.5 3.2v1.3M16.8 9.5h-1.3"/></svg>',
    retreat: '<svg viewBox="0 0 20 20" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M8 5L3.5 9.5 8 14"/><path d="M3.5 9.5H13a3.5 3.5 0 010 7H10"/></svg>',
    hourglass: '<svg viewBox="0 0 20 20" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.45" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5.5 3h9M5.5 17h9M6.5 3c0 3.8 3.5 5.2 3.5 7s-3.5 3.2-3.5 7M13.5 3c0 3.8-3.5 5.2-3.5 7s3.5 3.2 3.5 7"/></svg>',
    swords: '<svg viewBox="0 0 20 20" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 3.5l1.5 1.5-9 9-2.5.5.5-2.5 9.5-8.5z"/><path d="M5 3.5L3.5 5l4 4M11.5 13l3 3 1.5-1.5-3-3"/></svg>',
    shield: '<svg viewBox="0 0 20 20" width="13" height="13" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M10 2.5l6 2.5v4.8c0 3.8-2.6 6.8-6 7.8-3.4-1-6-4-6-7.8V5l6-2.5z"/></svg>',
    scale: '<svg viewBox="0 0 20 20" width="13" height="13" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M10 3v14M6 17h8M4.5 6.5h11M4.5 6.5L2.5 12h4l-2-5.5zM15.5 6.5L13.5 12h4l-2-5.5z"/></svg>',
    chart: '<svg viewBox="0 0 20 20" width="13" height="13" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 15.5V9.5M10 15.5V4.5M16 15.5V7.5"/></svg>',
  };

  function resolveBattleBgUrl(stageCfg) {
    const id = stageCfg && stageCfg.id ? stageCfg.id : '';
    if (id === 'hulan_beast_tide') return 'assets/bg/ice_canyon.jpg';
    if (id === 'aino_sparring') return 'assets/bg/ice_classroom.jpg';
    if (id === 'rowan_graveyard') return 'assets/bg_night.jpg';
    if (id === 'north_forest_hunt') return 'assets/bg/north_forest.jpg';
    return 'assets/bg/training.jpg';
  }

  function renderBeastCrestSVG(kind) {
    const k = String(kind || '');
    if (k.indexOf('jackal') >= 0) {
      return '<svg viewBox="0 0 120 120" fill="none" aria-hidden="true">' +
        '<circle cx="60" cy="60" r="50" stroke="rgba(139,211,255,0.28)" stroke-width="1.5" stroke-dasharray="4 4"/>' +
        '<polygon points="60,14 96,42 84,92 60,106 36,92 24,42" fill="rgba(16,24,48,0.85)" stroke="#9dd4ff" stroke-width="2"/>' +
        '<path d="M38 38L49 20L56 36L60 22L64 36L71 20L82 38L74 66L60 88L46 66Z" fill="rgba(42,64,108,0.65)" stroke="#d8b467" stroke-width="1.8"/>' +
        '<polygon points="48,54 55,58 47,61" fill="#ff7d91"/>' +
        '<polygon points="72,54 65,58 73,61" fill="#ff7d91"/>' +
        '<path d="M48 74l6 8 6-6 6 6 6-8" stroke="#e4eefc" stroke-width="2" stroke-linecap="round"/>' +
      '</svg>';
    }
    if (k.indexOf('hulan') >= 0 || k.indexOf('lord') >= 0) {
      return '<svg viewBox="0 0 120 120" fill="none" aria-hidden="true">' +
        '<circle cx="60" cy="60" r="52" stroke="rgba(139,211,255,0.34)" stroke-width="1.5"/>' +
        '<path d="M22 44L36 22L50 38L60 16L70 38L84 22L98 44L88 86L60 104L32 86Z" fill="rgba(14,34,68,0.88)" stroke="#8bd3ff" stroke-width="2.2"/>' +
        '<polygon points="60,46 73,64 60,84 47,64" fill="rgba(139,211,255,0.32)" stroke="#f4dca0" stroke-width="1.8"/>' +
        '<circle cx="60" cy="64" r="5" fill="#d8f4ff"/>' +
        '<path d="M40 54l10 4M80 54l-10 4" stroke="#8bd3ff" stroke-width="2.4" stroke-linecap="round"/>' +
      '</svg>';
    }
    // 银霜啸月魔狼纹章（北林群狼 / 默认兽徽）
    return '<svg viewBox="0 0 120 120" fill="none" aria-hidden="true">' +
      '<circle cx="60" cy="60" r="50" stroke="rgba(216,180,103,0.34)" stroke-width="1.4"/>' +
      '<path d="M84 26A28 28 0 0144 82A24 24 0 0084 26Z" fill="rgba(216,180,103,0.18)"/>' +
      '<path d="M36 42L43 18L55 34H65L77 18L84 42L90 62L60 98L30 62Z" fill="rgba(16,32,62,0.88)" stroke="#9dd4ff" stroke-width="2"/>' +
      '<path d="M46 46L60 72L74 46" stroke="#d8b467" stroke-width="1.6" stroke-linejoin="round"/>' +
      '<polygon points="44,54 53,57 46,61" fill="#8bd3ff"/>' +
      '<polygon points="76,54 67,57 74,61" fill="#8bd3ff"/>' +
      '<path d="M51 77l4 6 5-4 5 4 4-6" stroke="#eef6ff" stroke-width="1.8" stroke-linecap="round"/>' +
    '</svg>';
  }

  /* =========================================================
     1. 玩家战术技能库（高耗蓝匹配原著 100% 魔战循环等量回蓝）
     ========================================================= */
  const TACTICAL_SKILLS = {
    basic_attack: {
      id: 'basic_attack',
      name: '防身平斩',
      path: 'SWORD',
      elem: 'phys',
      ap: 1,
      mp: 0,
      power: 0.72,
      atkKind: 'atk',
      exposure: 0,
      desc: '基础挥击，零耗蓝，不触发魔战循环，对高防与风步收效甚微。',
    },

    // —— 【经手构筑】 ——
    hand_water_surge: {
      id: 'hand_water_surge',
      name: '覆潮水弹',
      path: 'HAND',
      elem: 'water',
      ap: 1,
      mp: 30,
      power: 1.52,
      atkKind: 'matk',
      exposure: 0,
      clearBlind: true,
      douseFire: true,
      desc: '经手压缩水流冲击，克制火系并冲净扬尘遮眼，零冰系暴露。',
    },
    hand_ice_crystal: {
      id: 'hand_ice_crystal',
      name: '凝华冰晶',
      path: 'HAND',
      elem: 'ice',
      ap: 1,
      mp: 38,
      power: 1.76,
      atkKind: 'matk',
      exposure: 66,
      chill: 1,
      desc: '无气泡高密度凝冰直射，正面破盾力强，但施法路径较长。',
    },
    hand_ice_wall: {
      id: 'hand_ice_wall',
      name: '凝水厚冰墙',
      path: 'HAND',
      elem: 'ice',
      ap: 1,
      mp: 28,
      power: 0,
      atkKind: 'matk',
      noOvercast: true,
      cooldown: 1,
      exposure: 65,
      shieldBase: 26,
      shieldScale: 0.55,
      desc: '童年期习得的基础经手冰墙（冷却1回合），稳健抵御正面冲击。',
    },
    hand_frost_floor: {
      id: 'hand_frost_floor',
      name: '蔓地薄冰',
      path: 'HAND',
      elem: 'ice',
      ap: 1,
      mp: 18,
      power: 0,
      atkKind: 'matk',
      noOvercast: true,
      cooldown: 1,
      exposure: 60,
      layFrostFloor: 2,
      desc: '沿地表悄然铺开薄冰（持续2回合，冷却1回合），待敌穿过窄道时以冰晶锁腿！',
    },
    hand_root_shield: {
      id: 'hand_root_shield',
      name: '钢冰生根盾',
      path: 'HAND',
      elem: 'ice',
      ap: 1,
      mp: 34,
      power: 0,
      atkKind: 'matk',
      noOvercast: true,
      cooldown: 1,
      exposure: 65,
      shieldBase: 31,
      shieldScale: 0.54,
      rooted: 1,
      iceThorns: 1,
      protectCrate: 32,
      desc: '魔力入地生根立盾（冷却1回合），防冰面打滑并协防药箱。',
    },
    hand_water_veil: {
      id: 'hand_water_veil',
      name: '折射水幕',
      path: 'HAND',
      elem: 'water',
      ap: 1,
      mp: 26,
      power: 0,
      atkKind: 'matk',
      noOvercast: true,
      cooldown: 1,
      exposure: 0,
      shieldBase: 20,
      shieldScale: 0.45,
      clearDebuff: true,
      desc: '柔韧水膜护身（冷却1回合），洗净灼烧与视线受阻，零暴露。',
    },
    hand_thorn_field: {
      id: 'hand_thorn_field',
      name: '冰棘群刺阵',
      path: 'HAND',
      elem: 'ice',
      ap: 2,
      mp: 62,
      power: 1.56,
      atkKind: 'matk',
      cooldown: 1,
      aoe: true,
      sureHit: true,
      drainWindMp: 14,
      exposure: 72,
      chill: 1,
      desc: '双手平推铺冰刺出九向地棘（冷却1回合）！全场必中，群怪魔战100%回蓝倍增！',
    },

    // —— 【隔空瞬凝（不经手 · 12岁学院艾诺点拨后习得）】 ——
    remote_blind_shot: {
      id: 'remote_blind_shot',
      name: '侧翼盲区冰弹',
      path: 'REMOTE',
      elem: 'ice',
      ap: 1,
      mp: 26,
      power: 0.92,
      interruptPower: 1.85,
      atkKind: 'matk',
      exposure: 65,
      desc: '不经手于敌身侧瞬凝！命中【双手控场】直接截断破招暴击！',
    },
    remote_snap_spike: {
      id: 'remote_snap_spike',
      name: '瞬发断咏冰锥',
      path: 'REMOTE',
      elem: 'ice',
      ap: 1,
      mp: 40,
      power: 1.08,
      interruptPower: 2.12,
      atkKind: 'matk',
      pierceHalfShield: true,
      exposure: 68,
      desc: '足下三十公分瞬凝尖锥，对【双手控场】断咏重创并无视半盾！',
    },

    // —— 【霁馆剑步（15岁澄岚霁馆习得 / 9岁决斗风行残像）】 ——
    sword_root_step: {
      id: 'sword_root_step',
      name: '生根步·卸力侧滑',
      path: 'SWORD',
      elem: 'phys',
      ap: 1,
      mp: 10,
      power: 0,
      atkKind: 'atk',
      noOvercast: true,
      cooldown: 1,
      exposure: -6,
      dodgeLunge: true,
      rooted: 1,
      desc: '沉膝横移纯步法（零护盾，冷却1回合）！唯迎击【贴身突袭】触发卸力闪反并蓄势下一刀。',
    },
    sword_water_edge: {
      id: 'sword_water_edge',
      name: '送刀·覆水极薄冰锋',
      path: 'SWORD',
      elem: 'water',
      ap: 1,
      mp: 22,
      power: 1.18,
      lungeRipostePower: 2.05,
      atkKind: 'hybrid',
      noOvercast: true,
      exposure: -10,
      counterLunge: true,
      desc: '活剑送刀裹极薄冰膜，事后化水降暴露！配合生根步蓄势或迎击扑杀威力倍增。',
    },
    sword_wind_afterimage: {
      id: 'sword_wind_afterimage',
      name: '风行残像',
      path: 'SWORD',
      elem: 'wind',
      ap: 1,
      mp: 18,
      power: 0,
      atkKind: 'atk',
      noOvercast: true,
      cooldown: 3,
      exposure: 0,
      afterimage: 1,
      nextApBonus: 1,
      desc: '气流折射留残影1.5秒（冷却3回合），闪避下一次攻击并令下回合+1 AP！',
    },

    // —— 【❄️ 冰晶宫殿·专属看破反制技（每波审视解锁后限1次）】 ——
    insight_beatrice_pillar: {
      id: 'insight_beatrice_pillar',
      name: '❄️ 看破·封肩地下冰柱',
      path: 'INSIGHT',
      elem: 'ice',
      ap: 1,
      mp: 18,
      power: 2.05,
      atkKind: 'matk',
      sureHit: true,
      maxUses: 1,
      interruptWindupOnly: true,
      shatterFireAura: true,
      applyVuln: 1,
      chill: 2,
      exposure: 20,
      desc: '算准她先抬右肩钉死重心的瞬间，地底冰柱一举掀翻全部斗气并截停重劈！',
    },
    insight_rowan_prism: {
      id: 'insight_rowan_prism',
      name: '❄️ 看破·双镜合拢夹杖',
      path: 'INSIGHT',
      elem: 'ice',
      ap: 1,
      mp: 20,
      power: 1.65,
      atkKind: 'matk',
      sureHit: true,
      maxUses: 1,
      forceInterrupt: true,
      sealBoost: 44,
      shieldBase: 30,
      shieldScale: 0.45,
      exposure: 15,
      desc: '识破他虚刺叔叔实则脱手掷杖袭心，双面冰镜凌空合拢死死夹住晦轮杖！',
    },
    insight_alice_cage: {
      id: 'insight_alice_cage',
      name: '❄️ 看破·封路十字冰栏',
      path: 'INSIGHT',
      elem: 'ice',
      ap: 1,
      mp: 20,
      power: 1.65,
      atkKind: 'matk',
      sureHit: true,
      maxUses: 1,
      drainEnemyMp: 22,
      sealWindEvade: 3,
      exposure: 20,
      desc: '锁死左侧裙摆折射的绕后风轨，必中截停并封印风步闪避、重挫其魔力池！',
    },
    insight_aino_bead: {
      id: 'insight_aino_bead',
      name: '❄️ 看破·盲区弹指冰珠',
      path: 'INSIGHT',
      elem: 'ice',
      ap: 1,
      mp: 18,
      power: 1.7,
      atkKind: 'matk',
      sureHit: true,
      bypassMirror: true,
      guaranteedCleanHit: true,
      maxUses: 1,
      exposure: 15,
      desc: '越过正面无瑕镜冰，于体侧盲区瞬凝冰珠精准弹中艾诺手背（有效命中+1）！',
    },
    insight_noelle_sever: {
      id: 'insight_noelle_sever',
      name: '❄️ 看破·冻彻冰缝断流',
      path: 'INSIGHT',
      elem: 'ice',
      ap: 1,
      mp: 16,
      power: 1.62,
      atkKind: 'matk',
      sureHit: true,
      severSeep: true,
      shatterShield: true,
      applyVuln: 1,
      maxUses: 1,
      exposure: 20,
      desc: '将暗渡至脚底冰缝的细水线彻底冻死，粉碎水幕并瓦解残血翻盘杀！',
    },
    insight_jackal_throat: {
      id: 'insight_jackal_throat',
      name: '❄️ 看破·沉身迎喉覆水斩',
      path: 'INSIGHT',
      elem: 'water',
      ap: 1,
      mp: 16,
      power: 2.15,
      atkKind: 'hybrid',
      noOvercast: true,
      sureHit: true,
      stripEvadeCharges: true,
      forceInterrupt: true,
      exposure: -15,
      maxUses: 1,
      desc: '锁死影豺腾空无法变向的下颌死角，覆水薄刃封喉且事后化水无痕！',
    },
    insight_hulan_resonance: {
      id: 'insight_hulan_resonance',
      name: '❄️ 看破·伊诺共鸣锁核',
      path: 'INSIGHT',
      elem: 'ice',
      ap: 1,
      mp: 36,
      power: 2.25,
      atkKind: 'matk',
      sureHit: true,
      shatterShield: true,
      shredArmor: true,
      applyVuln: 2,
      protectCrate: 38,
      triggerAinoSpear: true,
      maxUses: 1,
      exposure: 0,
      desc: '锁定领主腹下微裂晶核引动共鸣，接应崖顶艾诺的无气泡极寒冰枪贯通破甲！',
    },
    insight_generic_flaw: {
      id: 'insight_generic_flaw',
      name: '❄️ 看破·凝霜贯隙刺',
      path: 'INSIGHT',
      elem: 'ice',
      ap: 1,
      mp: 20,
      power: 1.9,
      atkKind: 'matk',
      sureHit: true,
      shatterShield: true,
      forceInterrupt: true,
      applyVuln: 1,
      protectCrate: 28,
      maxUses: 1,
      exposure: 15,
      desc: '直击时停推演锁定的发力缝隙，击碎护甲并打断当前蓄势。',
    },
  };

  /* =========================================================
     2. 7 大代表性战斗关卡配置表（严格遵循原著时间线与能力树）
     ========================================================= */
  const STAGE_CONFIGS = {
    beatrice_11: {
      id: 'beatrice_11',
      order: 1,
      title: '贝阿特丽丝（11岁·虚拟决斗）',
      chapter: '第一卷 · 梦境初试（9岁）',
      stars: '★★☆☆☆',
      charId: 'beatrice',
      emoji: '🔥',
      bg: 'bg-duel',
      tags: ['水克火1.5x', '三层烈焰斗气', '抬肩前摇看破'],
      summary: '三层烈焰斗气 + 火球重劈与剑障防反！盲目单招复读会被融冰反劈，须交替水冰破招或以冰宫地下冰柱一举掀翻斗气。',
      preset: {
        hp: 165, mhp: 165, mp: 230, mmp: 230,
        atk: 14, matk: 35, def: 9, mdef: 12,
        skills: ['basic_attack', 'hand_water_surge', 'hand_ice_crystal', 'hand_ice_wall', 'hand_water_veil'],
        passives: [],
        manaCycle: false,
        eclipseWand: false,
        palaceCharges: 1,
      },
      reward: { duelKey: 'beatrice_11', skillId: 'temp_sense', skillName: '温度感知', exp: 50, gold: 0 },
      palace: {
        sceneText: '淡蓝色虚拟斗兽场凝固。贝阿特丽丝周身环绕燥热气浪，掌心火球膨胀，正准备踏步重劈。',
        clues: [
          { id: 'ponytail', text: '高高扬起的金色马尾正随热浪向右后方飘摆', correct: false, feedback: '马尾只是随热浪自然摆动，并未暴露发力落点。' },
          { id: 'shoulder_lift', text: '甩出重型火球前，她的右肩习惯性先抬半寸', correct: true, feedback: '观察准确！她发力前必先抬右肩，重心已提前钉死。' },
          { id: 'boot_scuff', text: '靴尖重重踏进石板缝隙，带起一串细碎火星', correct: false, feedback: '直线踏步只是常规冲势，单看靴底难以提前反制。' },
        ],
        deductions: [
          { id: 'rush_face', text: '趁她抬肩正面迎上，与火焰气浪硬拼魔力输出', correct: false, feedback: '正面热浪正盛，硬拼只会白白损耗魔力。' },
          { id: 'under_pillar', text: '算准她抬肩钉死重心的落点，从地底顶出冰柱', correct: true, unlockSkill: 'insight_beatrice_pillar', feedback: '推演完成！地下冰柱可一举掀翻她的三层烈焰斗气并截停重劈！' },
        ],
      },
      waves: [
        {
          intro: '贝阿特丽丝叉着腰掌心冒火：「来决斗？正好贝阿特丽丝大人手痒了，可不会手下留情哦！」',
          enemies: [
            {
              id: 'beatrice',
              charId: 'beatrice',
              name: '贝阿特丽丝（11岁）',
              emoji: '🔥',
              elem: 'fire',
              hp: 278,
              mhp: 278,
              atk: 36,
              def: 10,
              mdef: 12,
              fireAura: 3,
              trait: '三层烈焰斗气：每层减免10%伤害并逐回合升温；受覆潮水弹逐层浇弱，或以看破冰柱一击掀翻。剑障防反时忌盲丢冰晶！',
              aiType: 'beatrice',
            },
          ],
        },
      ],
    },

    rowan_graveyard: {
      id: 'rowan_graveyard',
      order: 2,
      title: '罗文（8岁间章·乱葬岗活捉战）',
      chapter: '第一卷 · 间章《白昼里的夜》',
      stars: '★★★★☆',
      charId: 'reno',
      emoji: '🌑',
      bg: 'bg-img-night bg-night',
      tags: ['8岁童年配装', '白昼冰镜核验', '窄道铺冰+双镜夹杖', '打死算逃脱失败'],
      summary: '秋夜月升，罗文影子已恢复正常。须用8岁基础薄冰配合雷纳德切窄道锁腿，借冰晶宫殿核验白昼第四面冰镜并识破脱手旋杖，凑满100%封锁活捉！',
      sealRule: true,
      preset: {
        hp: 150, mhp: 150, mp: 255, mmp: 255,
        atk: 12, matk: 35, def: 8, mdef: 12,
        skills: ['basic_attack', 'hand_ice_crystal', 'hand_ice_wall', 'hand_frost_floor', 'hand_water_veil'],
        passives: [],
        manaCycle: false,
        eclipseWand: false,
        palaceCharges: 1,
      },
      reward: { exp: 140, gold: 0 },
      palace: {
        sceneText: '秋夜月升，罗文脚下影子已恢复如常。你边退边沉入冰晶宫殿核对白昼冻结的四面冰镜，同时定格眼前他刺向雷纳德肋下的右手。',
        clues: [
          { id: 'moon_grass', text: '月光下坟头荒草倒伏，罗文靴底沾着新翻的腐殖泥', correct: false, feedback: '乱葬岗新土本就松软，泥渍无法解释他的真正杀招。' },
          { id: 'mirror_thumb', text: '第四面冰镜日影慢半拍，且眼前他握杖拇指已半松', correct: true, feedback: '核验吻合！白昼日蚀止息时的迟滞日影证实他便是施术者，而此刻松指正是脱手掷杖前兆！' },
          { id: 'cloak_cut', text: '黑衣下摆被歪斜墓碑刮裂，露出一截暗银色内衬边', correct: false, feedback: '衣摆裂口只是穿过石碑时的擦痕，并非致命机关。' },
        ],
        deductions: [
          { id: 'aid_reno', text: '将冰墙横插在雷纳德身侧，替叔叔挡下肋下这一刺', correct: false, feedback: '雷纳德早已侧身避让，他的真正目标根本在后面！' },
          { id: 'clamp_staff', text: '预判他虚刺叔叔实则脱手掷杖袭心，双镜凌空合拢', correct: true, unlockSkill: 'insight_rowan_prism', feedback: '推演完成！解锁「双镜合拢夹杖」，待他掷杖袭心时凌空锁死晦轮杖！' },
        ],
      },
      waves: [
        {
          intro: '雷纳德从歪脖子树跳下：「别当着家长的面打小孩。」注意：必须留活口审问，打空罗文生命将致其化雾遁逃失败！',
          enemies: [
            {
              id: 'rowan',
              name: '罗文（圣级血族侍卫）',
              emoji: '🌑',
              elem: 'dark',
              hp: 290,
              mhp: 290,
              atk: 48,
              def: 15,
              mdef: 18,
              trait: '活捉铁律：纯挨打不涨封锁度，非窄道盲丢冰晶遭晦轮折射且HP归零将化雾逃脱判败！须铺【蔓地薄冰】抓窄道(+38%)配【双镜夹杖】满100%活捉！',
              aiType: 'rowan',
            },
          ],
        },
      ],
    },

    alice_9: {
      id: 'alice_9',
      order: 3,
      title: '爱丽丝（9岁·虚拟决斗）',
      chapter: '第一卷 · 风与羽毛（11岁）',
      stars: '★★★☆☆',
      charId: 'alice',
      emoji: '💨',
      bg: 'bg-duel',
      tags: ['扬尘必偏斜', '双层风步闪避', '封路榨蓝自断风暴'],
      summary: '扬尘遮蔽视线 + 每回合双层风步闪避 + 微风回蓝！普攻挥空无法耗其魔力，须用水弹洗尘、冰棘压走位或冰宫封锁风轨榨干她的魔力池！',
      preset: {
        hp: 155, mhp: 155, mp: 295, mmp: 295,
        atk: 15, matk: 38, def: 9, mdef: 13,
        skills: ['basic_attack', 'hand_water_surge', 'hand_ice_crystal', 'hand_ice_wall', 'hand_water_veil', 'hand_thorn_field'],
        passives: ['temp_sense'],
        manaCycle: false,
        eclipseWand: false,
        palaceCharges: 1,
      },
      reward: { duelKey: 'alice_9', skillId: 'wind_afterimage', skillName: '风行残像', exp: 75, gold: 0 },
      palace: {
        sceneText: '地面灰尘刚刚扬起，微风在爱丽丝身畔轻巧盘旋，她的身影正借风向侧方滑开。',
        clues: [
          { id: 'calm_eyes', text: '白发垂落耳际，半敛的蓝眸平静注视着正前方', correct: false, feedback: '妹妹神色始终安静淡然，眼神并未指向落脚位置。' },
          { id: 'skirt_wind', text: '扬尘漫起瞬间，她左侧裙摆逆着微风轻轻内贴', correct: true, feedback: '观察准确！「是因为风在帮我」——裙摆内贴暴露了她借风绕左的气流轨！' },
          { id: 'tiny_hands', text: '双手自然微张于身前，指尖萦绕着淡青色微光', correct: false, feedback: '指尖微光只是基础导引，真正的机动藏在脚下风向里。' },
        ],
        deductions: [
          { id: 'front_wall', text: '在正前方立起高大冰墙，彻底隔绝扑面而来的尘雾', correct: false, feedback: '她已经绕向侧翼，正面冰墙只会挡住你自己的视野。' },
          { id: 'cross_cage', text: '顺着气流折射锁死左侧落点，以十字冰栏截停风步', correct: true, unlockSkill: 'insight_alice_cage', feedback: '推演完成！十字冰栏可彻底封印她的风步闪避并大幅耗损其魔力！' },
        ],
      },
      waves: [
        {
          intro: '爱丽丝安静站定：「……请姐姐大人多多指教。」微风在她周身凝成两层轻羽护流。',
          enemies: [
            {
              id: 'alice',
              charId: 'alice',
              name: '爱丽丝（9岁）',
              emoji: '💨',
              elem: 'wind',
              hp: 440,
              mhp: 440,
              mp: 64,
              mmp: 64,
              windCushion: true,
              evadeCharges: 2,
              maxEvadeCharges: 2,
              atk: 36,
              def: 9,
              mdef: 15,
              trait: '微风护体：每回合维持2层风步闪避并自然回流7 MP；第4/7回合合拢蓄力狂岚（若MP不足22将当场溃散认输）！',
              aiType: 'alice',
            },
          ],
        },
      ],
    },

    aino_sparring: {
      id: 'aino_sparring',
      order: 4,
      title: '艾诺·塔尔维（冰上之战·三击制）',
      chapter: '第二卷 · 第四章 距离（12岁）',
      stars: '★★★★☆',
      charId: 'aino',
      emoji: '🧊',
      bg: 'bg-img-training bg-plain',
      tags: ['唯3次有效命中可胜', '正面镜冰免伤', '盲丢瞬凝触发反刺'],
      summary: '纯冰系切磋，唯抢满3次有效命中可获胜（9回合限时）！正面经手全被无气泡镜冰格挡，非空档期乱丢隔空瞬凝将遭反刺丢分！',
      hitRule: true,
      targetHits: 3,
      turnLimit: 9,
      iceOnlyRule: true,
      preset: {
        hp: 175, mhp: 175, mp: 255, mmp: 255,
        atk: 18, matk: 46, def: 11, mdef: 16,
        skills: ['basic_attack', 'hand_ice_crystal', 'hand_root_shield', 'remote_blind_shot', 'remote_snap_spike', 'sword_wind_afterimage'],
        passives: ['temp_sense'],
        manaCycle: false,
        eclipseWand: false,
        palaceCharges: 1,
      },
      reward: { duelKey: 'aino_cur', skillId: 'root_ice', skillName: '生根之冰', taskId: 'ice_hits', exp: 120, gold: 0 },
      palace: {
        sceneText: '训练场砂地覆霜。艾诺白发高束如出鞘利剑，双掌正同时按向地面引导双翼冰刺。',
        clues: [
          { id: 'front_mirror', text: '身前薄冰光滑如打蜡玻璃，内部找不到半点气泡', correct: false, feedback: '正面薄冰毫无瑕疵，强攻正面只会撞碎自己的冰晶。' },
          { id: 'left_shoulder_gap', text: '双掌同时贴地控冰时，左肩与右手背外侧空出半秒', correct: true, feedback: '观察准确！双手控场瞬间，体侧三十公分处于防御真空！' },
          { id: 'silver_ponytail', text: '高束的银白长发垂直落下，足尖稳稳扣住冻结砂面', correct: false, feedback: '她的下盘生根极稳，足尖并无破绽。' },
        ],
        deductions: [
          { id: 'heavy_spear', text: '凝聚更粗重的经手冰矛，全力轰击她正面的薄冰盾', correct: false, feedback: '经手释放路径太长，她一眼便能提前加厚冰盾。' },
          { id: 'snap_bead', text: '绕开正面镜冰，于她体侧盲区空气中瞬凝冰珠弹手背', correct: true, unlockSkill: 'insight_aino_bead', feedback: '推演完成！解锁「看破·盲区弹指冰珠」，直接拿下一记关键有效命中！' },
        ],
      },
      waves: [
        {
          intro: '艾诺：「规则简单。只用冰系魔法，9回合内打中三次算赢。战斗可不会给你三秒准备时间。」',
          enemies: [
            {
              id: 'aino',
              charId: 'aino',
              name: '艾诺·塔尔维',
              emoji: '🧊',
              elem: 'ice',
              hp: 999,
              mhp: 999,
              nonLethalSpar: true,
              atk: 54,
              def: 16,
              mdef: 20,
              mirrorGuard: true,
              trait: '显微镜视力：正面【经手】全被薄冰挡下；非【双手控场】回合盲丢【隔空瞬凝】不仅无效，连丢更会触发反制冰刺丢分！',
              aiType: 'aino',
            },
          ],
        },
      ],
    },

    noelle_14: {
      id: 'noelle_14',
      order: 5,
      title: '诺艾儿（14岁·虚拟决斗）',
      chapter: '第二卷 · 第八章 冰融之际',
      stars: '★★★★☆',
      charId: 'noelle',
      emoji: '💧',
      bg: 'bg-duel',
      tags: ['100%魔战循环解锁', '零留白水幕', '残血必入冰缝暗流杀'],
      summary: '极致省蓝大师 vs 魔战循环！每回合布设52点尺量水幕；压至残血必借水垫切入【冰缝暗流陷阱】，须以看破断流或残像避险后再2.0x倾注斩杀！',
      preset: {
        hp: 190, mhp: 190, mp: 260, mmp: 260,
        atk: 20, matk: 46, def: 13, mdef: 20,
        skills: ['basic_attack', 'hand_ice_crystal', 'hand_root_shield', 'hand_thorn_field', 'remote_blind_shot', 'remote_snap_spike', 'sword_wind_afterimage'],
        passives: ['temp_sense', 'root_ice'],
        manaCycle: true,
        eclipseWand: false,
        palaceCharges: 1,
      },
      reward: { duelKey: 'noelle_14', skillId: 'mana_calc', skillName: '魔力精算', achId: 'mana_calc', exp: 150, gold: 0 },
      palace: {
        sceneText: '灰色石板广场定格。诺艾儿每一步后撤间距分毫不差，琥珀色眸子冷静得如同正在解算方程。',
        clues: [
          { id: 'left_hand_blank', text: '左手习惯性半握在腰侧，梦境中的手背空空如也', correct: false, feedback: '梦境未同步她手背的日程字迹，这并非她的反击后手。' },
          { id: 'thin_curtain', text: '正面水幕薄如纸页，边缘尺寸恰好卡死冰晶落点', correct: false, feedback: '正面水幕只是她省蓝防守的常态，真正杀招藏在地面！' },
          { id: 'ice_crack_waterline', text: '等距后撤间，一缕细水线正顺冰缝悄悄渗向脚底', correct: true, feedback: '观察准确！她一直在借冰层裂缝向你脚底暗渡水线，正面冰盾根本挡不住脚底穿刺！' },
        ],
        deductions: [
          { id: 'rush_break', text: '趁她魔力见底水幕变薄，欺身前压倾泻冰晶强攻', correct: false, feedback: '一旦重心前压踏实，脚底暗水线便会瞬间贯穿翻盘！' },
          { id: 'freeze_seep', text: '止步稳住重心，将寒气灌入脚下冻绝冰缝暗水线', correct: true, unlockSkill: 'insight_noelle_sever', feedback: '推演完成！解锁「看破·冻彻冰缝断流」，彻底废除她的残血翻盘杀并击碎水幕！' },
        ],
      },
      waves: [
        {
          intro: '诺艾儿站在十五米外，每一滴魔力都当最后一滴用。利用【魔战循环】消耗她的魔力池，并提防冰面下的暗流！',
          enemies: [
            {
              id: 'noelle',
              charId: 'noelle',
              name: '诺艾儿（14岁）',
              emoji: '💧',
              elem: 'water',
              hp: 660,
              mhp: 660,
              mp: 175,
              mmp: 175,
              atk: 44,
              def: 14,
              mdef: 24,
              seepStacks: 0,
              trait: '尺量水幕 & 脚底暗流：每回合维持52点精准水幕；生命降至165时必借水垫退入【冰缝暗流陷阱】，无视正面护盾直刺脚底造成205点重创！',
              aiType: 'noelle',
            },
          ],
        },
      ],
    },

    north_forest_hunt: {
      id: 'north_forest_hunt',
      order: 6,
      title: '北林群狼 + 霜脊影豺突袭（连续波次）',
      chapter: '第三卷 · 第三章 北林（15岁）',
      stars: '★★★★☆',
      emoji: '🐺',
      bg: 'bg-img-forest bg-forest',
      tags: ['每波独立1次冰宫', 'W1四狼逼AOE满蓝', 'W2耳目禁冰+生根步闪反'],
      summary: 'W1四只灰棘狼高伤围猎，须以冰棘群刺触发魔战100%多倍回满蓝条；W2银级影豺带闪避层扑喉且极光小队迫近，须先以生根步卸力闪反再覆水封喉！',
      preset: {
        hp: 220, mhp: 220, mp: 280, mmp: 280,
        atk: 42, matk: 48, def: 15, mdef: 22,
        skills: ['hand_ice_crystal', 'hand_water_surge', 'hand_root_shield', 'hand_water_veil', 'hand_thorn_field', 'remote_snap_spike', 'sword_root_step', 'sword_water_edge', 'sword_wind_afterimage'],
        passives: ['temp_sense', 'root_ice', 'mana_calc'],
        manaCycle: true,
        eclipseWand: true,
        palaceCharges: 1,
      },
      reward: { skillId: 'stealth_edge', skillName: '覆水无痕', exp: 180, gold: 35 },
      palaceByWave: {
        0: {
          sceneText: '冬日落叶林深处，四只灰棘狼踏在潮湿腐叶层上呈扇形合围扑近。',
          clues: [
            { id: 'wolf_fur', text: '头狼脊背硬刺根根倒竖，前爪刨开林间枯黄腐叶', correct: false, feedback: '脊背硬刺只是交付任务的素材，并非合围破绽。' },
            { id: 'wet_leaves', text: '四狼呈密集扇形争抢扑近，脚下湿腐叶极易覆冰', correct: true, feedback: '观察准确！群居魔物站位密集且地面潮湿，正是群攻良机！' },
            { id: 'dead_wood', text: '后方倒木布满青苔爪痕，灌木丛间枝条剧烈晃动', correct: false, feedback: '倒木位于外圈，无法阻挡正面四狼扑咬。' },
          ],
          deductions: [
            { id: 'single_pick', text: '逐一瞄准后排灰棘狼，以单发水弹稳健点名清理', correct: false, feedback: '四狼场攻极高，单点清理太慢会被围攻重创。' },
            { id: 'thorn_sweep', text: '平推铺开贴地薄冰，刺出九向冰棘令狼群集体失衡', correct: true, unlockSkill: 'insight_generic_flaw', feedback: '推演完成！范围覆盖天然克制群体！' },
          ],
        },
        1: {
          sceneText: '林外百步传来「极光」小队凯尔的交谈声！眼前银影骤掠，银级「霜脊影豺」已四爪离地扑向咽喉！',
          clues: [
            { id: 'camo_coat', text: '银灰皮毛与枯枝色调相融，落地时足垫悄无声息', correct: false, feedback: '它已经腾空起跳，保护色不再影响交手。' },
            { id: 'midair_jaw', text: '四爪腾空扑咬离地，半空中的下颌与咽喉无法变向', correct: true, feedback: '观察准确！全力腾空后它无法在半空二次借力变向！' },
            { id: 'kyle_voice', text: '百步外林间隐约传来交谈，极光小队正在附近搜寻', correct: false, feedback: '只要不动用外显冰系与晦轮杖，他们便不会察觉。' },
          ],
          deductions: [
            { id: 'ice_blast', text: '原地张开大型冰棱阵，将半空中的影豺冻成冰雕', correct: false, feedback: '外显冰系魔力与切口会立刻引来极光小队！' },
            { id: 'water_throat', text: '沉身迎向死角送出覆水薄刃，事后化水不留痕迹', correct: true, unlockSkill: 'insight_jackal_throat', feedback: '推演完成！解锁「看破·沉身迎喉覆水斩」，零暴露一剑封喉！' },
          ],
        },
      },
      waves: [
        {
          witnessActive: false,
          intro: '【第 1/2 波 · 无人深林】四只灰棘狼合围扑来（总场攻极高）！四周无人，立即用【冰棘群刺阵】触发魔战循环多倍回满蓝条！',
          enemies: [
            { id: 'wolf_alpha', name: '灰棘头狼', emoji: '🐺', elem: 'wind', hp: 195, mhp: 195, shield: 20, atk: 34, def: 8, mdef: 8, trait: '群狼头领：仰首群嚎令全群攻击暴涨。', aiType: 'pack_wolf' },
            { id: 'wolf_b', name: '灰棘狼·甲', emoji: '🐺', elem: 'wind', hp: 118, mhp: 118, atk: 27, def: 5, mdef: 5, trait: '凶猛合围：单点清理过慢将被群狼撕碎。', aiType: 'pack_wolf' },
            { id: 'wolf_c', name: '灰棘狼·乙', emoji: '🐺', elem: 'wind', hp: 118, mhp: 118, atk: 27, def: 5, mdef: 5, trait: '凶猛合围：单点清理过慢将被群狼撕碎。', aiType: 'pack_wolf' },
            { id: 'wolf_d', name: '灰棘狼·丙', emoji: '🐺', elem: 'wind', hp: 118, mhp: 118, atk: 27, def: 5, mdef: 5, trait: '凶猛合围：单点清理过慢将被群狼撕碎。', aiType: 'pack_wolf' },
          ],
        },
        {
          witnessActive: true,
          initialExposure: 35,
          intro: '⚠️【第 2/2 波 · 耳目迫近】银级「霜脊影豺」突袭！林外极光小队正在勘察——忌用外显冰系与晦轮杖，先以【生根步】卸掉锁喉扑杀再覆水斩杀！',
          enemies: [
            {
              id: 'shadow_jackal',
              name: '霜脊影豺（银级）',
              emoji: '🦊',
              elem: 'ice',
              hp: 465,
              mhp: 465,
              evadeCharges: 1,
              maxEvadeCharges: 1,
              atk: 62,
              def: 14,
              mdef: 26,
              trait: '疾影锁喉：常备【💨疾影闪避×1】躲避鲁莽直击；须先以【生根步】卸掉锁喉扑杀破其闪避，再以覆水剑锋斩杀！',
              aiType: 'jackal',
            },
          ],
        },
      ],
    },

    hulan_beast_tide: {
      id: 'hulan_beast_tide',
      order: 7,
      title: '赫兰冰封峡谷·冻土兽潮协防战',
      chapter: '第三卷 · 第四章 奔赴北境',
      stars: '★★★★★',
      charId: 'aino',
      emoji: '🏔️',
      bg: 'bg-snow',
      tags: ['每波独立1次冰宫', '守护医疗药箱', '破招协同艾诺冰枪', '晦轮杖折光破甲'],
      summary: '5星终极战！守护药箱免遭冲撞，借每波冰宫看破或连续截断破招引动崖顶艾诺极寒冰枪震碎领主晶核，辅以晦轮杖折光与2.0x倾注轰杀领主！',
      crateRule: true,
      ainoSupport: true,
      preset: {
        hp: 250, mhp: 250, mp: 300, mmp: 300,
        atk: 45, matk: 54, def: 18, mdef: 25,
        skills: ['hand_ice_crystal', 'hand_root_shield', 'hand_thorn_field', 'remote_blind_shot', 'remote_snap_spike', 'sword_root_step', 'sword_water_edge', 'sword_wind_afterimage'],
        passives: ['temp_sense', 'root_ice', 'mana_calc'],
        manaCycle: true,
        eclipseWand: true,
        palaceCharges: 1,
      },
      reward: { achId: 'hulan_vanguard', exp: 260, gold: 80 },
      palaceByWave: {
        0: {
          sceneText: '赫兰暴雪如铁锤砸落。冻土重甲兽低头瞄准医疗药箱蓄力，两侧霜原狂狼同时扑近。',
          clues: [
            { id: 'snow_gust', text: '北境狂风裹挟六角暴雪，顺着狭窄冰谷呼啸灌入', correct: false, feedback: '风雪虽急，眼下最紧迫的是重甲兽撞向药箱的冲势。' },
            { id: 'armor_joint', text: '重甲兽低头冲向药箱，前膝甲片交叠缝隙正微张', correct: true, feedback: '观察准确！前膝甲缝正是截停它冲撞药箱的唯一支点！' },
            { id: 'wagon_wheel', text: '补给车木轮冻在冰层里，帆布篷顶积满厚重白雪', correct: false, feedback: '车体已冻牢，护住前侧药箱即可。' },
          ],
          deductions: [
            { id: 'ignore_box', text: '放任重甲兽撞向药箱，全力集火两侧的霜原狂狼', correct: false, feedback: '药箱一旦被撞毁，前线伤员防线便彻底崩溃！' },
            { id: 'guard_joint', text: '寒霜贯入前膝甲缝截停冲势，延展冰障护住药箱', correct: true, unlockSkill: 'insight_generic_flaw', feedback: '推演完成！截停冲锋并护住补给药箱！' },
          ],
        },
        1: {
          sceneText: '冰封峡谷剧震！领主级「霜渊裂地兽」披三寸灰岩冻甲破土而出，崖顶闪过一抹熟悉的浅蓝发丝与无气泡寒光。',
          clues: [
            { id: 'thick_carapace', text: '背部覆盖三寸厚灰岩冻甲，寻常冰刃难留半点痕', correct: false, feedback: '正面冻甲双抗极高，强砸背部如同挠痒。' },
            { id: 'blizzard_sky', text: '铅灰云层压得极低，漫天风雪遮蔽峡谷远端视野', correct: false, feedback: '云层并无异常，支援来自侧上方崖顶！' },
            { id: 'fissure_core', text: '震地前腹下幽蓝晶核微裂，恰与崖顶寒光成一线', correct: true, feedback: '观察准确！腹下散热晶核正处于高处艾诺冰枪的射击轴线上！' },
          ],
          deductions: [
            { id: 'solo_smash', text: '无视高处寒光轨迹，独自贴近正面硬撼灰岩重甲', correct: false, feedback: '领主重甲会不断再生，单靠蛮力来不及护住药箱。' },
            { id: 'aino_sync', text: '锁定腹下晶核引动共鸣，接应崖顶极寒冰枪破甲', correct: true, unlockSkill: 'insight_hulan_resonance', feedback: '推演完成！「冬天的孩子终会回到冬天」——解锁「伊诺共鸣锁核」贯通重甲！' },
          ],
        },
      },
      waves: [
        {
          witnessActive: false,
          intro: '【第 1/2 波 · 峡谷防线】冻土重甲兽携狂狼扑向医疗药箱！用群刺打狂狼回蓝，抓蓄力空档截断护箱，并用【晦轮杖·折光】凿穿重甲！',
          enemies: [
            { id: 'tundra_brute', name: '冻土重甲兽', emoji: '🐗', elem: 'earth', hp: 265, mhp: 265, shield: 55, atk: 46, def: 42, mdef: 38, trait: '攻城重甲：极高双抗且猛撞药箱；惧怕【隔空截断】与【晦轮杖折光破甲】！', aiType: 'hulan_brute' },
            { id: 'frost_hound_a', name: '霜原狂狼·甲', emoji: '🐺', elem: 'ice', hp: 132, mhp: 132, atk: 34, def: 8, mdef: 10, trait: '成群撕咬：绝佳的魔战循环回蓝踏板。', aiType: 'pack_wolf' },
            { id: 'frost_hound_b', name: '霜原狂狼·乙', emoji: '🐺', elem: 'ice', hp: 132, mhp: 132, atk: 34, def: 8, mdef: 10, trait: '成群撕咬：绝佳的魔战循环回蓝踏板。', aiType: 'pack_wolf' },
          ],
        },
        {
          witnessActive: false,
          intro: '❄️【第 2/2 波 · 领主降临 & 故人冰枪】领主「霜渊裂地兽」破冰而出！可用冰宫引动【伊诺共鸣】，或连续抓准【双手聚寒】破招引落两记艾诺冰枪震碎晶核！',
          enemies: [
            {
              id: 'abyss_behemoth',
              name: '霜渊裂地兽（领主）',
              emoji: '🗿',
              elem: 'earth',
              hp: 580,
              mhp: 580,
              shield: 115,
              atk: 66,
              def: 46,
              mdef: 44,
              boss: true,
              trait: '冻土领主：晶核未碎前每回合再生冻甲并寒震药箱；可借冰宫【伊诺共鸣】或连续【截断破招】引落第二发艾诺冰枪击碎晶核！',
              aiType: 'hulan_lord',
            },
            {
              id: 'ridge_claw',
              name: '寒脊爪兽',
              emoji: '🦎',
              elem: 'wind',
              hp: 165,
              mhp: 165,
              atk: 42,
              def: 12,
              mdef: 12,
              trait: '侧翼袭扰：高速突袭补给线。',
              aiType: 'jackal_minor',
            },
          ],
        },
      ],
    },
  };

  /* =========================================================
     3. 存档读取辅助与演武沙盒隔离
     ========================================================= */
  let arenaUseSaveStats = false;
  let arenaReturnToTitle = false;
  let hoveredSkillId = null;

  function getGameS() {
    return (typeof S !== 'undefined' && S) ? S : global.S;
  }
  function getPortraitMap() {
    return (typeof PORTRAIT_FILES !== 'undefined' && PORTRAIT_FILES) ? PORTRAIT_FILES : global.PORTRAIT_FILES;
  }
  function getCharMap() {
    return (typeof CHARS !== 'undefined' && CHARS) ? CHARS : global.CHARS;
  }
  function getEnemyTplMap() {
    return (typeof ENEMY_TEMPLATES !== 'undefined' && ENEMY_TEMPLATES) ? ENEMY_TEMPLATES : global.ENEMY_TEMPLATES;
  }

  function loadArenaRecords() {
    try {
      return JSON.parse(localStorage.getItem(ARENA_SAVE_KEY) || '{}');
    } catch (e) {
      return {};
    }
  }

  function saveArenaRecord(stageId, grade, turns) {
    const rankOrder = { S: 4, A: 3, B: 2, C: 1 };
    const rec = loadArenaRecords();
    const prev = rec[stageId];
    if (!prev || (rankOrder[grade] || 0) > (rankOrder[prev.grade] || 0) ||
        (prev.grade === grade && turns < prev.turns)) {
      rec[stageId] = { grade, turns, ts: Date.now() };
      try { localStorage.setItem(ARENA_SAVE_KEY, JSON.stringify(rec)); } catch (e) {}
    }
  }

  function hasEclipseInSave() {
    const curS = getGameS();
    if (!curS) return false;
    return !!(
      (curS.inv || []).some(it => it.id === 'eclipse_wand' || (it.name && it.name.includes('晦轮'))) ||
      (curS.flags && curS.flags.got_eclipse_wand)
    );
  }

  function getRelicsApi() {
    return (typeof RelicsAndEvents !== 'undefined' && RelicsAndEvents) ? RelicsAndEvents : global.RelicsAndEvents || null;
  }

  function hasRelic(player, relicId) {
    return !!(player && Array.isArray(player.relics) && player.relics.indexOf(relicId) !== -1);
  }

  function buildPlayerCombatant(stageCfg, opts) {
    opts = opts || {};
    const curS = getGameS() || {};
    const usePreset = opts.usePreset !== undefined ? opts.usePreset : !arenaUseSaveStats;
    const p = stageCfg && stageCfg.preset;
    const relApi = getRelicsApi();
    const activeRelics = relApi ? relApi.getActiveRelicsForBattle(Object.assign({}, opts, { state: curS })) : [];
    const activeAssist = relApi ? relApi.getActiveBondAssistForBattle(Object.assign({}, opts, { state: curS })) : null;
    const baseCrit = activeRelics.indexOf('belmont_schedule') !== -1 ? 0.15 : 0;

    if (usePreset && p) {
      return {
        name: (stageCfg.order >= 6) ? '眷寒渔（希尔维亚）' : '希尔维亚',
        hp: p.hp,
        mhp: p.mhp,
        mp: p.mp,
        mmp: p.mmp,
        atk: p.atk,
        matk: p.matk,
        def: p.def,
        mdef: p.mdef,
        shield: 0,
        maxShield: Math.round(p.mhp * 0.65),
        skills: p.skills.slice(),
        unlockedInsights: [],
        usedMaxSkills: {},
        cooldowns: {},
        passives: (p.passives || []).slice(),
        relics: activeRelics,
        critChance: baseCrit,
        bondAssist: activeAssist,
        bondAssistUsed: false,
        hasManaCycle: !!p.manaCycle,
        hasEclipseWand: !!p.eclipseWand,
        wandActive: false,
        wandCooldown: 0,
        overcastMode: 0,
        palaceLeft: p.palaceCharges != null ? p.palaceCharges : 1,
        palaceMax: p.palaceCharges != null ? p.palaceCharges : 1,
        status: {},
      };
    }

    // 故事模式存档出战：严格遵循玩家已习得的勇者之赐与阶段技能（修复假三元）
    const body = (curS.stats && curS.stats.body) || 10;
    const mind = (curS.stats && curS.stats.mind) || 15;
    const mana = (curS.stats && curS.stats.mana) || 15;
    const charm = (curS.stats && curS.stats.charm) || 10;
    const floorP = p || { hp: 120, mhp: 120, mp: 160, mmp: 160, atk: 14, matk: 34, def: 8, mdef: 10, skills: ['basic_attack', 'hand_water_surge', 'hand_ice_crystal', 'hand_ice_wall'] };

    const mhp = Math.max(Math.round(floorP.mhp * 0.85), curS.mhp || 80);
    const mmp = Math.max(Math.round(floorP.mmp * 0.85), curS.mmp || 120);
    const hp = opts.fullRestore ? mhp : Math.max(1, Math.min(mhp, curS.hp || mhp));
    const mp = opts.fullRestore ? mmp : Math.max(20, Math.min(mmp, curS.mp || mmp));

    const learned = new Set([...(curS.skills || []), ...(curS.skillsLearned || [])]);
    const age = curS.ageY || 0;
    const skillSet = new Set(['basic_attack', 'hand_water_surge', 'hand_ice_crystal', 'hand_ice_wall', 'hand_water_veil']);
    if (age >= 8) skillSet.add('hand_frost_floor');
    if (age >= 9 || (curS.lv || 1) >= 15) skillSet.add('hand_thorn_field');
    if (age >= 12 || curS.phase === 'academy' || curS.phase === 'journey' || curS.phase === 'finale') {
      skillSet.add('hand_root_shield');
      skillSet.add('remote_blind_shot');
      skillSet.add('remote_snap_spike');
    }
    if (learned.has('wind_afterimage') || learned.has('wind_step_s')) skillSet.add('sword_wind_afterimage');
    if (learned.has('root_step') || learned.has('soft_cut') || learned.has('frost_edge') || curS.phase === 'journey' || curS.phase === 'finale') {
      skillSet.add('sword_root_step');
      skillSet.add('sword_water_edge');
    }
    if (learned.has('instant_ice')) {
      skillSet.add('remote_blind_shot');
      skillSet.add('remote_snap_spike');
    }
    if (stageCfg && stageCfg.iceOnlyRule) {
      skillSet.delete('hand_water_surge');
      skillSet.delete('hand_water_veil');
      skillSet.delete('sword_water_edge');
    }

    const passives = [];
    if (learned.has('temp_sense') || learned.has('ice_sense')) passives.push('temp_sense');
    if (learned.has('root_ice')) passives.push('root_ice');
    if (learned.has('mana_calc')) passives.push('mana_calc');
    if (learned.has('frost_edge')) passives.push('frost_edge');
    if (learned.has('instant_ice')) passives.push('instant_ice');

    const hasPalace = learned.has('ice_palace');

    return {
      name: curS.alias || '希尔维亚',
      hp,
      mhp,
      mp,
      mmp,
      atk: Math.round(Math.max(floorP.atk * 0.85, (curS.atk || 8) + body * 0.35)),
      matk: Math.round(Math.max(floorP.matk * 0.85, Math.min(62, (curS.mag || 28) * 0.45 + mana * 0.35))),
      def: Math.round(Math.max(floorP.def * 0.85, (curS.pdef || 4) + charm * 0.15)),
      mdef: Math.round(Math.max(floorP.mdef * 0.85, (curS.mdef || 6) + mind * 0.18)),
      shield: 0,
      maxShield: Math.round(mhp * 0.65),
      skills: Array.from(skillSet),
      unlockedInsights: [],
      usedMaxSkills: {},
      cooldowns: {},
      passives,
      relics: activeRelics,
      critChance: baseCrit,
      bondAssist: activeAssist,
      bondAssistUsed: false,
      hasManaCycle: learned.has('mana_cycle'),
      hasEclipseWand: hasEclipseInSave(),
      wandActive: false,
      wandCooldown: 0,
      overcastMode: 0,
      palaceLeft: hasPalace ? 1 : 0,
      palaceMax: hasPalace ? 1 : 0,
      status: {},
    };
  }

  /* =========================================================
     4. 动态反应型敌方架势 AI（感知玩家龟缩、路径复读与失衡变招）
     ========================================================= */
  function decideEnemyIntent(enemy, b) {
    if (enemy.hp <= 0) {
      enemy.intent = null;
      return;
    }
    if (enemy.status && enemy.status.stagger > 0) {
      enemy.intent = {
        stance: 'STAGGERED',
        moveName: '架势失衡·气息紊乱',
        dmg: 0,
        desc: '动作被截断，本回合无法组织攻势。',
      };
      return;
    }

    const mem = b.aiMemory || {};
    const wt = b.waveTurn || b.turn;
    const ai = enemy.aiType || 'generic';
    const playerTurtling = (mem.turtleStreak || 0) >= 2 || (b.player.shield >= 45 && (mem.lastTurnDmgDealt || 0) === 0);
    const spammingRemote = mem.lastPath === 'REMOTE' && (mem.samePathStreak || 0) >= 2;
    const spammingSameSkill = (mem.sameSkillStreak || 0) >= 3;
    const spammingSameAtk = (mem.sameAtkSkillStreak || 0) >= 3;

    // 1. 贝阿特丽丝（动态融盾重劈 + 火蛇/融冰防反/抬肩重劈四拍切换）
    if (ai === 'beatrice') {
      if (playerTurtling) {
        mem.turtleStreak = 0;
        enemy.intent = {
          stance: 'HEAVY_WINDUP',
          moveName: '融冰爆炎·破壁重劈',
          dmg: 54 + (enemy.fireStacks || 0) * 6,
          elem: 'fire',
          shatterPlayerShield: true,
          addBurn: 2,
        };
        return;
      }
      if (spammingSameAtk) {
        enemy.intent = {
          stance: 'GUARD_COUNTER',
          moveName: '看破路数·烈焰剑障反劈（忌复读单招！）',
          dmg: 46 + (enemy.fireStacks || 0) * 5,
          elem: 'fire',
          shatterPlayerShield: true,
          meltIceCounter: true,
          punishRepeatAtk: mem.lastAtkSkillId,
          addBurn: 2,
          gainFire: 1,
        };
        return;
      }
      if (enemy.wasInterruptedLastTurn) {
        enemy.wasInterruptedLastTurn = false;
        enemy.intent = {
          stance: 'CLOSE_LUNGE',
          moveName: '变步近身·烈火疾斩',
          dmg: 36 + (enemy.fireStacks || 0) * 4,
          elem: 'fire',
          addBurn: 1,
        };
        return;
      }
      const step = (wt - 1) % 4;
      if (step === 0) {
        enemy.intent = {
          stance: 'HEAVY_WINDUP',
          moveName: '抬右肩·烈焰连球重劈',
          dmg: 38 + (enemy.fireStacks || 0) * 4,
          elem: 'fire',
          addBurn: 2,
          gainFire: 1,
        };
      } else if (step === 1) {
        enemy.intent = {
          stance: 'DUAL_CAST',
          moveName: '双手塑形·暴走火蛇（宜凝华冰晶冻核）',
          dmg: 36 + (enemy.fireStacks || 0) * 4,
          elem: 'fire',
          addBurn: 1,
          gainFire: 1,
        };
      } else if (step === 2) {
        enemy.intent = {
          stance: 'GUARD_COUNTER',
          moveName: '烈焰剑障·融冰防反（宜覆潮水弹浇灭，忌冰晶）',
          dmg: 32 + (enemy.fireStacks || 0) * 4,
          elem: 'fire',
          meltIceCounter: true,
        };
      } else {
        enemy.intent = {
          stance: 'HEAVY_WINDUP',
          moveName: '抬右肩·爆炎踏步重劈',
          dmg: 40 + (enemy.fireStacks || 0) * 4,
          elem: 'fire',
          addBurn: 2,
        };
      }
      return;
    }

    // 2. 罗文（8岁乱葬岗：龟缩碎壁、窄道突围、脱手旋杖袭心；已铺设地面薄冰设伏时视为战术布阵）
    if (ai === 'rowan') {
      if (playerTurtling && !(b.frostFloorTurns > 0)) {
        mem.turtleStreak = 0;
        enemy.intent = {
          stance: 'HEAVY_WINDUP',
          moveName: '血魔炸土·碎壁穿心刺',
          dmg: 78,
          elem: 'dark',
          shatterPlayerShield: true,
        };
        return;
      }
      const step = (wt - 1) % 3;
      if (step === 0) {
        enemy.intent = {
          stance: 'UNDER_SEEP',
          moveName: '晦轮银环·越位蚀心黑光',
          dmg: 60,
          bypassHalfShield: true,
          elem: 'dark',
          renoRockBlock: true,
          refractIceCrystal: true,
        };
      } else if (step === 1) {
        enemy.intent = {
          stance: 'DUAL_CAST',
          moveName: '血魔震土·石碑窄道突围',
          dmg: 50,
          elem: 'dark',
          narrowPassWindow: true,
        };
      } else {
        enemy.intent = {
          stance: 'CLOSE_LUNGE',
          moveName: '虚刺雷纳德·脱手旋杖袭心',
          dmg: 60,
          bypassHalfShield: true,
          elem: 'dark',
          thrownStaff: true,
          refractIceCrystal: true,
        };
      }
      return;
    }

    // 3. 爱丽丝（第1拍必扬尘遮眼、第4/7拍双手合拢狂岚检定：MP<22当场溃散认输！）
    if (ai === 'alice') {
      const isStormTurn = wt === 4 || (wt > 4 && (wt - 4) % 3 === 0);
      if (isStormTurn) {
        const sealed = !!(enemy.status && enemy.status.evadeSealed > 0);
        enemy.intent = {
          stance: 'DUAL_CAST',
          moveName: '双手合拢·狂躁风暴蓄力',
          dmg: sealed ? 64 : 138,
          elem: 'wind',
          mpCost: 22,
          selfFizzleIfLowMp: true,
        };
        return;
      }
      if (playerTurtling && (enemy.mp || 0) >= 18) {
        mem.turtleStreak = 0;
        enemy.intent = {
          stance: 'HEAVY_WINDUP',
          moveName: '狂岚破幕卷（粉碎护盾）',
          dmg: 68,
          elem: 'wind',
          mpCost: 12,
          shatterPlayerShield: true,
        };
        return;
      }
      const subStep = wt <= 3 ? (wt - 1) : ((wt - 5) % 2);
      if (subStep === 0) {
        enemy.intent = {
          stance: 'GUARD_COUNTER',
          moveName: '侧滑扬尘 + 绕侧风刃',
          dmg: 30,
          elem: 'wind',
          mpCost: 7,
          inflictBlind: 1,
        };
      } else if (subStep === 1) {
        enemy.intent = {
          stance: 'CLOSE_LUNGE',
          moveName: '借风掠影·透明风刃',
          dmg: 34,
          elem: 'wind',
          mpCost: 7,
        };
      } else {
        enemy.intent = {
          stance: 'HEAVY_WINDUP',
          moveName: '旋风障壁·回旋风镰',
          dmg: 38,
          elem: 'wind',
          mpCost: 7,
          inflictBlind: 1,
        };
      }
      return;
    }

    // 4. 艾诺（显微镜视力：反制盲目隔空复读、反制纯叠盾挂机、动态切空档）
    if (ai === 'aino') {
      if (spammingRemote) {
        enemy.intent = {
          stance: 'GUARD_COUNTER',
          moveName: '无瑕镜冰·预判反刺（忌隔空！）',
          dmg: 50,
          elem: 'ice',
          counterRemoteHit: true,
          scoresHit: true,
        };
        return;
      }
      if ((mem.turtleStreak || 0) >= 4) {
        mem.turtleStreak = 0;
        enemy.intent = {
          stance: 'CLOSE_LUNGE',
          moveName: '破根极寒钻刺（碎盾重击）',
          dmg: 64,
          elem: 'ice',
          shatterPlayerShield: true,
          scoresHit: true,
        };
        return;
      }
      if (enemy.wasInterruptedLastTurn) {
        enemy.wasInterruptedLastTurn = false;
        enemy.intent = {
          stance: 'CLOSE_LUNGE',
          moveName: '贴地滑冰·变向双刺',
          dmg: 56,
          elem: 'ice',
          slipStrike: true,
          scoresHit: true,
        };
        return;
      }
      const step = (wt - 1) % 3;
      if (step === 0) {
        enemy.intent = {
          stance: 'HEAVY_WINDUP',
          moveName: '破土三连冰锥（正面镜冰）',
          dmg: 52,
          elem: 'ice',
          scoresHit: true,
        };
      } else if (step === 1) {
        enemy.intent = {
          stance: 'DUAL_CAST',
          moveName: '双手压地·极寒双翼刺阵',
          dmg: 68,
          elem: 'ice',
          slipStrike: true,
          scoresHit: true,
        };
      } else {
        enemy.intent = {
          stance: 'CLOSE_LUNGE',
          moveName: '贴地滑冰·近身双刺',
          dmg: 56,
          elem: 'ice',
          slipStrike: true,
          scoresHit: true,
        };
      }
      return;
    }

    // 5. 诺艾儿（残血水垫必入脚底冰缝暗流翻盘杀 + 反隔空与反单招复读尺量水幕）
    if (ai === 'noelle') {
      if (!enemy.seepSevered && (enemy.hp <= 170 || (enemy.mp != null && enemy.mp <= 40) || playerTurtling)) {
        enemy.intent = {
          stance: 'UNDER_SEEP',
          moveName: '残魔退守（脚底冰缝暗流穿心！）',
          dmg: playerTurtling ? 195 : 52,
          bypassAllShield: playerTurtling,
          trapDmg: 205,
          elem: 'water',
          mpCost: 12,
          ambushTrap: true,
        };
        return;
      }
      if (spammingRemote || enemy.wasInterruptedLastTurn) {
        enemy.wasInterruptedLastTurn = false;
        enemy.intent = {
          stance: 'GUARD_COUNTER',
          moveName: '纸薄水膜截凝 + 反切水刃',
          dmg: 46,
          elem: 'water',
          mpCost: 6,
          refreshCurtain: 52,
          counterRemoteHit: true,
        };
        return;
      }
      if (spammingSameAtk) {
        enemy.intent = {
          stance: 'GUARD_COUNTER',
          moveName: '方程预演·叠层尺量水幕',
          dmg: 48,
          elem: 'water',
          mpCost: 6,
          refreshCurtain: 76,
          punishRepeatAtk: mem.lastAtkSkillId,
        };
        return;
      }
      const step = (wt - 1) % 3;
      if (step === 1) {
        enemy.intent = {
          stance: 'DUAL_CAST',
          moveName: '等距后撤·双幕收口水刃',
          dmg: 54,
          elem: 'water',
          mpCost: 8,
          refreshCurtain: 44,
        };
      } else {
        enemy.intent = {
          stance: 'GUARD_COUNTER',
          moveName: '尺量零留白水幕 + 平切水刃',
          dmg: 44,
          elem: 'water',
          mpCost: 6,
          refreshCurtain: 52,
        };
      }
      return;
    }

    // 6. 灰棘狼群 & 霜脊影豺
    if (ai === 'pack_wolf') {
      if (enemy.id === 'wolf_alpha' && wt % 2 === 1) {
        enemy.intent = {
          stance: 'DUAL_CAST',
          moveName: '仰首群嚎·凶性激发',
          dmg: 42,
          elem: 'wind',
          buffPack: 10,
        };
      } else {
        enemy.intent = {
          stance: 'CLOSE_LUNGE',
          moveName: '群狼合围撕咬',
          dmg: enemy.atk + 8,
          elem: 'phys',
        };
      }
      return;
    }

    if (ai === 'jackal' || ai === 'jackal_minor') {
      if (ai === 'jackal') {
        // 影豺若未被卸力破招，自动恢复1层疾影闪避
        if (!enemy.wasInterruptedLastTurn && !enemy.evadeBrokenThisTurn) {
          enemy.evadeCharges = enemy.maxEvadeCharges || 1;
        }
        enemy.evadeBrokenThisTurn = false;
        enemy.wasInterruptedLastTurn = false;

        if (playerTurtling || spammingSameSkill) {
          mem.turtleStreak = 0;
          enemy.intent = {
            stance: 'HEAVY_WINDUP',
            moveName: '裂甲暗影重爪（撕碎护盾）',
            dmg: 68,
            elem: 'phys',
            shatterPlayerShield: true,
          };
          return;
        }
      }
      const step = (wt - 1) % 3;
      if (step === 2 && ai === 'jackal') {
        enemy.intent = {
          stance: 'DUAL_CAST',
          moveName: '霜脊蓄寒·冰刺喷吐',
          dmg: 64,
          elem: 'ice',
        };
      } else {
        enemy.intent = {
          stance: 'CLOSE_LUNGE',
          moveName: '银影腾空·锁喉扑杀',
          dmg: ai === 'jackal' ? 62 : 42,
          elem: 'phys',
        };
      }
      return;
    }

    // 7. 赫兰冻土重甲兽 & 霜渊裂地兽领主
    if (ai === 'hulan_brute') {
      if (spammingRemote) {
        enemy.intent = {
          stance: 'GUARD_COUNTER',
          moveName: '冻土岩刺守御·反震撞箱',
          dmg: 50,
          crateDmg: 42,
          counterRemoteHit: true,
          elem: 'earth',
        };
        return;
      }
      const step = (wt - 1) % 2;
      if (step === 0) {
        enemy.intent = {
          stance: 'DUAL_CAST',
          moveName: '冻土聚甲 + 蓄力撞击药箱',
          dmg: 44,
          crateDmg: 42,
          gainShield: 45,
          elem: 'earth',
        };
      } else {
        enemy.intent = {
          stance: 'GUARD_COUNTER',
          moveName: '厚岩缩甲·蛮冲医疗药箱',
          dmg: 48,
          crateDmg: 42,
          shatterPlayerShield: playerTurtling,
          elem: 'earth',
        };
      }
      return;
    }

    if (ai === 'hulan_lord') {
      if (spammingRemote) {
        enemy.intent = {
          stance: 'GUARD_COUNTER',
          moveName: '极寒岩壁防反（反震药箱！）',
          dmg: 68,
          crateDmg: 40,
          counterRemoteHit: true,
          gainShield: 70,
          elem: 'earth',
        };
        return;
      }
      if (playerTurtling || spammingSameSkill) {
        mem.turtleStreak = 0;
        enemy.intent = {
          stance: 'HEAVY_WINDUP',
          moveName: '崩山碎盾踏（摧毁护盾与药箱！）',
          dmg: 76,
          crateDmg: 48,
          shatterPlayerShield: true,
          gainShield: 75,
          elem: 'earth',
        };
        return;
      }
      enemy.wasInterruptedLastTurn = false;
      // 第 1、3 回合亮出双手聚寒空档，让无冰宫玩家也能连续截断引落两记艾诺冰枪震裂晶核！
      const step = (wt - 1) % 4;
      if (step === 0 || step === 2) {
        enemy.intent = {
          stance: 'DUAL_CAST',
          moveName: '双臂聚寒·极北霜岩风暴',
          dmg: 72,
          crateDmg: 36,
          gainShield: 80,
          elem: 'ice',
        };
      } else if (step === 1) {
        enemy.intent = {
          stance: 'GUARD_COUNTER',
          moveName: '冻甲壁垒·冰峡崩震（波及药箱）',
          dmg: 64,
          crateDmg: 36,
          counterRemoteHit: true,
          elem: 'earth',
        };
      } else {
        enemy.intent = {
          stance: 'CLOSE_LUNGE',
          moveName: '裂地横扫扑击',
          dmg: 60,
          crateDmg: 24,
          elem: 'phys',
        };
      }
      return;
    }

    const gStep = (wt - 1) % 3;
    enemy.intent = gStep === 1
      ? { stance: 'DUAL_CAST', moveName: '蓄势咆哮猛击', dmg: Math.round(enemy.atk * 1.25), elem: enemy.elem || 'phys' }
      : gStep === 2
        ? { stance: 'CLOSE_LUNGE', moveName: '贴身疾扑', dmg: Math.round(enemy.atk * 1.1), elem: 'phys' }
        : { stance: 'HEAVY_WINDUP', moveName: '正面强袭', dmg: enemy.atk, elem: enemy.elem || 'phys' };
  }

  function predictNextIntentTendency(enemy, b) {
    if (!enemy || enemy.hp <= 0) return '已失去战意';
    if (enemy.intent && enemy.intent.stance === 'STAGGERED') {
      return '失衡恢复中（准备重新蓄势反扑）';
    }
    const cloneE = Object.assign({}, enemy, { status: Object.assign({}, enemy.status || {}) });
    delete cloneE.status.stagger;
    const fakeB = Object.assign({}, b, {
      waveTurn: (b.waveTurn || b.turn || 1) + 1,
      aiMemory: Object.assign({}, b.aiMemory || {})
    });
    decideEnemyIntent(cloneE, fakeB);
    const nextSt = cloneE.intent ? cloneE.intent.stance : 'HEAVY_WINDUP';
    const labelMap = {
      DUAL_CAST: '双手控场（可留【隔空瞬凝】破招）',
      CLOSE_LUNGE: '贴身突袭（可备【霁馆剑步】闪反）',
      HEAVY_WINDUP: '蓄力重击（宜提前堆叠护盾或开冰宫）',
      GUARD_COUNTER: '严密防反（宜切【经手构筑】正面破防）',
      UNDER_SEEP: '诡道暗流（须防脚底陷阱，备残像或冰宫）'
    };
    return labelMap[nextSt] || '常规试探';
  }

  /* =========================================================
     5. 魔战循环耗蓝与伤害精算核心（严格实装原著双公式）
     ========================================================= */
  function computeSkillApCost(bState, skill) {
    if (!skill) return 0;
    const baseAp = skill.ap || 0;
    if (bState && bState.turn === 1 && !bState._handkerchiefFreeRemoteUsed &&
        hasRelic(bState.player, 'aino_academy_handkerchief') && skill.path === 'REMOTE') {
      return 0;
    }
    return baseAp;
  }

  function computeBaseMpCost(player, skill) {
    let base = (skill && skill.mp) || 0;
    if (base > 0 && player.passives && player.passives.includes('mana_calc')) {
      base = Math.max(1, Math.floor(base * 0.85));
    }
    if (base > 0 && hasRelic(player, 'noelle_manuscript') && skill.atkKind === 'matk') {
      base = Math.max(1, Math.floor(base * 0.8));
    }
    return base;
  }

  function computeOvercastPowerMp(player, skill) {
    if (!skill) return 0;
    const base = computeBaseMpCost(player, skill);
    let commit = base;
    if (player.hasManaCycle && !skill.noOvercast && skill.atkKind === 'matk' && skill.power > 0) {
      if (player.overcastMode === 1) {
        commit = Math.max(base, Math.floor(player.mp * 0.5));
      } else if (player.overcastMode === 2) {
        commit = Math.max(base, player.mp);
      }
    }
    if (player.wandActive && skill.power > 0 && !skill.aoe && skill.atkKind === 'matk') {
      if (player.overcastMode !== 2) {
        commit += 46;
      }
    }
    return commit;
  }

  function computeSkillMpCost(player, skill) {
    if (!skill) return 0;
    if (player.status && player.status.zeroMpThisTurn) return 0;
    const base = computeBaseMpCost(player, skill);
    let commit = computeOvercastPowerMp(player, skill);
    // 【省魔手稿】：魔战倾注过载额外消耗减半，保留一半过载缓冲
    if (hasRelic(player, 'noelle_manuscript') && commit > base) {
      commit = base + Math.ceil((commit - base) * 0.5);
    }
    return commit;
  }

  // 原著魔战循环公式②：严格仅限魔法伤害额外增加 原伤害 × (该魔法消耗 ÷ 总魔力值)
  function computeManaCycleMultiplier(player, mpSpent, skill) {
    if (!player.hasManaCycle || !skill || skill.power <= 0 || skill.atkKind !== 'matk' || skill.elem === 'phys' || mpSpent <= 0) {
      return 1.0;
    }
    return 1.0 + mpSpent / Math.max(1, player.mmp);
  }

  function getPlayerCritChance(player, skill) {
    let rate = Number(player && player.critChance) || 0;
    if (skill && skill.path === 'SWORD' && hasRelic(player, 'ebony_sword')) {
      rate += 0.25;
    }
    return Math.max(0, Math.min(0.95, rate));
  }

  function estimateSkillDamage(bState, skill, targetEnemy, opts) {
    opts = opts || {};
    const p = bState.player;
    if (!skill || !skill.power || skill.power <= 0) {
      return { dmg: 0, mult: 1, mcMult: 1, mpCost: opts.mpCost != null ? opts.mpCost : computeSkillMpCost(p, skill), willInterrupt: false, willRiposte: false };
    }
    const e = targetEnemy || getPrimaryAliveEnemy(bState);
    if (!e) return { dmg: 0, mult: 1, mcMult: 1, mpCost: 0, willInterrupt: false, willRiposte: false };

    const mpCost = opts.mpCost != null ? opts.mpCost : computeSkillMpCost(p, skill);
    const powerMp = opts.powerMp != null ? opts.powerMp : computeOvercastPowerMp(p, skill);
    const mcMult = computeManaCycleMultiplier(p, powerMp, skill);
    const stance = e.intent ? e.intent.stance : 'HEAVY_WINDUP';
    const wandOn = !!(p.wandActive && !skill.aoe && skill.atkKind === 'matk');

    let atkStat = p.matk;
    if (skill.atkKind === 'atk') atkStat = p.atk;
    else if (skill.atkKind === 'hybrid') atkStat = p.atk * 0.92 + p.matk * 0.58;

    let pwr = skill.power;
    let willInterrupt = false;
    let willRiposte = false;
    let stanceMod = 1.0;

    if (skill.path === 'REMOTE') {
      // 严禁把 weaknessExposed 当作永久无视防反外挂！唯敌方处于 DUAL_CAST 才触发隔空截断！
      if (stance === 'DUAL_CAST') {
        pwr = skill.interruptPower || skill.power * 1.85;
        willInterrupt = true;
        stanceMod = 1.15;
      } else if (stance === 'GUARD_COUNTER' && !wandOn) {
        stanceMod = 0.28; // 严密防反下盲目丢隔空瞬凝仅 28% 刮痧！
      }
      if (p.passives && p.passives.includes('instant_ice')) {
        stanceMod *= (willInterrupt ? 1.22 : 1.12);
      }
    } else if (skill.path === 'SWORD') {
      if (skill.counterLunge && (stance === 'CLOSE_LUNGE' || stance === 'STAGGERED' || p.status.poise > 0)) {
        pwr = skill.lungeRipostePower || skill.power * 1.6;
        willRiposte = stance === 'CLOSE_LUNGE';
      }
      if (p.status.poise > 0) stanceMod *= 1.35;
      if (p.passives && p.passives.includes('frost_edge')) {
        stanceMod *= 1.18;
      }
      if (hasRelic(p, 'ebony_sword')) {
        stanceMod *= 1.15;
      }
    } else if (skill.path === 'INSIGHT') {
      if (skill.forceInterrupt && stance !== 'STAGGERED') willInterrupt = true;
      if (skill.interruptWindupOnly && stance === 'HEAVY_WINDUP') willInterrupt = true;
      stanceMod = 1.15;
    }

    // 铭记增伤与连携追击窗口（1.35×）
    if (skill.elem === 'ice' && hasRelic(p, 'aino_academy_handkerchief')) {
      stanceMod *= 1.2;
    }
    if ((skill.elem === 'water' || skill.elem === 'wind') && hasRelic(p, 'shell_pin')) {
      stanceMod *= 1.18;
    }
    const chainApplied = !!(p.status && p.status.breakChain > 0 && skill.id !== 'basic_attack');
    if (chainApplied) {
      stanceMod *= 1.35;
    }

    // 单次临时破绽印记 flawToken（打中一次立即消耗清除，且不覆盖 GUARD_COUNTER 对盲目 REMOTE 的惩罚）
    if (e.flawToken > 0 && !(skill.path === 'REMOTE' && stance === 'GUARD_COUNTER')) {
      stanceMod *= 1.2;
    }

    if (stance === 'STAGGERED') stanceMod *= 1.25;
    if (e.status && e.status.vuln > 0) stanceMod *= 1.32;

    // 贝阿特丽丝三层烈焰斗气与架势相克（双火蛇需冰晶冻核，融冰剑障需水弹浇灭）
    if (e.fireAura > 0 && !skill.shatterFireAura && skill.path !== 'INSIGHT') {
      stanceMod *= (1.0 - 0.10 * Math.min(3, e.fireAura));
    }
    if (e.aiType === 'beatrice' && skill.path !== 'INSIGHT') {
      if (stance === 'DUAL_CAST') {
        if (skill.elem === 'ice') stanceMod *= 1.32;
        else if (skill.elem === 'water') stanceMod *= 0.58;
      } else if (stance === 'GUARD_COUNTER' && e.intent && e.intent.meltIceCounter && skill.elem === 'ice') {
        stanceMod *= 0.28;
      }
    }
    if (e.intent && e.intent.punishRepeatAtk && e.intent.punishRepeatAtk === skill.id) {
      stanceMod *= 0.52;
    }

    // 爱丽丝微风缓冲：魔力尚存时借气流缓冲伤害，未被十字冰栏封印风轨前规避大半地面冰棘
    if (e.windCushion && (e.mp || 0) > 0 && skill.path !== 'INSIGHT') {
      stanceMod *= 0.78;
    }
    if (e.aiType === 'alice' && skill.aoe && !(e.status && e.status.evadeSealed > 0)) {
      stanceMod *= 0.42;
    }
    // 群狼合围牵制：场上存活群狼 >= 3 只时，单点技能受侧翼合围干扰威力大减（逼用范围冰棘破阵）
    const alivePackCount = bState.enemies ? bState.enemies.filter(x => x.hp > 0 && x.aiType === 'pack_wolf').length : 0;
    if (alivePackCount >= 3 && !skill.aoe) {
      stanceMod *= 0.42;
    }

    const elemMult = getElemMult(skill.elem, e.elem);

    // 艾诺正面无气泡镜冰阻挡非破招攻击
    if (e.mirrorGuard && !skill.bypassMirror && !willInterrupt) {
      return { dmg: 0, mult: elemMult, mcMult, mpCost, willInterrupt: false, willRiposte: false, mirrorBlocked: true, chainApplied };
    }

    let defVal = skill.atkKind === 'atk' ? e.def : skill.atkKind === 'hybrid' ? Math.min(e.def, e.mdef) * 0.7 : e.mdef;
    if (wandOn) {
      // 晦轮杖折光蚀穿：穿透 70% 防御并附带 1.22x 折光伤害加成
      defVal *= 0.3;
      stanceMod *= 1.22;
    }
    if (skill.elem === 'ice' && p.status && p.status.frostPierce > 0 && hasRelic(p, 'aino_frost_shard')) {
      defVal *= 0.75;
    }

    const raw = atkStat * pwr * mcMult * stanceMod * elemMult - defVal * 0.75;
    return {
      dmg: Math.max(2, Math.round(raw)),
      mult: elemMult,
      mcMult,
      mpCost,
      willInterrupt,
      willRiposte,
      wandRefract: wandOn,
      chainApplied,
    };
  }

  function computeTacticalForecast(bState, skill, targetEnemy) {
    if (!bState || !skill) return null;
    const p = bState.player;
    const e = targetEnemy || getPrimaryAliveEnemy(bState);
    if (!e) return null;
    const apCost = computeSkillApCost(bState, skill);
    const mpCost = computeSkillMpCost(p, skill);
    const stance = e.intent ? e.intent.stance : 'HEAVY_WINDUP';
    const wandOn = !!(p.wandActive && !skill.aoe && skill.atkKind === 'matk');

    if (!skill.power || skill.power <= 0) {
      const willParry = !!(skill.dodgeLunge && stance === 'CLOSE_LUNGE');
      return {
        skillId: skill.id,
        apCost,
        mpCost,
        dmgMin: 0,
        dmgMax: 0,
        elemMult: 1,
        mcMult: 1,
        manaReturn: 0,
        critChance: 0,
        willInterrupt: false,
        willRiposte: willParry,
        guardPenalty: false,
        mirrorBlocked: false,
        evadeBlocked: false,
        chainApplied: false,
        headline: willParry ? '⚡ 触发卸力闪反（并开启连携追击）！' : '🛡️ 稳固防线 / 战术步法',
        kind: willParry ? 'riposte' : 'utility'
      };
    }

    const est = estimateSkillDamage(bState, skill, e);
    const critChance = getPlayerCritChance(p, skill);
    const bypassEvade = !!(skill.aoe || skill.sureHit || wandOn || stance === 'STAGGERED');
    const evadeBlocked = !bypassEvade && e.evadeCharges > 0;
    const guardPenalty = (skill.path === 'REMOTE' && stance === 'GUARD_COUNTER' && !wandOn) ||
      (e.aiType === 'beatrice' && stance === 'GUARD_COUNTER' && e.intent && e.intent.meltIceCounter && skill.elem === 'ice' && skill.path !== 'INSIGHT');

    const dmgMin = (est.mirrorBlocked || evadeBlocked) ? 0 : est.dmg;
    const dmgMax = (est.mirrorBlocked || evadeBlocked) ? 0 : (critChance > 0 ? Math.round(est.dmg * 1.5) : est.dmg);

    let effShield = e.shield || 0;
    if (skill.shatterShield) effShield = 0;
    else if (skill.pierceHalfShield) effShield = Math.floor(effShield * 0.5);
    const estHpLoss = wandOn
      ? Math.min(e.hp, Math.round(dmgMin * 0.65) + Math.max(0, dmgMin - Math.round(dmgMin * 0.65) - effShield))
      : Math.min(e.hp, Math.max(0, dmgMin - effShield));

    let manaReturn = 0;
    if (p.hasManaCycle && skill.elem !== 'phys' && estHpLoss > 0) {
      manaReturn += estHpLoss;
    }
    if (est.chainApplied) {
      manaReturn += Math.round(p.mmp * 0.15) + (hasRelic(p, 'shell_pin') ? Math.round(p.mmp * 0.08) : 0);
    }

    let headline = `预计伤害 ${dmgMin}${dmgMax > dmgMin ? `~${dmgMax}` : ''}`;
    let kind = 'normal';
    if (est.mirrorBlocked) {
      headline = '🛡️ 将被正面镜冰格挡（请开冰宫或打断）';
      kind = 'warn';
    } else if (evadeBlocked) {
      headline = `💨 将被敌方闪避层抵消（余 ${e.evadeCharges} 层）`;
      kind = 'warn';
    } else if (guardPenalty) {
      headline = '⚠️ 敌方严密防反，盲丢将衰减！';
      kind = 'warn';
    } else if (est.willInterrupt) {
      headline = '💥 触发截断破招！（并激活连携追击）';
      kind = 'interrupt';
    } else if (est.willRiposte) {
      headline = '⚡ 触发卸力闪反！（并激活连携追击）';
      kind = 'riposte';
    } else if (est.chainApplied) {
      headline = '🔗 连携追击生效（1.35× 伤害 + 返蓝）！';
      kind = 'chain';
    }

    return {
      skillId: skill.id,
      apCost,
      mpCost,
      dmgMin,
      dmgMax,
      estHpLoss,
      elemMult: est.mult,
      mcMult: est.mcMult,
      manaReturn,
      critChance,
      willInterrupt: est.willInterrupt,
      willRiposte: est.willRiposte,
      guardPenalty,
      mirrorBlocked: !!est.mirrorBlocked,
      evadeBlocked,
      chainApplied: !!est.chainApplied,
      headline,
      kind
    };
  }

  /* =========================================================
     6. 战场状态与交互结算核心
     ========================================================= */
  let activeBattle = null;

  function getPrimaryAliveEnemy(b) {
    if (!b || !b.enemies) return null;
    const locked = b.enemies[b.targetIdx];
    if (locked && locked.hp > 0) return locked;
    const idx = b.enemies.findIndex(e => e.hp > 0);
    if (idx >= 0) {
      b.targetIdx = idx;
      return b.enemies[idx];
    }
    return null;
  }

  function pushLog(b, html) {
    if (!b) return;
    b.log.push(html);
    if (b.log.length > 70) b.log.shift();
    if (!b.headless && typeof document !== 'undefined') {
      const el = document.getElementById('b-log');
      if (el) {
        el.innerHTML = b.log.join('<br>');
        el.scrollTop = el.scrollHeight;
      }
    }
  }

  function spawnBanner(b, text, kind) {
    if (!b || b.headless || typeof document === 'undefined') return;
    const layer = document.getElementById('cb-callout-layer');
    if (!layer) return;
    const div = document.createElement('div');
    div.className = 'cb-banner-fx ' + (kind || 'interrupt');
    div.textContent = text;
    layer.appendChild(div);
    setTimeout(() => { if (div.parentNode) div.remove(); }, 920);
  }

  function triggerShake(b, heavy) {
    if (!b || b.headless || typeof document === 'undefined') return;
    const scr = document.getElementById('battle-screen');
    if (!scr) return;
    const cls = heavy ? 'heavy-shake' : 'hit-shake';
    scr.classList.remove('hit-shake', 'heavy-shake');
    void scr.offsetWidth;
    scr.classList.add(cls);
    setTimeout(() => scr.classList.remove(cls), 460);
  }

  function spawnCombatFloat(b, side, text, kind, enemyIdx) {
    if (!b || b.headless || typeof document === 'undefined') return;
    const layer = document.getElementById('cb-callout-layer');
    if (!layer) return;
    const div = document.createElement('div');
    div.className = 'cb-float-num ' + (kind || 'dmg');
    div.textContent = text;
    if (side === 'player') {
      div.style.left = '18%';
      div.style.top = kind === 'mp' ? '44%' : kind === 'shield' ? '36%' : '28%';
    } else {
      const total = Math.max(1, (b.enemies || []).length);
      const idx = Math.max(0, Math.min(total - 1, enemyIdx || 0));
      const pct = 40 + ((idx + 0.5) / total) * 56;
      div.style.left = pct.toFixed(1) + '%';
      div.style.top = '34%';
    }
    layer.appendChild(div);
    setTimeout(() => { if (div.parentNode) div.remove(); }, 1060);
  }

  function queueHitPulse(b, side, enemyIdx) {
    if (!b || b.headless) return;
    b._pendingHitPulses = b._pendingHitPulses || [];
    b._pendingHitPulses.push({ side, enemyIdx: enemyIdx || 0 });
  }

  function triggerPalaceFlash() {
    if (typeof document === 'undefined') return;
    const fl = document.getElementById('cb-vfx-flash');
    if (!fl) return;
    fl.classList.remove('active');
    void fl.offsetWidth;
    fl.classList.add('active');
    setTimeout(() => fl.classList.remove('active'), 480);
  }

  function initWave(b, waveIdx) {
    const sc = b.stageCfg;
    const w = sc.waves[waveIdx];
    b.waveIdx = waveIdx;
    b.waveTurn = 1;
    b.ainoSpearsFiredInWave = 0;
    delete b.palacePendingStep2;
    b.witnessActive = !!w.witnessActive;
    b.frostFloorTurns = 0;

    // 切换新波次时清理上一波的临时看破技，并为拥有冰晶宫殿的玩家重置本波 1 次审视机会！
    if (waveIdx > 0 && b.player.unlockedInsights && b.player.unlockedInsights.length) {
      const stale = new Set(b.player.unlockedInsights);
      b.player.skills = b.player.skills.filter(id => !stale.has(id));
      b.player.unlockedInsights = [];
    }
    if (b.player.palaceMax > 0) {
      b.player.palaceLeft = b.player.palaceMax;
    }

    if (w.witnessActive && b.exposure < (w.initialExposure || 25)) {
      b.exposure = w.initialExposure || 25;
    }
    b.enemies = w.enemies.map(tpl => Object.assign({}, tpl, {
      status: {},
      shield: tpl.shield || 0,
      mp: tpl.mp != null ? tpl.mp : null,
      mmp: tpl.mmp != null ? tpl.mmp : null,
      evadeCharges: tpl.evadeCharges || 0,
      maxEvadeCharges: tpl.maxEvadeCharges || 0,
      flawToken: 0,
      seepSevered: false,
      seepTriggeredOnce: false,
      wasInterruptedLastTurn: false,
      intent: null,
    }));
    b.targetIdx = 0;

    b.enemies.forEach(e => {
      if (e.aiType === 'noelle') e.shield = 52;
      decideEnemyIntent(e, b);
    });

    if (hasRelic(b.player, 'northwind_pass')) {
      const beforeS = b.player.shield;
      b.player.shield = Math.min(b.player.maxShield, b.player.shield + 12);
      if (b.player.shield > beforeS) {
        pushLog(b, `<span style="color:#a8ecff">🪪【北风堡木牌】寒铁护盾 +${b.player.shield - beforeS}（当前 ${b.player.shield}/${b.player.maxShield}）。</span>`);
      }
    }

    if (w.intro) pushLog(b, `<span style="color:#8cd4ff">${w.intro}</span>`);
  }

  function isPalaceReady(b) {
    if (!b || b.over) return false;
    if (b.player.palaceMax <= 0 || b.player.palaceLeft <= 0) return false;
    // 原著法则：须先亲眼见识敌方本波至少出手一轮（本波第 2 回合起）方可开启冰晶宫殿冻结复盘！
    return (b.waveTurn || 1) >= 2;
  }

  function createBattleState(stageCfg, opts) {
    opts = opts || {};
    const player = buildPlayerCombatant(stageCfg, opts);
    const b = {
      id: stageCfg.id,
      stageCfg,
      player,
      enemies: [],
      targetIdx: 0,
      waveIdx: 0,
      waveTurn: 1,
      totalWaves: stageCfg.waves.length,
      turn: 1,
      ap: 2,
      apMax: 3,
      apPerTurn: 2,
      over: false,
      won: false,
      grade: null,
      headless: !!opts.headless,
      done: opts.done || null,
      fromArena: !!opts.fromArena,
      _forceCrit: !!opts.forceCrit,
      // 专属战场仪表
      playerHits: 0,
      enemyHits: 0,
      sealProgress: 0,
      frostFloorTurns: 0,
      exposure: 0,
      witnessActive: false,
      exposureWarningTriggered: false,
      crateHp: stageCfg.crateRule ? 100 : null,
      crateMax: stageCfg.crateRule ? 100 : null,
      ainoResonance: 0,
      ainoSpearsFiredInWave: 0,
      // 动态 AI 行为记忆黑板
      aiMemory: {
        lastSkillId: null,
        sameSkillStreak: 0,
        lastAtkSkillId: null,
        sameAtkSkillStreak: 0,
        lastPath: null,
        samePathStreak: 0,
        lastTurnDmgDealt: 0,
        currentTurnDmgDealt: 0,
        turtleStreak: 0,
      },
      // 评分与实战验证统计
      metrics: {
        interrupts: 0,
        ripostes: 0,
        insights: 0,
        manaRecycled: 0,
        wandHits: 0,
        maxOvercastMult: 1.0,
        enemyActions: 0,
        enteredUnderSeep: false,
        manaFizzleWin: false,
      },
      palaceInspectedWaves: {},
      log: [],
    };
    initWave(b, 0);
    if (hasRelic(b.player, 'alice_flower_cake')) {
      b.player.status.afterimage = (b.player.status.afterimage || 0) + 1;
      pushLog(b, `<span style="color:#9ef2c8">🌼【风之花饼】袖间清香微散，开局自带 1 层「风行残像」！</span>`);
    }
    if (b.player.relics && b.player.relics.length) {
      const api = getRelicsApi();
      const names = b.player.relics.map(id => (api && api.RELICS && api.RELICS[id] ? `${api.RELICS[id].icon}${api.RELICS[id].name}` : id)).join(' · ');
      pushLog(b, `<span style="color:#d6c8f5">✦ 随身铭记已生效：${names}</span>`);
    }
    return b;
  }

  function setOvercast(mode, b) {
    b = b || activeBattle;
    if (!b || b.over) return false;
    if (!b.player.hasManaCycle) return false;
    b.player.overcastMode = Math.max(0, Math.min(2, mode | 0));
    if (!b.headless) renderCombatUI();
    return true;
  }

  function toggleEclipseWand(forceVal, b) {
    b = b || activeBattle;
    if (!b || b.over) return false;
    const p = b.player;
    if (!p.hasEclipseWand) return false;
    if (p.wandCooldown > 0 && forceVal !== false) {
      pushLog(b, `<span style="color:#b8a8d8">🪄 晦轮杖银环余震未平（冷却剩余 ${p.wandCooldown} 回合）。</span>`);
      return false;
    }
    p.wandActive = forceVal !== undefined ? !!forceVal : !p.wandActive;
    if (p.wandActive) {
      if (b.witnessActive) {
        b.exposure = Math.min(100, b.exposure + 25);
        if (b.exposure >= 70) b.exposureWarningTriggered = true;
      }
      pushLog(b, `<span style="color:#d6a8ff">🪄 催动「晦轮杖」暗银细环：下一次单点魔法附带【折光蚀穿】（穿透65%护盾与70%法抗，额外耗蓝46 MP，冷却2回合）！${b.witnessActive ? `（⚠️ 耳目附近拔杖引动异象，暴露风险升至 ${b.exposure}%！）` : ''}</span>`);
      spawnBanner(b, '🪄 晦轮杖 · 银环折光', 'wand');
      if (b.witnessActive && b.exposure >= 100) {
        finishBattle(b, false, 'exposed');
        return false;
      }
    } else {
      pushLog(b, `<span style="opacity:.8">🪄 收敛晦轮杖银环微光。</span>`);
    }
    if (!b.headless) renderCombatUI();
    return p.wandActive;
  }

  function getCurrentPalaceConfig(b) {
    const sc = b.stageCfg;
    if (sc.palaceByWave && sc.palaceByWave[b.waveIdx]) return sc.palaceByWave[b.waveIdx];
    if (sc.palace) return sc.palace;
    const e = getPrimaryAliveEnemy(b);
    const nm = e ? e.name : '敌方';
    return {
      sceneText: `意识沉入冰晶宫殿，飞溅尘屑与风声凝固，${nm}的发力姿态被完整冻结。`,
      clues: [
        { id: 'decoy_a', text: `表面流转的寻常魔力余波正随呼吸轻轻起伏`, correct: false, feedback: '表面余波并无异常。' },
        { id: 'true_flaw', text: `前踏发力瞬间，支撑脚踝外侧重心明显悬空`, correct: true, feedback: '观察准确！支撑脚重心已锁死！' },
        { id: 'decoy_b', text: `身后十步外的枯枝被掠过的阵风吹得微颤`, correct: false, feedback: '只是寻常林风。' },
      ],
      deductions: [
        { id: 'decoy_d', text: `原地等待对方收招，再以普通斩击正面硬拼`, correct: false, feedback: '错失转瞬即逝的重心死角。' },
        { id: 'true_d', text: `将寒霜精准打入支撑脚死角，截断发力链条`, correct: true, unlockSkill: 'insight_generic_flaw', feedback: '推演完成！锁定支撑死角！' },
      ],
    };
  }

  // 支持两步推理核验：本波第 2 回合起可用，且与弹窗第 1 步锁定扣次机制无缝衔接
  function inspectClue(clueId, deductionId, b) {
    if (deductionId && typeof deductionId === 'object') {
      b = deductionId;
      deductionId = null;
    }
    b = b || activeBattle;
    if (!b || b.over) return { ok: false, reason: 'no_battle' };

    const fromPendingStep2 = !!(b.palacePendingStep2 && b.palacePendingStep2.clueId === clueId);
    if (!fromPendingStep2) {
      if ((b.waveTurn || 1) < 2) {
        return { ok: false, reason: 'gathering_turn1' };
      }
      if (b.player.palaceLeft <= 0) {
        return { ok: false, reason: 'no_charges' };
      }
    }

    const pCfg = getCurrentPalaceConfig(b);
    const clue = (pCfg.clues || []).find(c => c.id === clueId);
    if (!clue) return { ok: false, reason: 'bad_clue' };

    if (fromPendingStep2) {
      delete b.palacePendingStep2;
    } else {
      b.player.palaceLeft -= 1;
    }

    if (!clue.correct) {
      // 选错观察点有真实战术代价：分神损耗 1 AP（若当前有 AP）
      if (b.ap > 0) b.ap -= 1;
      pushLog(b, `<span style="color:#ffb8c0">❄️【冰晶宫殿·误判】${clue.feedback}（时停分神损耗 1 AP！）</span>`);
      if (!b.headless) renderCombatUI();
      return { ok: true, correct: false, step: 1, feedback: clue.feedback };
    }

    // 第 2 步推演核验
    const dList = pCfg.deductions || [];
    let ded = null;
    if (dList.length) {
      if (deductionId) {
        ded = dList.find(d => d.id === deductionId);
      } else {
        ded = dList.find(d => d.correct);
      }
      if (!ded || !ded.correct) {
        if (b.ap > 0) b.ap -= 1;
        const fb = ded ? ded.feedback : '推演方向偏差，未能形成有效反制。';
        pushLog(b, `<span style="color:#ffb8c0">❄️【冰晶宫殿·推演偏差】${fb}（损耗 1 AP！）</span>`);
        if (!b.headless) renderCombatUI();
        return { ok: true, correct: false, step: 2, feedback: fb };
      }
    }

    const skId = (ded && ded.unlockSkill) || clue.unlockSkill || 'insight_generic_flaw';
    b.metrics.insights += 1;
    b.palaceInspectedWaves[b.waveIdx] = true;
    if (!b.player.skills.includes(skId)) {
      b.player.skills.push(skId);
      b.player.unlockedInsights.push(skId);
    }
    delete b.player.usedMaxSkills[skId];

    // 仅赋予 1 层单次破绽印记 flawToken（触发一次攻击后立即销毁，绝不永久破坏 GUARD_COUNTER）
    const target = getPrimaryAliveEnemy(b);
    if (target) {
      target.flawToken = 1;
    }

    const finalFb = (ded && ded.feedback) || clue.feedback;
    pushLog(b, `<span style="color:#9beeff">❄️【冰晶宫殿·两步看破】${finalFb} 解锁「${TACTICAL_SKILLS[skId].name}」！</span>`);
    if (hasRelic(b.player, 'frost_cipher')) {
      const recMp = Math.max(10, Math.round(b.player.mmp * 0.18));
      const beforeMp = b.player.mp;
      b.player.mp = Math.min(b.player.mmp, b.player.mp + recMp);
      b.ap = Math.min(b.apMax, b.ap + 1);
      pushLog(b, `<span style="color:#9beeff">💠【霜封暗记】看破瞬间魔脉回涌 +${b.player.mp - beforeMp} MP、+1 AP！</span>`);
    }
    spawnBanner(b, '❄️ 冰晶宫殿 · 破绽锁定！', 'interrupt');
    if (!b.headless && typeof global.sfx === 'function') global.sfx('egg');
    if (!b.headless) renderCombatUI();
    return { ok: true, correct: true, unlockedSkill: skId, feedback: finalFb };
  }

  function dealDamageToEnemy(b, enemy, dmg, opts) {
    opts = opts || {};
    if (opts.shatterShield && enemy.shield > 0) {
      pushLog(b, `<span style="color:#7ee8ff">💥 击碎了 ${enemy.name} 的 ${enemy.shield} 点护盾！</span>`);
      enemy.shield = 0;
    }

    let rem = dmg;
    let shieldAbsorbed = 0;
    if (enemy.shield > 0) {
      if (opts.wandRefract) {
        // 晦轮杖折光蚀穿：65% 伤害直接穿透护盾打本体，35% 削减护盾
        const bypassDmg = Math.round(rem * 0.65);
        const onShield = rem - bypassDmg;
        const blk = Math.min(enemy.shield, onShield);
        enemy.shield -= blk;
        shieldAbsorbed = blk;
        rem = bypassDmg + (onShield - blk);
      } else if (opts.pierceHalfShield) {
        const effShield = Math.floor(enemy.shield * 0.5);
        const blk = Math.min(effShield, rem);
        enemy.shield -= blk;
        shieldAbsorbed = blk;
        rem -= blk;
      } else {
        const blk = Math.min(enemy.shield, rem);
        enemy.shield -= blk;
        shieldAbsorbed = blk;
        rem -= blk;
      }
    }

    // 诺艾儿二阶段保护（尺量应急水垫）：首次濒临 165 HP 以下且暗流未被斩断时，稳守 165 HP 并切入【冰缝暗流陷阱】！
    if (enemy.aiType === 'noelle' && !enemy.seepTriggeredOnce && !enemy.seepSevered && !opts.severSeep && enemy.hp > 165 && enemy.hp - rem <= 165) {
      const actualHpLoss = enemy.hp - 165;
      enemy.hp = 165;
      enemy.seepTriggeredOnce = true;
      if (enemy.mp != null) enemy.mp = Math.max(0, enemy.mp - 18);
      enemy.shield = Math.max(enemy.shield, 60);
      delete enemy.status.stagger;
      enemy.intent = {
        stance: 'UNDER_SEEP',
        moveName: '残魔退守（脚底冰缝暗流穿心！）',
        dmg: 52,
        trapDmg: 205,
        elem: 'water',
        mpCost: 12,
        ambushTrap: true,
      };
      b.metrics.enteredUnderSeep = true;
      spawnBanner(b, '💧 冰面暗流 · 杀阵成型！', 'danger');
      pushLog(b, `<span style="color:#7ee8ff;font-weight:700">💧【尺量应急水垫】诺艾儿借薄水垫卸开致命追击退至十五米外（稳守 165 HP + 60 水幕），冰缝下的暗水线已彻底锁死你的脚底！</span>`);
      return { actualHpLoss, shieldAbsorbed };
    }

    const minHp = enemy.nonLethalSpar ? 1 : 0;
    const maxCanLose = Math.max(0, enemy.hp - minHp);
    const actualHpLoss = Math.min(maxCanLose, rem);
    enemy.hp = Math.max(minHp, enemy.hp - rem);

    return { actualHpLoss, shieldAbsorbed };
  }

  function useSkill(skillId, targetIdx, b) {
    b = b || activeBattle;
    if (!b || b.over) return { ok: false, reason: 'over' };
    const p = b.player;
    const sk = TACTICAL_SKILLS[skillId];
    if (!sk || !p.skills.includes(skillId)) return { ok: false, reason: 'locked' };
    if (sk.maxUses && (p.usedMaxSkills[skillId] || 0) >= sk.maxUses) return { ok: false, reason: 'max_uses' };
    if ((p.cooldowns[skillId] || 0) > 0) return { ok: false, reason: 'cooldown' };
    const apCost = computeSkillApCost(b, sk);
    if (b.ap < apCost) return { ok: false, reason: 'no_ap' };

    const mpCost = computeSkillMpCost(p, sk);
    if (p.mp < mpCost) return { ok: false, reason: 'no_mp' };

    const powerMp = computeOvercastPowerMp(p, sk);
    const mcMult = computeManaCycleMultiplier(p, powerMp, sk);
    if (mcMult > b.metrics.maxOvercastMult) b.metrics.maxOvercastMult = mcMult;

    if (targetIdx != null && b.enemies[targetIdx] && b.enemies[targetIdx].hp > 0) {
      b.targetIdx = targetIdx;
    }
    const primary = getPrimaryAliveEnemy(b);
    if (!primary) return { ok: false, reason: 'no_target' };

    const usedWand = !!(p.wandActive && sk.power > 0 && !sk.aoe && sk.atkKind === 'matk');

    // 扣除资源与记录冷却
    if (apCost === 0 && sk.ap > 0 && sk.path === 'REMOTE' && b.turn === 1 && !b._handkerchiefFreeRemoteUsed && hasRelic(p, 'aino_academy_handkerchief')) {
      b._handkerchiefFreeRemoteUsed = true;
      pushLog(b, `<span style="color:#bfefff">🧣【雪纹手帕】首回合初次【隔空瞬凝】免除 AP 消耗！</span>`);
    }
    b.ap -= apCost;
    p.mp = Math.max(0, p.mp - mpCost);
    if (sk.maxUses) p.usedMaxSkills[skillId] = (p.usedMaxSkills[skillId] || 0) + 1;
    if (sk.cooldown) p.cooldowns[skillId] = sk.cooldown;
    if (usedWand) {
      p.wandActive = false;
      p.wandCooldown = 2;
      b.metrics.wandHits += 1;
    }

    // 记录 AI 记忆黑板（含同技能与跨护盾同攻击技能复读监测）
    if (b.aiMemory.lastSkillId === skillId) b.aiMemory.sameSkillStreak += 1;
    else { b.aiMemory.lastSkillId = skillId; b.aiMemory.sameSkillStreak = 1; }
    if (sk.power > 0) {
      if (b.aiMemory.lastAtkSkillId === skillId) b.aiMemory.sameAtkSkillStreak += 1;
      else { b.aiMemory.lastAtkSkillId = skillId; b.aiMemory.sameAtkSkillStreak = 1; }
      if (b.aiMemory.lastPath === sk.path) b.aiMemory.samePathStreak += 1;
      else { b.aiMemory.lastPath = sk.path; b.aiMemory.samePathStreak = 1; }
    }

    // 暴露度结算
    if (b.witnessActive) {
      let expDelta = sk.exposure || 0;
      if (usedWand) expDelta += 55;
      if (hasRelic(p, 'ebony_sword') && sk.path === 'SWORD') {
        expDelta = Math.min(0, expDelta);
      }
      b.exposure = Math.max(0, Math.min(100, b.exposure + expDelta));
      if (expDelta > 0) {
        pushLog(b, `<span style="color:#ffb37a">👁️ 魔力外显惊动林外耳目，暴露风险 +${expDelta}%（当前 ${b.exposure}%）！</span>`);
      } else if (expDelta < 0) {
        pushLog(b, `<span style="color:#88e8b0">🍃 剑锋化水收痕，暴露风险 ${expDelta}%（当前 ${b.exposure}%）。</span>`);
      }
      if (b.exposure >= 100) {
        b.exposureWarningTriggered = true;
        pushLog(b, `<span style="color:#ff6b7a;font-weight:700">🚨 暴露风险达 100%！「极光」小队已循着魔力波动冲入林间，行踪彻底败露！</span>`);
        finishBattle(b, false, 'exposed');
        return { ok: true, exposedFail: true };
      }
      if (b.exposure >= 70) b.exposureWarningTriggered = true;
    }

    // 自身净化/护盾/场地效果（注意水系先冲净 blind 再执行命中判定！）
    const washedBlindJustNow = !!(sk.clearBlind && p.status.blind > 0);
    if (washedBlindJustNow) {
      delete p.status.blind;
      pushLog(b, `<span style="color:#7ec8ff">💧 水流冲净了眼前的扬尘，视野恢复清晰！</span>`);
    }
    if (sk.clearDebuff) {
      delete p.status.blind;
      delete p.status.burn;
    }
    if (sk.layFrostFloor) {
      b.frostFloorTurns = Math.max(b.frostFloorTurns || 0, sk.layFrostFloor);
      b.aiMemory.turtleStreak = 0;
      pushLog(b, `<span style="color:#9beeff">❄️ 一层极薄的冰面沿着乱葬岗松土悄然铺开（持续 ${b.frostFloorTurns} 回合）！</span>`);
    }
    if (sk.shieldBase) {
      let gain = Math.round(sk.shieldBase + p.matk * (sk.shieldScale || 0));
      if (sk.elem === 'ice' && p.passives.includes('root_ice')) gain = Math.round(gain * 1.2);
      if (hasRelic(p, 'cross')) gain = Math.round(gain * 1.2);
      const beforeS = p.shield;
      p.shield = Math.min(p.maxShield, p.shield + gain);
      const shieldDelta = p.shield - beforeS;
      if (shieldDelta > 0) spawnCombatFloat(b, 'player', `+${shieldDelta} 护盾`, 'shield');
      pushLog(b, `<span style="color:#7ef2e8">🛡️ 「${sk.name}」构筑 ${shieldDelta} 点护盾（当前 ${p.shield}/${p.maxShield}）。</span>`);
      if (hasRelic(p, 'cross') && (p.status.burn > 0 || p.status.blind > 0)) {
        if (p.status.burn > 0) delete p.status.burn;
        else if (p.status.blind > 0) delete p.status.blind;
        pushLog(b, `<span style="color:#d4e8ff">✝️【银十字架】微光护盾净化了 1 项负面异常！</span>`);
      }
    }
    if (sk.rooted) p.status.rooted = 1;
    if (sk.iceThorns) p.status.iceThorns = 1; // 仅钢冰生根盾带微弱反刺，物理生根步绝不串味！
    if (sk.dodgeLunge) p.status.lungeParry = 1;
    if (sk.afterimage) p.status.afterimage = (p.status.afterimage || 0) + sk.afterimage;
    if (sk.nextApBonus) p.status.nextAp = (p.status.nextAp || 0) + sk.nextApBonus;
    if (sk.protectCrate && b.crateHp != null) {
      p.status.crateGuard = (p.status.crateGuard || 0) + sk.protectCrate;
      pushLog(b, `<span style="color:#8ce8b5">📦 冰障延伸护住医疗药箱（抵御冲击 ${p.status.crateGuard}）！</span>`);
    }
    if (sk.path === 'HAND' && hasRelic(p, 'ice_pebble') && b._pebbleTurn !== b.turn) {
      b._pebbleTurn = b.turn;
      const beforePeb = p.shield;
      p.shield = Math.min(p.maxShield, p.shield + 8);
      pushLog(b, `<span style="color:#9beeff">💎【冰蓝石子】经手调魔额外凝结 ${Math.max(8, p.shield - beforePeb)} 护盾（当前 ${p.shield}/${p.maxShield}）。</span>`);
    }

    // 攻击结算
    let totalManaReturned = 0;
    const consumedChain = !!(sk.power && sk.power > 0 && p.status.breakChain > 0 && sk.id !== 'basic_attack');
    let anyHitDealt = false;
    let activatedChain = false;
    let usedFrostPierce = false;
    let activatedFrostPierce = false;
    if (sk.power && sk.power > 0) {
      const targets = sk.aoe ? b.enemies.filter(e => e.hp > 0) : [primary];
      const hadPoise = p.status.poise > 0;

      // 玩家被扬尘致盲（blind）时的真实确定性失手判定！
      if (p.status.blind > 0 && !sk.aoe && !sk.sureHit) {
        p.status.blind -= 1;
        if (p.status.blind <= 0) delete p.status.blind;
        pushLog(b, `<span style="color:#e6c280">🌫️ 视线受扬尘遮蔽，你的「${sk.name}」偏斜落空！（提示：用覆潮水弹/折射水幕洗净视线，或用范围技覆盖）</span>`);
        if (p.overcastMode === 2) p.overcastMode = 0;
        if (!b.headless) renderCombatUI();
        return { ok: true, missedByBlind: true };
      }

      targets.forEach(e => {
        const stance = e.intent ? e.intent.stance : 'HEAVY_WINDUP';
        if (stance === 'UNDER_SEEP' && e.aiType === 'noelle') {
          b.metrics.enteredUnderSeep = true;
        }

        // 诺艾儿残血脚底冰缝暗流翻盘陷阱（100% 绕过正面护盾直刺本体！）
        if (e.intent && e.intent.ambushTrap && !e.seepSevered && !sk.severSeep) {
          if (p.status.afterimage > 0) {
            p.status.afterimage--;
            e.seepSevered = true;
            e.intent.ambushTrap = false;
            pushLog(b, `<span style="color:#8ce8b5">💨 脚底冰缝暗流骤然暴起，幸亏「风行残像」替身引爆了暗流杀阵，你真身安然避开！</span>`);
          } else {
            const trapDmg = e.intent.trapDmg || 205;
            p.hp = Math.max(0, p.hp - trapDmg);
            triggerShake(b, true);
            spawnBanner(b, '💧 冰缝暗流 · 绕盾穿心！', 'danger');
            pushLog(b, `<span style="color:#ff6b7a;font-weight:700">💥 致命陷阱！你前压瞬间，诺艾儿暗渡在冰面裂缝下的水线绕过正面护盾从脚底直接刺穿，造成 ${trapDmg} 点本体重创！</span>`);
            e.intent.ambushTrap = false;
            if (p.hp <= 0) return;
          }
        }
        if (p.hp <= 0) return;

        // 贝阿特丽丝烈焰剑障：盲丢普通冰晶触发融冰爆炎反劈
        if (e.aiType === 'beatrice' && stance === 'GUARD_COUNTER' && e.intent && e.intent.meltIceCounter && sk.elem === 'ice' && sk.path !== 'INSIGHT') {
          const meltDmg = 34;
          const blk = Math.min(p.shield, meltDmg);
          p.shield -= blk;
          p.hp = Math.max(0, p.hp - (meltDmg - blk));
          p.status.burn = (p.status.burn || 0) + 1;
          e.fireAura = Math.min(3, (e.fireAura || 0) + 1);
          triggerShake(b, false);
          pushLog(b, `<span style="color:#ff9e7a">🔥 贝阿特丽丝旋剑震碎正面冰晶，烈焰气浪反劈造成 ${meltDmg} 伤害并重燃1层斗气！（宜在剑障时改用覆潮水弹浇灭）</span>`);
          if (p.hp <= 0) return;
        }

        // 罗文非窄道窗口盲丢凝华冰晶：遭晦轮银环折射反噬
        if (e.aiType === 'rowan' && e.intent && e.intent.refractIceCrystal && sk.id === 'hand_ice_crystal') {
          const refDmg = 24;
          const blk = Math.min(p.shield, refDmg);
          p.shield -= blk;
          p.hp = Math.max(0, p.hp - (refDmg - blk));
          pushLog(b, `<span style="color:#d6a8ff">🌑 罗文轻转晦轮杖偏折了正面冰晶余波，黑芒反噬你 ${refDmg} 伤害！（宜留魔力等他钻入石碑窄道时配合薄冰出击）</span>`);
          if (p.hp <= 0) return;
        }

        // 敌方预判反制盲目隔空瞬凝（艾诺 / 诺艾儿 / 赫兰重甲 GUARD_COUNTER + counterRemoteHit）
        if (sk.path === 'REMOTE' && stance === 'GUARD_COUNTER' && e.intent && e.intent.counterRemoteHit && !usedWand) {
          const counterDmg = 42;
          const blk = Math.min(p.shield, counterDmg);
          p.shield -= blk;
          p.hp = Math.max(0, p.hp - (counterDmg - blk));
          triggerShake(b, false);
          pushLog(b, `<span style="color:#ff8a98">⚡ ${e.name} 早料到你会隔空偷袭，岩幕掐灭冰锥并反震造成 ${counterDmg} 伤害！</span>`);
          if (b.crateHp != null && (e.aiType === 'hulan_brute' || e.aiType === 'hulan_lord')) {
            b.crateHp = Math.max(0, b.crateHp - 22);
            pushLog(b, `<span style="color:#ff8a98">📦 防反余波重创补给线，医疗药箱耐久 -22（剩余 ${b.crateHp}/${b.crateMax}）！</span>`);
            if (b.crateHp <= 0) {
              finishBattle(b, false, 'crate_destroyed');
              return;
            }
          }
          if (b.stageCfg.hitRule && counterDmg > blk) {
            b.enemyHits += 1;
            pushLog(b, `<span style="color:#ff8090;font-weight:700">⚠️ 盲目复读遭艾诺反刺命中！比分：${b.playerHits} : ${b.enemyHits}！</span>`);
            if (b.enemyHits >= (b.stageCfg.targetHits || 3)) {
              finishBattle(b, false, 'enemy_three_hits');
              return;
            }
          }
          if (p.hp <= 0) return;
        }

        if (sk.stripEvadeCharges) e.evadeCharges = 0;
        if (sk.sealWindEvade) {
          e.evadeCharges = 0;
          e.status.evadeSealed = sk.sealWindEvade;
        }

        // 真实确定性闪避层数判定（evadeCharges > 0，与 UI 徽章 100% 一致！）
        const bypassEvade = !!(sk.aoe || sk.sureHit || usedWand || stance === 'STAGGERED');
        if (!bypassEvade && e.evadeCharges > 0) {
          e.evadeCharges -= 1;
          // 普攻 basic_attack 挥空绝不消耗爱丽丝半点 MP！唯耗蓝魔法迫使她催动风步耗 6 MP
          if (e.mp != null && sk.mp > 0) {
            e.mp = Math.max(0, e.mp - 6);
          }
          // 爱丽丝风路未被封印时，若非刚用水弹冲净扬尘，借风闪开单点攻击会顺势回削一道微风气刃
          if (e.aiType === 'alice' && !(e.status.evadeSealed > 0) && sk.mp > 0 && !washedBlindJustNow) {
            const windChip = 18;
            const blk = Math.min(p.shield, windChip);
            p.shield -= blk;
            p.hp = Math.max(0, p.hp - (windChip - blk));
            pushLog(b, `<span style="color:#b8d0e8">💨 ${e.name} 借微风轻盈闪开「${sk.name}」，顺风回削一道气刃造成 ${windChip} 伤害！（宜用冰晶宫殿封死风轨或用范围冰棘压走位）</span>`);
            return;
          }
          pushLog(b, `<span style="color:#b8d0e8">💨 ${e.name} 消耗1层闪避轻盈避开了「${sk.name}」（剩余闪避层×${e.evadeCharges}）！</span>`);
          return;
        }

        // 临时恢复 wandActive 标志供伤害精算读取
        const prevWand = p.wandActive;
        if (usedWand) p.wandActive = true;
        const est = estimateSkillDamage(b, sk, e, { mpCost, powerMp });
        p.wandActive = prevWand;

        // 消耗单次破绽印记 flawToken（打一发立刻清除，绝不永久残留！）
        if (e.flawToken > 0) e.flawToken = 0;

        if (sk.shatterFireAura && e.fireAura) {
          e.fireAura = 0;
          e.fireStacks = 0;
          pushLog(b, `<span style="color:#9beeff">❄️ 地下冰柱将贝阿特丽丝顶了个趔趄，三层烈焰斗气轰然溃散！</span>`);
        }
        if (sk.douseFire) {
          if (e.fireStacks) e.fireStacks = Math.max(0, e.fireStacks - 1);
          if (e.fireAura > 0) {
            e.fireAura = Math.max(0, e.fireAura - 1);
            pushLog(b, `<span style="color:#7ec8ff">💧 覆潮水弹浇弱了贝阿特丽丝 1 层烈焰斗气（剩余斗气×${e.fireAura}）！</span>`);
          }
        }
        if (e.aiType === 'beatrice' && stance === 'DUAL_CAST' && sk.elem === 'ice' && sk.path !== 'INSIGHT') {
          if (e.intent) e.intent.gainFire = 0;
          e.fireStacks = Math.max(0, (e.fireStacks || 0) - 1);
          pushLog(b, `<span style="color:#9beeff">❄️ 凝华冰晶精准冻住暴走火蛇核心，压制了她的升温势头！</span>`);
        }
        if (sk.severSeep) {
          e.seepSevered = true;
          e.seepStacks = 0;
          if (e.intent && e.intent.ambushTrap) {
            e.intent.ambushTrap = false;
            e.status.stagger = 1;
            decideEnemyIntent(e, b);
          }
          pushLog(b, `<span style="color:#9beeff">❄️ 潜伏在冰缝下的暗渡水线被彻底冻死斩断！</span>`);
        }
        if (sk.shredArmor) {
          e.def = Math.floor(e.def * 0.25);
          e.mdef = Math.floor(e.mdef * 0.25);
          e.coreShattered = true;
        }
        if (sk.drainEnemyMp && e.mp != null) {
          e.mp = Math.max(0, e.mp - sk.drainEnemyMp);
          pushLog(b, `<span style="color:#8cd4ff">💨 十字冰栏封死风路，迫使 ${e.name} 剧烈损耗 ${sk.drainEnemyMp} MP（剩余 ${e.mp}/${e.mmp}）！</span>`);
        }
        if (sk.drainWindMp && e.mp != null) {
          if (e.status && e.status.evadeSealed > 0) {
            e.mp = Math.max(0, e.mp - 18);
            pushLog(b, `<span style="color:#8cd4ff">❄️ 冰栏封路下满地冰棘锁死走位，逼耗 ${e.name} 18 MP（剩余 ${e.mp}/${e.mmp}）！</span>`);
          } else if (!p.status.blind && (b.aiMemory.sameAtkSkillStreak || 0) < 2) {
            e.mp = Math.max(0, e.mp - 13);
            pushLog(b, `<span style="color:#8cd4ff">❄️ 你看清风向交错铺开地棘，迫使 ${e.name} 催动微风腾跃耗损 13 MP（剩余 ${e.mp}/${e.mmp}）！</span>`);
          }
        }

        // 艾诺正面无气泡镜冰阻挡
        if (est.mirrorBlocked) {
          pushLog(b, `<span style="color:#a8c4e0">🧊 艾诺随手凝出一面无气泡薄冰挡下「${sk.name}」：「路径太慢，这不算有效命中。」</span>`);
          return;
        }

        // 截断破招判定
        let didInterrupt = false;
        if (est.willInterrupt && stance !== 'STAGGERED') {
          didInterrupt = true;
          e.status.stagger = 1;
          e.wasInterruptedLastTurn = true;
          b.metrics.interrupts += 1;
          if (b.stageCfg.ainoSupport) {
            // 领主庞大身躯在双手聚寒被破招时直接暴露于崖顶视野（+2 共鸣），小怪破招 +1 共鸣
            b.ainoResonance += (e.aiType === 'hulan_lord' ? 2 : 1);
          }
          decideEnemyIntent(e, b);
          spawnBanner(b, '💥 截断破招 INTERRUPT!', 'interrupt');
          triggerShake(b, false);
        }

        // 罗文乱葬岗：窄道铺冰配合雷纳德按肩封锁（冷却后再次铺设薄冰抓窄道可重复叠加 +38%，无冰宫亦可苦战活捉）！
        if (b.stageCfg.sealRule) {
          if (stance === 'DUAL_CAST' && b.frostFloorTurns > 0 && sk.elem === 'ice') {
            b.frostFloorTurns = 0;
            e.status.stagger = 1;
            didInterrupt = true;
            b.metrics.interrupts += 1;
            b.sealProgress = Math.min(100, b.sealProgress + 38);
            decideEnemyIntent(e, b);
            spawnBanner(b, '🪨❄️ 窄道滑冰 · 雷纳德按肩锁脉！', 'interrupt');
            pushLog(b, `<span style="color:#ffe599">🪨❄️ 罗文穿过石碑窄道恰好踏碎你铺开的薄冰，左腿慢了半步！雷纳德按肩灌入土系魔力——合围封锁度 +38%（${b.sealProgress}%）！</span>`);
          } else if (sk.sealBoost) {
            if (stance === 'CLOSE_LUNGE') {
              b.sealProgress = Math.min(100, b.sealProgress + sk.sealBoost);
              pushLog(b, `<span style="color:#ffe599">❄️ 双面冰镜凌空合拢死死夹住脱手飞来的晦轮杖！雷纳德五指收紧收拢石棱——合围封锁度 +${sk.sealBoost}%（${b.sealProgress}%）！</span>`);
            } else {
              b.sealProgress = Math.min(100, b.sealProgress + 26);
              pushLog(b, `<span style="color:#ffe599">❄️ 双面冰镜逼退罗文半步，合围封锁度 +26%（${b.sealProgress}%）！</span>`);
            }
          }
        }

        // 霁馆剑步迎击扑杀闪反
        if (est.willRiposte) {
          b.metrics.ripostes += 1;
          p.status.lungeMitigate = 1;
          spawnBanner(b, '⚡ 覆水迎锋 · 卸力截斩！', 'riposte');
          triggerShake(b, false);
        }

        const critRate = getPlayerCritChance(p, sk);
        const didCrit = !!(b._forceCrit || (critRate > 0 && Math.random() < critRate));
        const finalDmg = didCrit ? Math.round(est.dmg * 1.5) : est.dmg;
        if (sk.elem === 'ice' && p.status.frostPierce > 0 && hasRelic(p, 'aino_frost_shard')) {
          usedFrostPierce = true;
        }

        const dmgRes = dealDamageToEnemy(b, e, finalDmg, {
          wandRefract: est.wandRefract,
          shatterShield: !!sk.shatterShield,
          pierceHalfShield: !!sk.pierceHalfShield,
          severSeep: !!sk.severSeep,
        });
        anyHitDealt = true;

        if (didCrit && sk.path === 'SWORD' && hasRelic(p, 'ebony_sword') && b._ebonyApRefundTurn !== b.turn) {
          b._ebonyApRefundTurn = b.turn;
          b.ap = Math.min(b.apMax, b.ap + 1);
          pushLog(b, `<span style="color:#d6b8ff">🗡️【乌木紫穗剑】剑步暴击破风，返还 1 AP（当前 ${b.ap}/${b.apMax}）！</span>`);
        }

        if ((didInterrupt && sk.path === 'REMOTE') || (est.willRiposte && hadPoise)) {
          activatedChain = true;
        }
        if (didInterrupt || est.willRiposte) {
          if (hasRelic(p, 'aino_frost_shard')) activatedFrostPierce = true;
        }

        const ePos = b.enemies.indexOf(e);
        if (dmgRes.actualHpLoss > 0 || dmgRes.shieldAbsorbed > 0 || est.dmg > 0) {
          const floatLabel = didInterrupt
            ? `-${est.dmg} 破招!`
            : est.willRiposte
              ? `-${est.dmg} 迎锋!`
              : `-${est.dmg}`;
          const floatKind = (didInterrupt || est.mult > 1 || est.wandRefract) ? 'crit' : 'dmg';
          spawnCombatFloat(b, 'enemy', floatLabel, floatKind, ePos);
          queueHitPulse(b, 'enemy', ePos);
        }

        b.aiMemory.currentTurnDmgDealt += dmgRes.actualHpLoss;

        if (sk.applyVuln) e.status.vuln = (e.status.vuln || 0) + sk.applyVuln;
        if (sk.chill) e.status.chill = (e.status.chill || 0) + sk.chill;
        if (dmgRes.actualHpLoss > 0 && p.passives) {
          if (sk.path === 'SWORD' && p.passives.includes('frost_edge')) {
            e.status.chill = Math.max(e.status.chill || 0, 1);
          } else if (sk.path === 'REMOTE' && p.passives.includes('instant_ice')) {
            e.status.chill = Math.max(e.status.chill || 0, 2);
          }
        }

        const tagStr = [
          didInterrupt ? '<b style="color:#ffd468">【截断破招！】</b>' : '',
          est.willRiposte ? '<b style="color:#7ef2c8">【迎锋截斩！】</b>' : '',
          didCrit ? '<b style="color:#ffdf7a">【暴击！】</b>' : '',
          est.chainApplied ? '<b style="color:#ffe28c">【连携1.35×】</b>' : '',
          est.wandRefract ? '<b style="color:#d6a8ff">【晦轮折光破甲】</b>' : '',
          est.mult > 1 ? '<b style="color:#7ec8ff">【属性克制】</b>' : '',
          mcMult > 1.05 ? `<span style="color:#ffe599">[魔战${mcMult.toFixed(2)}x]</span>` : '',
        ].filter(Boolean).join(' ');

        pushLog(b, `⚔️ 「${sk.name}」命中 ${e.name}，造成 <b>${finalDmg}</b> 伤害${dmgRes.shieldAbsorbed ? `（破盾${dmgRes.shieldAbsorbed}）` : ''} ${tagStr}`);

        // 艾诺三击制计分铁律：唯隔空截断破招或冰晶宫殿看破手背可记有效命中
        if (b.stageCfg.hitRule && dmgRes.actualHpLoss > 0) {
          if (didInterrupt || sk.guaranteedCleanHit) {
            b.playerHits += 1;
            pushLog(b, `<span style="color:#ffe599;font-weight:700">🎯 有效命中！比分：希尔维亚 ${b.playerHits} : ${b.enemyHits} 艾诺！</span>`);
          }
        }

        // ⚡ 魔战循环公式①：100% 等量有效生命伤害回流魔力（严格仅作用于非纯物理主动伤害）！
        if (p.hasManaCycle && sk.elem !== 'phys' && dmgRes.actualHpLoss > 0) {
          totalManaReturned += dmgRes.actualHpLoss;
        }
      });

      if (usedFrostPierce) delete p.status.frostPierce;
      if (consumedChain && anyHitDealt) {
        delete p.status.breakChain;
        const chainBonus = Math.round(p.mmp * 0.15) + (hasRelic(p, 'shell_pin') ? Math.round(p.mmp * 0.08) : 0);
        const beforeChainMp = p.mp;
        p.mp = Math.min(p.mmp, p.mp + chainBonus);
        b.metrics.manaRecycled += Math.max(0, p.mp - beforeChainMp);
        pushLog(b, `<span style="color:#ffd468">🔗【连携追击】乘势追击引动魔脉回流 +${p.mp - beforeChainMp} MP${hasRelic(p, 'shell_pin') ? '（含月虹螺+8%）' : ''}！</span>`);
      }
      if (activatedFrostPierce) {
        p.status.frostPierce = 1;
        pushLog(b, `<span style="color:#9beeff">❄️【钢冰试炼笺】破招余锋凝实，下一次冰系攻击无视 25% 冰抗！</span>`);
      }
      if (activatedChain) {
        p.status.breakChain = 1;
        pushLog(b, `<span style="color:#ffd468;font-weight:700">✨【破招连携窗口】本回合下一张非基础攻击牌享 1.35× 伤害并额外返还 15% 魔力！</span>`);
      }

      if (hadPoise && sk.path === 'SWORD') delete p.status.poise;

      // 伊诺共鸣锁核或连续破招触发崖顶艾诺极寒冰枪协同轰击！
      if (sk.triggerAinoSpear && b.stageCfg.ainoSupport) {
        b.ainoResonance += 2;
      }
      while (b.stageCfg.ainoSupport && b.ainoResonance >= 2) {
        const bossTarget = getPrimaryAliveEnemy(b);
        b.ainoResonance -= 2;
        if (bossTarget) {
          b.ainoSpearsFiredInWave = (b.ainoSpearsFiredInWave || 0) + 1;
          const spearDmg = 100;
          dealDamageToEnemy(b, bossTarget, spearDmg, { pierceHalfShield: true });
          spawnBanner(b, '❄️ 艾诺支援 · 极寒冰枪贯落！', 'interrupt');
          pushLog(b, `<span style="color:#a8ecff;font-weight:700">❄️【冰原共鸣】峡谷崖顶艾诺射落第 ${b.ainoSpearsFiredInWave} 道无气泡极寒冰枪，重创 ${bossTarget.name} ${spearDmg} 伤害！</span>`);
          // 无冰宫基本功路径：本波累计引落第 2 发艾诺冰枪命中领主时，同样震碎腹下晶核！
          if (bossTarget.aiType === 'hulan_lord' && !bossTarget.coreShattered && b.ainoSpearsFiredInWave >= 2) {
            bossTarget.coreShattered = true;
            bossTarget.shield = 0;
            bossTarget.def = Math.floor(bossTarget.def * 0.28);
            bossTarget.mdef = Math.floor(bossTarget.mdef * 0.28);
            bossTarget.status.vuln = (bossTarget.status.vuln || 0) + 2;
            pushLog(b, `<span style="color:#9beeff;font-weight:700">❄️💥 第二道极寒冰枪顺着破招裂隙贯入领主腹下，幽蓝晶核轰然震碎（重甲瓦解，地脉寒震停止）！</span>`);
          }
        }
      }
    }

    if (p.hp > 0 && p.hp < p.mhp * 0.35 && !b._blueVialTriggered && hasRelic(p, 'blue_vial')) {
      b._blueVialTriggered = true;
      const vialHeal = Math.max(15, Math.round(p.mhp * 0.25));
      p.hp = Math.min(p.mhp, p.hp + vialHeal);
      p.status.afterimage = (p.status.afterimage || 0) + 1;
      pushLog(b, `<span style="color:#8cd4ff;font-weight:700">🧪【淡蓝小瓶】濒危安神凉雾散开，回复 ${vialHeal} 生命并幻化 1 层「风行残像」！</span>`);
    }

    if (p.hp <= 0) {
      finishBattle(b, false, 'hp_zero');
      return { ok: true, defeated: true };
    }

    if (totalManaReturned > 0) {
      const mpBefore = p.mp;
      p.mp = Math.min(p.mmp, p.mp + totalManaReturned);
      b.metrics.manaRecycled += totalManaReturned;
      const mpGain = p.mp - mpBefore;
      if (mpGain > 0) spawnCombatFloat(b, 'player', `+${mpGain} MP`, 'mp');
      pushLog(b, `<span style="color:#6ecbff">⚡【魔战循环】100% 等量伤害回流 +${totalManaReturned} MP（当前 ${p.mp}/${p.mmp}）！</span>`);
    }
    if (p.overcastMode === 2 && sk.power > 0 && sk.atkKind === 'matk') {
      p.overcastMode = 0;
    }

    if (!b.headless && typeof global.sfx === 'function') global.sfx('magic');

    if (checkImmediateVictoryOrNextWave(b)) {
      if (!b.headless) renderCombatUI();
      return { ok: true, battleEndedOrAdvanced: true };
    }

    if (!b.headless) renderCombatUI();
    return { ok: true };
  }

  function checkImmediateVictoryOrNextWave(b) {
    if (b.over) return true;

    // 1. 艾诺三击制唯一胜机铁律：绝不允许靠 HP 归零判胜，唯抢满 3 次有效命中可胜！
    if (b.stageCfg.hitRule) {
      if (b.playerHits >= (b.stageCfg.targetHits || 3)) {
        pushLog(b, `<span style="color:#ffe599;font-weight:700">❄️ 冰珠弹在艾诺手背上！艾诺微怔：「……这算命中。三击已满，你赢了。」</span>`);
        finishBattle(b, true, 'three_hits');
        return true;
      }
      return false;
    }

    // 2. 罗文乱葬岗活捉铁律：凑满 100% 合围封锁判胜；若未满 100% 却把罗文打空 HP，化雾逃脱判败！
    if (b.stageCfg.sealRule) {
      if (b.sealProgress >= 100) {
        pushLog(b, `<span style="color:#ffe599;font-weight:700">🪨❄️ 四道石棱轰然闭合将罗文压入地面，你一发冰锥钉穿他袖口定在离地半寸——成功活捉留口供！</span>`);
        finishBattle(b, true, 'sealed_rowan');
        return true;
      }
      const rowan = b.enemies[0];
      if (rowan && rowan.hp <= 0) {
        pushLog(b, `<span style="color:#ff6b7a;font-weight:700">❌ 合围尚未成形（${b.sealProgress}%）！重伤的罗文借晦轮杖偏折月影化作血雾遁逃，线索断绝！</span>`);
        finishBattle(b, false, 'rowan_escaped');
        return true;
      }
      return false;
    }

    // 3. 常规与多波次全灭检查
    const alive = b.enemies.some(e => e.hp > 0);
    if (!alive) {
      if (b.waveIdx + 1 < b.totalWaves) {
        initWave(b, b.waveIdx + 1);
        b.ap = Math.max(b.ap, b.apPerTurn);
        if (b.player.wandActive && b.witnessActive) {
          b.player.wandActive = false;
          pushLog(b, `<span style="color:#ffd480">⚠️ 察觉林外极光小队靠近，已迅速收起晦轮杖！</span>`);
        }
        return true;
      } else {
        finishBattle(b, true, b.metrics.manaFizzleWin ? 'alice_mana_fizzle' : 'all_defeated');
        return true;
      }
    }
    return false;
  }

  function endTurn(b) {
    b = b || activeBattle;
    if (!b || b.over) return false;
    const p = b.player;
    delete p.status.breakChain;
    const hadNobleReflect = !!(p.status && p.status.nobleReflect > 0);

    // 更新 AI 龟缩监测黑板
    b.aiMemory.lastTurnDmgDealt = b.aiMemory.currentTurnDmgDealt;
    if (b.aiMemory.currentTurnDmgDealt <= 5) {
      b.aiMemory.turtleStreak = (b.aiMemory.turtleStreak || 0) + 1;
    } else {
      b.aiMemory.turtleStreak = 0;
    }
    b.aiMemory.currentTurnDmgDealt = 0;

    const banked = Math.min(1, Math.max(0, b.ap));

    // 敌方依次行动
    for (const e of b.enemies) {
      if (e.hp <= 0 || b.over) continue;

      if (e.status.stagger > 0) {
        pushLog(b, `<span style="color:#9ec8e8">💫 ${e.name} 架势崩解，错失本回合攻势！</span>`);
        delete e.status.stagger;
        // 霜渊裂地兽若晶核未碎，即便眩晕亦有微弱余震（-8 药箱耐久）
        if (e.aiType === 'hulan_lord' && !e.coreShattered && e.hp > 0 && b.crateHp != null) {
          e.shield += 35;
          b.crateHp = Math.max(0, b.crateHp - 8);
          pushLog(b, `<span style="color:#ff9aa6">❄️ 领主腹下晶核未破，再生 35 点冻甲且寒气余震损耗药箱 8 耐久（剩余 ${b.crateHp}）！</span>`);
          if (b.crateHp <= 0) {
            finishBattle(b, false, 'crate_destroyed');
            return true;
          }
        }
        if (e.status.vuln > 0) e.status.vuln--;
        if (e.status.chill > 0) e.status.chill--;
        continue;
      }

      const intent = e.intent;
      if (!intent) continue;

      b.metrics.enemyActions = (b.metrics.enemyActions || 0) + 1;

      // 爱丽丝魔力不足蓄力风暴原著自断！
      if (intent.selfFizzleIfLowMp && e.mp != null && e.mp < intent.mpCost) {
        b.metrics.manaFizzleWin = true;
        pushLog(b, `<span style="color:#c8ecff;font-weight:700">💨 狂躁的气流骤然散去！爱丽丝晃了一下：「……没魔力了。……认输。」</span>`);
        e.hp = 0;
        if (checkImmediateVictoryOrNextWave(b)) {
          if (!b.headless) renderCombatUI();
          return true;
        }
        continue;
      }

      if (intent.mpCost && e.mp != null) {
        e.mp = Math.max(0, e.mp - intent.mpCost);
      }

      if (intent.refreshCurtain && !e.seepSevered) {
        e.shield = Math.max(e.shield, intent.refreshCurtain);
      }
      if (intent.gainShield) e.shield += intent.gainShield;
      if (intent.gainFire) e.fireStacks = (e.fireStacks || 0) + intent.gainFire;
      if (intent.buffPack) {
        b.enemies.forEach(ally => { if (ally.hp > 0) ally.atk += intent.buffPack; });
      }

      // 赫兰医疗药箱受击结算
      if (intent.crateDmg && b.crateHp != null) {
        let cDmg = intent.crateDmg;
        if (hasRelic(p, 'northwind_pass')) cDmg = Math.max(0, cDmg - 4);
        if (p.status.crateGuard > 0) {
          const blk = Math.min(p.status.crateGuard, cDmg);
          p.status.crateGuard -= blk;
          cDmg -= blk;
        }
        if (cDmg > 0) {
          b.crateHp = Math.max(0, b.crateHp - cDmg);
          pushLog(b, `<span style="color:#ff8a98">📦 ${e.name} 重撞补给防线，医疗药箱耐久 -${cDmg}（剩余 ${b.crateHp}/${b.crateMax}）！</span>`);
          if (b.crateHp <= 0) {
            pushLog(b, `<span style="color:#ff5b6c;font-weight:700">❌ 医疗药箱被毁，冰封峡谷前线补给崩溃！</span>`);
            finishBattle(b, false, 'crate_destroyed');
            return true;
          }
        } else {
          pushLog(b, `<span style="color:#8ce8b5">📦 生根冰障稳稳护住了医疗药箱！</span>`);
        }
      }

      if (intent.dmg > 0) {
        // 1) 风行残像闪避
        if (p.status.afterimage > 0) {
          p.status.afterimage -= 1;
          pushLog(b, `<span style="color:#8ce8b5">💨 「风行残像」碎裂，你真身避开了 ${e.name} 的「${intent.moveName}」！</span>`);
          if (hasRelic(p, 'alice_flower_cake')) {
            const beforeMp = p.mp;
            p.mp = Math.min(p.mmp, p.mp + 10);
            if (p.mp > beforeMp) {
              pushLog(b, `<span style="color:#9ef2c8">🌼【风之花饼】借风轻落回蓄 ${p.mp - beforeMp} MP！</span>`);
            }
          }
          continue;
        }

        // 2) 生根步·卸力侧滑 专克单挑 CLOSE_LUNGE 贴身扑杀（若陷入 >=3 只群狼合围则无法靠单人步法全身而退）！
        const packSurround = b.enemies.filter(x => x.hp > 0 && x.aiType === 'pack_wolf').length >= 3;
        if (intent.stance === 'CLOSE_LUNGE' && p.status.lungeParry > 0 && !packSurround) {
          p.status.lungeParry = 0;
          p.status.poise = 1; // 蓄势强化下一记送刀
          e.evadeCharges = 0;
          e.evadeBrokenThisTurn = true;
          b.metrics.ripostes += 1;
          const riposteDmg = Math.round(p.atk * 1.15);
          dealDamageToEnemy(b, e, riposteDmg, {});
          spawnCombatFloat(b, 'enemy', `-${riposteDmg} 闪反!`, 'riposte', b.enemies.indexOf(e));
          queueHitPulse(b, 'enemy', b.enemies.indexOf(e));
          spawnBanner(b, '⚡ 生根侧滑 · 卸力破闪！', 'riposte');
          pushLog(b, `<span style="color:#8ce8b5">🗡️ 你沉膝侧滑卸开「${intent.moveName}」，震散其闪避架势并顺势削出 ${riposteDmg} 伤害（下一记送刀强化）！</span>`);
          if (checkImmediateVictoryOrNextWave(b)) {
            if (!b.headless) renderCombatUI();
            return true;
          }
          continue;
        }

        // 敌方破盾重锤判定（专治无脑叠盾龟缩！）
        if (intent.shatterPlayerShield && p.shield > 0) {
          pushLog(b, `<span style="color:#ff6b7a">💥 ${e.name} 的「${intent.moveName}」正面轰碎了你全部 ${p.shield} 点护盾！</span>`);
          p.shield = 0;
        }

        let incoming = intent.dmg;
        if (e.status.chill > 0) incoming = Math.round(incoming * 0.86);
        if (intent.elem === 'fire' && p.passives.includes('temp_sense')) {
          incoming = Math.round(incoming * 0.8);
        }
        if (intent.slipStrike && !p.status.rooted) {
          incoming = Math.round(incoming * 1.3);
        }
        if (p.status.lungeMitigate > 0 && intent.stance === 'CLOSE_LUNGE') {
          incoming = Math.round(incoming * 0.4);
        }

        // 罗文首击黑光：雷纳德掀石板仅协助减伤保命，单纯挨打绝不白送合围封锁度！
        if (b.stageCfg.sealRule && intent.renoRockBlock && p.shield > 0) {
          incoming = Math.round(incoming * 0.45);
          pushLog(b, `<span style="color:#ffe599">🪨 雷纳德勾起碎石板与你的冰墙合力拦下大半黑光！（提示：须铺设蔓地薄冰主动设伏才能推进封锁度）</span>`);
        }

        const pDef = intent.elem === 'phys' ? p.def : p.mdef;
        incoming = Math.max(5, Math.round(incoming - pDef * 0.55));

        let hpLoss = incoming;
        if (intent.bypassAllShield) {
          // 脚底穿刺完全绕过正面护盾
        } else if (intent.bypassHalfShield) {
          const blk = Math.min(Math.floor(p.shield * 0.5), hpLoss);
          p.shield -= blk;
          hpLoss -= blk;
        } else {
          const blk = Math.min(p.shield, hpLoss);
          p.shield -= blk;
          hpLoss -= blk;
        }

        // 仅钢冰生根盾（iceThorns）产生微弱10点冰晶刮擦，且最低保留敌方1HP，绝不回蓝、绝不磨死Boss！
        if (p.status.iceThorns > 0 && e.hp > 1 && (intent.stance === 'HEAVY_WINDUP' || intent.stance === 'CLOSE_LUNGE')) {
          const chip = Math.min(e.hp - 1, 10);
          if (chip > 0) {
            e.hp -= chip;
            pushLog(b, `<span style="color:#9beeff">❄️ 生根冰盾表面霜刺刮伤 ${e.name} ${chip} 点皮毛。</span>`);
          }
        }

        p.hp = Math.max(0, p.hp - hpLoss);
        if (hpLoss > 0) {
          triggerShake(b, hpLoss >= 45);
          spawnCombatFloat(b, 'player', `-${hpLoss}`, 'enemy-dmg');
          queueHitPulse(b, 'player', 0);
          if (!b.headless && typeof global.sfx === 'function') global.sfx('bad');
          pushLog(b, `<span style="color:#ff9aa6">❗ ${e.name} 施展「${intent.moveName}」，造成 ${hpLoss} 伤害${hpLoss < incoming ? `（护盾抵消 ${incoming - hpLoss}）` : ''}！</span>`);
          if (intent.scoresHit && b.stageCfg.hitRule) {
            const hitGain = (intent.slipStrike && !p.status.rooted) ? 2 : 1;
            b.enemyHits = Math.min(b.stageCfg.targetHits || 3, b.enemyHits + hitGain);
            pushLog(b, `<span style="color:#ff8090;font-weight:700">⚠️ ${hitGain > 1 ? '脚底未生根打滑连中两刺！' : '被艾诺有效命中！'}比分：${b.playerHits} : ${b.enemyHits}！</span>`);
            if (b.enemyHits >= (b.stageCfg.targetHits || 3)) {
              finishBattle(b, false, 'enemy_three_hits');
              return true;
            }
          }
        } else {
          pushLog(b, `<span style="color:#8cd4ff">🛡️ 你的护盾稳稳挡下了 ${e.name} 的「${intent.moveName}」！</span>`);
        }

        if (intent.inflictBlind) {
          p.status.blind = (p.status.blind || 0) + intent.inflictBlind;
          pushLog(b, `<span style="color:#e6c280">🌫️ 扬尘遮蔽视线（下一次非范围单点攻击必偏斜，可用覆潮水弹/折射水幕洗净）！</span>`);
        }
        if (intent.addBurn && hpLoss > 0) {
          p.status.burn = (p.status.burn || 0) + intent.addBurn;
        }

        if (hadNobleReflect && hpLoss >= 0 && e.hp > 0) {
          const refDmg = Math.round(p.mdef * 1.4 + 28);
          dealDamageToEnemy(b, e, refDmg, {});
          pushLog(b, `<span style="color:#ffd479">👑【贵族体面·回敬】礼仪冰霜震退 ${e.name}，反伤 ${refDmg}！</span>`);
          if (checkImmediateVictoryOrNextWave(b)) {
            if (!b.headless) renderCombatUI();
            return true;
          }
        }

        if (p.hp > 0 && p.hp < p.mhp * 0.35 && !b._blueVialTriggered && hasRelic(p, 'blue_vial')) {
          b._blueVialTriggered = true;
          const vialHeal = Math.max(15, Math.round(p.mhp * 0.25));
          p.hp = Math.min(p.mhp, p.hp + vialHeal);
          p.status.afterimage = (p.status.afterimage || 0) + 1;
          pushLog(b, `<span style="color:#8cd4ff;font-weight:700">🧪【淡蓝小瓶】濒危安神凉雾散开，回复 ${vialHeal} 生命并幻化 1 层「风行残像」！</span>`);
        }

        if (p.hp <= 0) {
          finishBattle(b, false, 'hp_zero');
          return true;
        }
      }

      // 爱丽丝每回合微风回流 7 MP 并补充风步闪避层（除非被十字冰栏封印）
      if (e.aiType === 'alice') {
        if (e.mp != null) e.mp = Math.min(e.mmp, e.mp + 7);
        if (e.status.evadeSealed > 0) {
          e.status.evadeSealed -= 1;
          e.evadeCharges = 0;
        } else {
          e.evadeCharges = e.maxEvadeCharges || 2;
        }
      }
      if (e.aiType === 'noelle' && !e.seepSevered) {
        e.seepStacks = (e.seepStacks || 0) + 1;
      }
      // 霜渊裂地兽领主腹下晶核未破时，每回合释放地脉寒震损耗药箱并再生重甲
      if (e.aiType === 'hulan_lord' && !e.coreShattered && e.hp > 0 && b.crateHp != null) {
        e.shield += 55;
        b.crateHp = Math.max(0, b.crateHp - 16);
        pushLog(b, `<span style="color:#ff9aa6">❄️ 领主腹下晶核未破，再生 55 点冻甲且寒震穿透冰障损耗药箱 16 耐久（剩余 ${b.crateHp}）！</span>`);
        if (b.crateHp <= 0) {
          finishBattle(b, false, 'crate_destroyed');
          return true;
        }
      }

      if (e.status.vuln > 0) e.status.vuln--;
      if (e.status.chill > 0) e.status.chill--;
    }

    // 玩家回合末结算
    if (p.status.burn > 0) {
      const burnDmg = 8;
      p.hp = Math.max(0, p.hp - burnDmg);
      p.status.burn--;
      pushLog(b, `<span style="color:#ff9e7a">🔥 烈焰灼烧损耗 ${burnDmg} 生命。</span>`);
      if (p.hp <= 0) {
        finishBattle(b, false, 'burn_death');
        return true;
      }
    }

    if (hasRelic(p, 'cross') && p.hp > 0 && p.hp < p.mhp) {
      const crossHeal = Math.max(2, Math.round(p.mhp * 0.06));
      const beforeHp = p.hp;
      p.hp = Math.min(p.mhp, p.hp + crossHeal);
      if (p.hp > beforeHp) {
        pushLog(b, `<span style="color:#d4e8ff">✝️【银十字架】微光抚平伤势，回复 ${p.hp - beforeHp} 生命。</span>`);
      }
    }

    delete p.status.rooted;
    delete p.status.iceThorns;
    delete p.status.lungeParry;
    delete p.status.lungeMitigate;
    delete p.status.crateGuard;
    delete p.status.zeroMpThisTurn;
    delete p.status.nobleReflect;

    if (b.frostFloorTurns > 0) b.frostFloorTurns--;

    // 护盾跨回合大幅衰减（普通留 20%，生根之冰留 45%）
    const retainRate = p.passives.includes('root_ice') ? 0.45 : 0.2;
    p.shield = Math.floor(p.shield * retainRate);

    if (p.wandCooldown > 0) p.wandCooldown--;
    Object.keys(p.cooldowns).forEach(k => {
      if (p.cooldowns[k] > 0) p.cooldowns[k]--;
      if (p.cooldowns[k] <= 0) delete p.cooldowns[k];
    });

    // 艾诺切磋回合上限判定
    if (b.stageCfg.turnLimit && b.turn >= b.stageCfg.turnLimit) {
      pushLog(b, `<span style="color:#ff8090;font-weight:700">⏱️ ${b.stageCfg.turnLimit} 回合时限已到，未能拿满三次有效命中，切磋告负！</span>`);
      finishBattle(b, false, 'turn_limit');
      return true;
    }

    b.turn += 1;
    b.waveTurn = (b.waveTurn || 1) + 1;
    const bonusAp = p.status.nextAp || 0;
    delete p.status.nextAp;
    b.ap = Math.min(b.apMax, b.apPerTurn + banked + bonusAp);

    if (hasRelic(p, 'northwind_pass')) {
      const beforeS = p.shield;
      p.shield = Math.min(p.maxShield, p.shield + 12);
      if (p.shield > beforeS) {
        pushLog(b, `<span style="color:#a8ecff">🪪【北风堡木牌】新回合寒铁护盾 +${p.shield - beforeS}（当前 ${p.shield}/${p.maxShield}）。</span>`);
      }
    }

    b.enemies.forEach(e => {
      if (e.aiType === 'noelle' && e.seepTriggeredOnce && !e.seepSevered) {
        b.metrics.enteredUnderSeep = true;
      }
      decideEnemyIntent(e, b);
    });

    if (!b.headless) renderCombatUI();
    return true;
  }

  function useBondAssist(b) {
    b = b || activeBattle;
    if (!b || b.over) return { ok: false, reason: 'over' };
    const p = b.player;
    if (!p.bondAssist) return { ok: false, reason: 'none' };
    if (p.bondAssistUsed) return { ok: false, reason: 'used' };

    const api = getRelicsApi();
    const meta = (api && api.BOND_ASSISTS && api.BOND_ASSISTS[p.bondAssist]) || null;
    const cid = p.bondAssist;
    p.bondAssistUsed = true;
    const primary = getPrimaryAliveEnemy(b);

    if (cid === 'alice') {
      delete p.status.blind;
      delete p.status.burn;
      p.status.afterimage = (p.status.afterimage || 0) + 1;
      const recMp = Math.round(p.mmp * 0.15);
      p.mp = Math.min(p.mmp, p.mp + recMp);
      pushLog(b, `<span style="color:#9ef2c8;font-weight:700">🍃【心念援护·爱丽丝·清风托翼】「${meta ? meta.quote : ''}」清除视野/灼烧，获 1 层「风行残像」并回复 ${recMp} MP！</span>`);
    } else if (cid === 'noelle') {
      p.status.zeroMpThisTurn = 1;
      const recMp = Math.round(p.mmp * 0.2);
      p.mp = Math.min(p.mmp, p.mp + recMp);
      pushLog(b, `<span style="color:#9beeff;font-weight:700">📐【心念援护·诺艾儿·精算校准】「${meta ? meta.quote : ''}」本回合所有技能零耗蓝，并立即回复 ${recMp} MP！</span>`);
    } else if (cid === 'aino') {
      b.enemies.forEach(e => {
        if (e.hp > 0) {
          e.status.vuln = (e.status.vuln || 0) + 2;
          e.status.chill = (e.status.chill || 0) + 2;
        }
      });
      if (primary && primary.shield > 0) {
        primary.shield = Math.max(0, Math.floor(primary.shield * 0.7));
      }
      pushLog(b, `<span style="color:#a8ecff;font-weight:700">❄️【心念援护·艾诺·霜域共鸣】「${meta ? meta.quote : ''}」全体附加 2 回合易伤与寒颤，当前目标削盾 30%！</span>`);
    } else if (cid === 'jilan') {
      b.ap = Math.min(b.apMax, b.ap + 1);
      p.status.poise = 1;
      if (primary && primary.evadeCharges > 0) primary.evadeCharges -= 1;
      if (p.status.blind > 0) delete p.status.blind;
      else if (p.status.burn > 0) delete p.status.burn;
      pushLog(b, `<span style="color:#d6b8ff;font-weight:700">💜【心念援护·霁岚·霁馆借步】「${meta ? meta.quote : ''}」+1 AP、剑势蓄力并震破目标 1 层闪避！</span>`);
    } else if (cid === 'charlotte') {
      p.shield = Math.max(p.maxShield, p.shield + 40);
      p.status.nobleReflect = 1;
      pushLog(b, `<span style="color:#ffd479;font-weight:700">👑【心念援护·夏洛特·贵族体面】「${meta ? meta.quote : ''}」护盾补满（至少+40）并展开冰镜反震！</span>`);
    }

    spawnBanner(b, `💞 ${meta ? `${meta.icon} ${meta.name}·${meta.title}` : '心念援护'}！`, 'riposte');
    if (!b.headless && typeof global.sfx === 'function') global.sfx('egg');
    if (!b.headless) renderCombatUI();
    return { ok: true, charId: cid };
  }

  /* =========================================================
     7. 评级计算与严格存档沙盒隔离
     ========================================================= */
  function calculateGrade(b) {
    if (!b.won) return 'F';
    let score = 70;
    const parTurns = b.totalWaves > 1 ? 8 : 6;
    if (b.turn <= parTurns) score += 12;
    else if (b.turn <= parTurns + 3) score += 6;
    else if (b.turn > parTurns + 7) score -= 8;

    if (b.metrics.interrupts > 0 || b.metrics.ripostes > 0 || b.metrics.manaFizzleWin) score += 8;
    if (b.metrics.insights > 0) score += 15;
    const hpRatio = b.player.hp / Math.max(1, b.player.mhp);
    if (hpRatio >= 0.5) score += 6;
    else if (hpRatio >= 0.25) score += 2;
    if (b.crateHp != null && b.crateHp < 60) score -= 15;

    let grade = score >= 97 ? 'S' : score >= 80 ? 'A' : 'B';
    if (b.exposureWarningTriggered) grade = 'B';
    return grade;
  }

  function applyStageRewardsToGame(b) {
    // 核心红线：演武场独立沙盒（fromArena: true）严禁修改主线存档 S 的任何属性、经验、金币或道具！
    if (!b || b.headless || b.fromArena) return;
    const curS = getGameS();
    if (!curS) return;

    const rew = b.stageCfg.reward || {};
    const isDreamDuel = !!rew.duelKey;

    if (!b.won) {
      if (!isDreamDuel) {
        // 野外实战战败：重伤撤回安全屋
        curS.deaths = (curS.deaths || 0) + 1;
        curS.hp = 1;
        curS.mp = Math.max(5, Math.min(curS.mmp, b.player.mp));
        if (curS.lastSafe) curS.loc = curS.lastSafe;
      }
      if (typeof global.updateHUD === 'function') global.updateHUD();
      return;
    }

    // 野外实战胜利：同步写回真实 HP/MP 损耗
    if (!isDreamDuel) {
      curS.hp = Math.max(1, Math.min(curS.mhp, b.player.hp));
      curS.mp = Math.max(0, Math.min(curS.mmp, b.player.mp));
    }

    // 虚拟决斗奖励仅首次战胜发放，防止无限刷钱刷级
    const alreadyWonDuel = isDreamDuel && (curS.duelWins || []).includes(rew.duelKey);
    if (!alreadyWonDuel) {
      if (rew.exp && typeof global.addExp === 'function') global.addExp(rew.exp);
      if (rew.gold) curS.gold = (curS.gold || 0) + rew.gold;
      if (rew.skillId && typeof global.addSkill === 'function') global.addSkill(rew.skillId);
      if (rew.duelKey) {
        curS.duelWins = curS.duelWins || [];
        curS.duelWins.push(rew.duelKey);
        if (typeof global.ach === 'function') global.ach('virtual_first');
      }
      if (rew.taskId && typeof global.doneTask === 'function') global.doneTask(rew.taskId);
      if (rew.achId && typeof global.ach === 'function') global.ach(rew.achId);
    }

    if (typeof global.updateHUD === 'function') global.updateHUD();
    if (typeof global.save === 'function') global.save();
  }

  function finishBattle(b, won, reason) {
    if (b.over) return;
    b.over = true;
    b.won = !!won;
    b.endReason = reason || '';
    b.grade = won ? calculateGrade(b) : 'F';

    if (won) {
      saveArenaRecord(b.id, b.grade, b.turn);
      if (!b.headless && typeof global.sfx === 'function') global.sfx('level');
    } else {
      if (!b.headless && typeof global.sfx === 'function') global.sfx('bad');
    }
    applyStageRewardsToGame(b);

    if (!b.headless) {
      renderCombatUI();
      showResultModal(b);
    }
  }

  /* =========================================================
     8. UI 渲染层（实时悬停倾注预览 + 两步随机洗牌冰晶宫殿 + 演武大厅）
     ========================================================= */
  function resolveCharImg(charId, emo, stageAge) {
    if (!charId) return null;
    const pMap = getPortraitMap();
    const curS = getGameS();
    const namedInGame = !!(curS && curS.flags && curS.flags.named);
    const useStageAge = stageAge != null || !!(activeBattle && activeBattle.fromArena) || !namedInGame;
    if (useStageAge && pMap) {
      const baseAge = stageAge != null
        ? stageAge
        : ((activeBattle && activeBattle.stageCfg && activeBattle.stageCfg.presetPlayer && activeBattle.stageCfg.presetPlayer.age) || 14);
      const charAge = charId === 'beatrice' ? baseAge + 2 : charId === 'alice' ? Math.max(0, baseAge - 2) : baseAge;
      const tier = charAge <= 5 ? 'child' : charAge <= 11 ? 'young' : 'teenage';
      const emotion = emo || 'normal';
      return pMap[`${charId}_${tier}_${emotion}`]
        || pMap[`${charId}_${tier}_normal`]
        || pMap[`${charId}_${emotion}`]
        || pMap[`${charId}_normal`]
        || pMap[`${charId}_child`]
        || null;
    }
    if (typeof global.resolvePortrait === 'function') {
      if (charId === 'sylvia' && pMap) {
        return global.resolvePortrait('sylvia', emo || 'serious') || pMap.sylvia_teenage_serious || pMap.sylvia_young_normal;
      }
      return global.resolvePortrait(charId, emo || 'normal');
    }
    return null;
  }

  function shuffleCopy(arr) {
    const out = arr.slice();
    for (let i = out.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      const tmp = out[i];
      out[i] = out[j];
      out[j] = tmp;
    }
    return out;
  }

  function ensureBattleDOM() {
    if (typeof document === 'undefined') return null;
    const root = document.getElementById('battle-screen');
    if (!root) return null;
    if (root.querySelector('.cb-shell')) return root;

    root.innerHTML = `
      <div class="cb-backdrop" id="cb-backdrop"></div>
      <div class="cb-vignette" aria-hidden="true"></div>
      <div class="cb-palace-frost" id="cb-palace-frost" aria-hidden="true"></div>
      <div class="cb-vfx-flash" id="cb-vfx-flash" aria-hidden="true"></div>
      <div class="cb-shell">
        <header class="cb-topbar">
          <div class="cb-stage-info">
            <span class="cb-wave-pill" id="cb-wave">WAVE 1/1</span>
            <span class="cb-stage-title" id="cb-title">战术交锋</span>
            <span class="cb-turn-badge" id="cb-turn">第 1 回合</span>
          </div>
          <div class="cb-meters" id="cb-meters"></div>
          <div class="cb-top-tools">
            <button class="cb-tool-btn palace-btn" id="cb-btn-palace">${CB_SVG.crystal} 冰晶宫殿 <span class="cb-kbd">Q</span></button>
            <button class="cb-tool-btn wand-btn hidden" id="cb-btn-wand">${CB_SVG.wand} 晦轮杖 <span class="cb-kbd">R</span></button>
            <button class="cb-tool-btn assist-btn hidden" id="cb-btn-assist">✦ 心念援护 <span class="cb-kbd">F</span></button>
            <button class="cb-tool-btn retreat-btn" id="cb-btn-retreat">${CB_SVG.retreat} 撤出</button>
          </div>
        </header>

        <div class="cb-arena-field">
          <div class="cb-callout-layer" id="cb-callout-layer"></div>

          <div class="cb-player-stage" id="cb-player-stage">
            <div class="cb-standee-wrap">
              <div class="cb-magic-circle" aria-hidden="true"></div>
              <div class="cb-p-portrait" id="cb-p-portrait"></div>
            </div>
            <aside class="cb-player-pane" id="cb-player-pane">
              <div class="cb-p-header">
                <div class="cb-p-title">
                  <div class="cb-p-name" id="cb-p-name">希尔维亚</div>
                  <div class="cb-p-sub" id="cb-p-sub">物攻 -- · 魔攻 --</div>
                </div>
                <div class="cb-ap-row" id="cb-ap-row"></div>
              </div>
              <div class="cb-bars-wrap">
                <div class="cb-stat-row">
                  <div class="cb-stat-top"><span>生命值 HP</span><span id="cb-php-txt">0/0</span></div>
                  <div class="cb-stat-track"><div class="cb-stat-fill hp" id="cb-php-bar"></div></div>
                </div>
                <div class="cb-stat-row">
                  <div class="cb-stat-top"><span>魔力池 MP</span><span id="cb-pmp-txt">0/0</span></div>
                  <div class="cb-stat-track">
                    <div class="cb-stat-fill mp" id="cb-pmp-bar"></div>
                    <div class="cb-mp-commit" id="cb-mp-commit"></div>
                    <div class="cb-stat-ticks"></div>
                  </div>
                </div>
              </div>
              <div class="cb-buff-list" id="cb-p-buffs"></div>
            </aside>
          </div>

          <section class="cb-enemy-zone" id="cb-enemy-zone"></section>
        </div>

        <div class="cb-forecast-bar" id="cb-forecast-bar">悬停技能卡可实时推演架势克制、破招截断、预计伤害与魔战回蓝</div>

        <div id="b-enemy" class="hidden">
          <span id="b-emoji"></span><span id="b-ename"></span>
          <i id="b-ehp"></i><em id="b-ehp-num"></em>
        </div>

        <footer class="cb-deck">
          <div class="cb-left-console">
            <div class="cb-overcast-box" id="cb-overcast-box">
              <div class="cb-oc-head">
                <span>魔战循环 · 倾注 <span class="cb-kbd">W</span></span>
                <span class="cb-oc-mult" id="cb-oc-mult">1.00x</span>
              </div>
              <div class="cb-oc-seg" id="cb-oc-seg">
                <button class="cb-oc-btn" data-oc="0">常规</button>
                <button class="cb-oc-btn" data-oc="1">半蓝强击</button>
                <button class="cb-oc-btn all-in" data-oc="2">孤注一掷</button>
              </div>
            </div>
            <div id="b-log" class="cb-log-box"></div>
          </div>

          <div id="b-actions" class="cb-skills-grid"></div>

          <div class="cb-turn-col">
            <button class="cb-endturn-btn" id="cb-btn-endturn">
              <span class="cb-endturn-seal" aria-hidden="true">${CB_SVG.hourglass}</span>
              <span class="cb-endturn-main">结束回合 <span class="cb-kbd">E</span></span>
              <small>可留存 1 点 AP</small>
            </button>
          </div>
        </footer>
      </div>
      <div id="cb-modal-slot"></div>
    `;

    root.querySelector('#cb-oc-seg').onclick = e => {
      const btn = e.target.closest('[data-oc]');
      if (!btn || btn.disabled) return;
      setOvercast(Number(btn.getAttribute('data-oc')));
    };
    root.querySelector('#cb-btn-palace').onclick = () => openIcePalaceModal();
    root.querySelector('#cb-btn-wand').onclick = () => toggleEclipseWand();
    root.querySelector('#cb-btn-assist').onclick = () => useBondAssist();
    root.querySelector('#cb-btn-endturn').onclick = () => endTurn();
    root.querySelector('#cb-btn-retreat').onclick = () => exitBattle(false);

    return root;
  }

  function updateOvercastPreviewUI(b, refSkillId) {
    if (!b || b.headless || typeof document === 'undefined') return;
    const p = b.player;
    const ocMultEl = document.getElementById('cb-oc-mult');
    const commitBar = document.getElementById('cb-mp-commit');
    const forecastBar = document.getElementById('cb-forecast-bar');
    if (!ocMultEl || !commitBar) return;

    const mpPct = Math.max(0, Math.min(100, p.mp / Math.max(1, p.mmp) * 100));
    const pickId = refSkillId || p.skills.find(id => {
      const s = TACTICAL_SKILLS[id];
      return s && s.atkKind === 'matk' && s.power > 0 && !s.noOvercast;
    }) || 'hand_ice_crystal';
    const refSkill = TACTICAL_SKILLS[pickId] || TACTICAL_SKILLS.hand_ice_crystal;

    if (!p.hasManaCycle) {
      ocMultEl.textContent = '未习得';
      commitBar.style.width = '0%';
    } else {
      // 精确联动悬停技能或当前首个可用魔法技能的真实蓝耗（含 mana_calc -15% / 省魔手稿 与晦轮杖附加耗蓝）
      const realSpend = Math.min(p.mp, computeSkillMpCost(p, refSkill));
      const powerMp = Math.min(p.mp, computeOvercastPowerMp(p, refSkill));
      const realMult = computeManaCycleMultiplier(p, powerMp, refSkill);

      ocMultEl.textContent = `${refSkill.name} ${realMult.toFixed(2)}x (耗${realSpend})`;
      const spendPct = Math.min(mpPct, realSpend / Math.max(1, p.mmp) * 100);
      commitBar.style.left = `${Math.max(0, mpPct - spendPct)}%`;
      commitBar.style.width = `${spendPct}%`;
    }

    // 实时更新敌方血条预扣与上方战术预测条
    document.querySelectorAll('.cb-ehp-preview').forEach(el => {
      el.style.width = '0%';
      el.style.left = '0%';
    });

    if (forecastBar) {
      if (refSkillId && TACTICAL_SKILLS[refSkillId]) {
        const hoverSk = TACTICAL_SKILLS[refSkillId];
        const target = getPrimaryAliveEnemy(b);
        const fc = computeTacticalForecast(b, hoverSk, target);
        if (fc) {
          forecastBar.className = `cb-forecast-bar kind-${fc.kind}`;
          const dmgPart = fc.dmgMin > 0
            ? `伤害 <b>${fc.dmgMin}${fc.dmgMax > fc.dmgMin ? `~${fc.dmgMax}` : ''}</b>`
            : '战术增益/防反';
          const multPart = fc.dmgMin > 0
            ? `克制 <b>${fc.elemMult.toFixed(2)}×</b> · 魔战 <b>${fc.mcMult.toFixed(2)}×</b> · 回蓝 <b>+${fc.manaReturn}</b>`
            : `消耗 AP ${fc.apCost}${fc.mpCost > 0 ? ` · MP ${fc.mpCost}` : ''}`;
          forecastBar.innerHTML = `<span class="cfb-name">🎯 ${hoverSk.name}</span><span class="cfb-head">${fc.headline}</span><span class="cfb-meta">${dmgPart} · ${multPart}${fc.critChance > 0 && fc.dmgMin > 0 ? ` · 暴击 ${(fc.critChance * 100).toFixed(0)}%` : ''}</span>`;

          if (hoverSk.power > 0 && fc.dmgMin > 0) {
            const list = hoverSk.aoe ? b.enemies : (target ? [target] : []);
            list.forEach(eObj => {
              const eIdx = b.enemies.indexOf(eObj);
              if (eIdx < 0 || eObj.hp <= 0 || eObj.nonLethalSpar) return;
              const fcTarget = hoverSk.aoe ? computeTacticalForecast(b, hoverSk, eObj) : fc;
              const loss = (fcTarget && fcTarget.estHpLoss) || 0;
              if (loss <= 0) return;
              const prevEl = document.querySelector(`.cb-ehp-preview[data-eidx="${eIdx}"]`);
              if (prevEl) {
                const curPct = Math.max(0, Math.min(100, eObj.hp / Math.max(1, eObj.mhp) * 100));
                const lossPct = Math.min(curPct, loss / Math.max(1, eObj.mhp) * 100);
                prevEl.style.left = `${Math.max(0, curPct - lossPct)}%`;
                prevEl.style.width = `${lossPct}%`;
              }
            });
          }
        }
      } else if (p.status && p.status.breakChain > 0) {
        forecastBar.className = 'cb-forecast-bar kind-chain';
        forecastBar.innerHTML = '<span class="cfb-head">🔗【破招连携窗口已激活】本回合下一张非基础攻击牌享 1.35× 伤害并额外返还 15% 魔力！</span>';
      } else {
        forecastBar.className = 'cb-forecast-bar';
        forecastBar.textContent = '悬停任意技能卡，实时推演架势克制、破招截断、预计伤害与魔战回蓝';
      }
    }
  }

  function renderCombatUI() {
    const b = activeBattle;
    if (!b || b.headless || typeof document === 'undefined') return;
    const root = ensureBattleDOM();
    if (!root) return;

    const p = b.player;
    const stageAge = (b.fromArena && b.stageCfg && b.stageCfg.presetPlayer && b.stageCfg.presetPlayer.age) || null;
    root.classList.toggle('wand-refract', !!p.wandActive);
    root.classList.toggle('palace-timestop', !!document.getElementById('cb-palace-modal'));
    const backdropEl = document.getElementById('cb-backdrop');
    if (backdropEl) {
      backdropEl.style.backgroundImage = `url('${resolveBattleBgUrl(b.stageCfg)}')`;
    }

    document.getElementById('cb-wave').textContent = `WAVE ${b.waveIdx + 1}/${b.totalWaves}`;
    document.getElementById('cb-title').textContent = b.stageCfg.title;
    document.getElementById('cb-turn').textContent = b.stageCfg.turnLimit
      ? `第 ${b.turn}/${b.stageCfg.turnLimit} 回合`
      : `第 ${b.turn} 回合`;

    const meters = [];
    if (b.stageCfg.hitRule) {
      const pDots = '●'.repeat(b.playerHits) + '○'.repeat(Math.max(0, 3 - b.playerHits));
      const eDots = '●'.repeat(b.enemyHits) + '○'.repeat(Math.max(0, 3 - b.enemyHits));
      meters.push(`<div class="cb-meter-pill hit-counter">三击制：<b>我方 ${pDots}</b> vs <b>${eDots} 艾诺</b></div>`);
    }
    if (b.stageCfg.sealRule) {
      meters.push(`<div class="cb-meter-pill reno">合围封锁：<b>${b.sealProgress}%</b>${b.frostFloorTurns > 0 ? ' (薄冰已铺)' : ''}
        <span class="cb-mini-bar"><i style="width:${b.sealProgress}%;background:linear-gradient(90deg,#6eb5ff,#e6be5a)"></i></span></div>`);
    }
    if (b.witnessActive) {
      meters.push(`<div class="cb-meter-pill exposure${b.exposure >= 60 ? ' danger' : ''}">暴露风险：<b>${b.exposure}%</b>
        <span class="cb-mini-bar"><i style="width:${b.exposure}%;background:linear-gradient(90deg,#f59e42,#ef5b6c)"></i></span></div>`);
    }
    if (b.crateHp != null) {
      meters.push(`<div class="cb-meter-pill crate">医疗药箱：<b>${b.crateHp}/${b.crateMax}</b>
        <span class="cb-mini-bar"><i style="width:${b.crateHp}%;background:linear-gradient(90deg,#3da872,#7ef2b8)"></i></span></div>`);
    }
    if (b.stageCfg.ainoSupport) {
      meters.push(`<div class="cb-meter-pill aino-aid">艾诺冰枪共鸣：<b>${b.ainoResonance}/2</b></div>`);
    }
    document.getElementById('cb-meters').innerHTML = meters.join('');

    const palBtn = document.getElementById('cb-btn-palace');
    if (p.palaceMax <= 0) {
      palBtn.innerHTML = `${CB_SVG.crystal} 冰晶宫殿（未习得）`;
      palBtn.disabled = true;
      palBtn.classList.remove('pulse-hint', 'gathering');
    } else if (p.palaceLeft > 0 && (b.waveTurn || 1) < 2) {
      palBtn.innerHTML = `${CB_SVG.crystal} 冰晶宫殿·凝结采集中 (${p.palaceLeft}/${p.palaceMax})`;
      palBtn.title = '须先观察敌方本波至少出手一轮，第 2 回合起可开启时停复盘';
      palBtn.disabled = true;
      palBtn.classList.remove('pulse-hint');
      palBtn.classList.add('gathering');
    } else if (p.palaceLeft > 0) {
      palBtn.innerHTML = `${CB_SVG.crystal} 冰晶宫殿 (${p.palaceLeft}/${p.palaceMax}) <span class="cb-kbd">Q</span>`;
      palBtn.title = '冻结当前交锋帧，两步推演敌方招式死角';
      palBtn.disabled = b.over;
      palBtn.classList.remove('gathering');
      palBtn.classList.toggle('pulse-hint', !b.over);
    } else {
      palBtn.innerHTML = `${CB_SVG.crystal} 冰晶宫殿 (0/${p.palaceMax})${b.waveIdx + 1 < b.totalWaves ? ' · 下波重置' : ''}`;
      palBtn.title = b.waveIdx + 1 < b.totalWaves ? '本波已审视，进入下一波将重新凝结 1 次机会' : '本场审视机会已用尽';
      palBtn.disabled = true;
      palBtn.classList.remove('pulse-hint', 'gathering');
    }

    const wBtn = document.getElementById('cb-btn-wand');
    if (p.hasEclipseWand) {
      wBtn.classList.remove('hidden');
      wBtn.classList.toggle('active', !!p.wandActive);
      wBtn.innerHTML = p.wandCooldown > 0
        ? `${CB_SVG.wand} 晦轮杖（冷却${p.wandCooldown}）`
        : p.wandActive
          ? `${CB_SVG.wand} 晦轮杖：折光 ON <span class="cb-kbd">R</span>`
          : `${CB_SVG.wand} 晦轮杖：收鞘 <span class="cb-kbd">R</span>`;
      wBtn.disabled = b.over || p.wandCooldown > 0;
    } else {
      wBtn.classList.add('hidden');
    }

    const assistBtn = document.getElementById('cb-btn-assist');
    if (assistBtn) {
      const api = getRelicsApi();
      const aMeta = p.bondAssist && api && api.BOND_ASSISTS ? api.BOND_ASSISTS[p.bondAssist] : null;
      if (aMeta) {
        assistBtn.classList.remove('hidden');
        assistBtn.disabled = b.over || !!p.bondAssistUsed;
        assistBtn.title = `${aMeta.effectDesc} — ${aMeta.quote}`;
        assistBtn.innerHTML = p.bondAssistUsed
          ? `${aMeta.icon} ${aMeta.title} (已援护)`
          : `${aMeta.icon} ${aMeta.name}·${aMeta.title} <span class="cb-kbd">F</span>`;
      } else {
        assistBtn.classList.add('hidden');
      }
    }

    const pane = document.getElementById('cb-player-pane');
    pane.classList.toggle('rooted-aura', !!(p.status.rooted || p.shield > 0));
    pane.classList.toggle('wand-aura', !!p.wandActive);

    const pImg = resolveCharImg('sylvia', p.hp < p.mhp * 0.4 ? 'serious' : 'normal', stageAge);
    const pPortEl = document.getElementById('cb-p-portrait');
    pPortEl.classList.toggle('is-svg', !pImg);
    pPortEl.innerHTML = pImg ? `<img src="${pImg}" alt="希尔维亚"/>` : renderBeastCrestSVG('wolf');
    document.getElementById('cb-p-name').textContent = p.name;
    document.getElementById('cb-p-sub').textContent = `物攻 ${p.atk} · 魔攻 ${p.matk} · 双抗 ${p.def}/${p.mdef}`;

    let gemsHtml = '';
    for (let i = 0; i < b.apMax; i++) {
      gemsHtml += `<span class="cb-ap-gem${i < b.ap ? ' on' : ''}"></span>`;
    }
    gemsHtml += `<span class="cb-ap-label">AP ${b.ap}/${b.apMax}</span>`;
    document.getElementById('cb-ap-row').innerHTML = gemsHtml;

    document.getElementById('cb-php-txt').textContent = `${p.hp}/${p.mhp}${p.shield > 0 ? ` (+盾${p.shield})` : ''}`;
    document.getElementById('cb-php-bar').style.width = `${Math.max(0, Math.min(100, p.hp / p.mhp * 100))}%`;
    document.getElementById('cb-pmp-txt').textContent = `${p.mp}/${p.mmp}`;
    document.getElementById('cb-pmp-bar').style.width = `${Math.max(0, Math.min(100, p.mp / p.mmp * 100))}%`;

    const buffs = [];
    if (p.shield > 0) buffs.push(`<span class="cb-buff-chip shield">护盾 ${p.shield}/${p.maxShield}</span>`);
    if (p.status.breakChain > 0) buffs.push(`<span class="cb-buff-chip gold chain-active">✦ 连携追击 1.35×</span>`);
    if (p.status.frostPierce > 0) buffs.push(`<span class="cb-buff-chip">透冰破抗 25%</span>`);
    if (p.status.zeroMpThisTurn > 0) buffs.push(`<span class="cb-buff-chip gold">本回合零耗蓝</span>`);
    if (p.status.nobleReflect > 0) buffs.push(`<span class="cb-buff-chip gold">冰镜反震</span>`);
    if (b.frostFloorTurns > 0) buffs.push(`<span class="cb-buff-chip">地面薄冰(${b.frostFloorTurns})</span>`);
    if (p.status.rooted > 0) buffs.push(`<span class="cb-buff-chip">下盘生根</span>`);
    if (p.status.afterimage > 0) buffs.push(`<span class="cb-buff-chip">残像闪避×${p.status.afterimage}</span>`);
    if (p.status.lungeParry > 0) buffs.push(`<span class="cb-buff-chip">侧滑待反</span>`);
    if (p.status.poise > 0) buffs.push(`<span class="cb-buff-chip gold">剑势蓄力</span>`);
    if (p.passives.includes('temp_sense')) buffs.push(`<span class="cb-buff-chip">温度感知</span>`);
    if (p.passives.includes('mana_calc')) buffs.push(`<span class="cb-buff-chip">魔力精算-15%</span>`);
    if (p.passives.includes('root_ice')) buffs.push(`<span class="cb-buff-chip">生根之冰</span>`);
    if (p.passives.includes('frost_edge')) buffs.push(`<span class="cb-buff-chip">覆冰锋+18%</span>`);
    if (p.passives.includes('instant_ice')) buffs.push(`<span class="cb-buff-chip">隔空凝冰</span>`);
    if (p.relics && p.relics.length) {
      const api = getRelicsApi();
      p.relics.forEach(rid => {
        const rm = api && api.RELICS && api.RELICS[rid];
        if (rm) buffs.push(`<span class="cb-buff-chip relic" title="${rm.effectText}">✦ ${rm.name}</span>`);
      });
    }
    if (p.status.blind > 0) buffs.push(`<span class="cb-buff-chip debuff">视线受阻×${p.status.blind}</span>`);
    if (p.status.burn > 0) buffs.push(`<span class="cb-buff-chip debuff">灼烧(${p.status.burn})</span>`);
    document.getElementById('cb-p-buffs').innerHTML = buffs.join('');

    root.querySelectorAll('#cb-oc-seg .cb-oc-btn').forEach(btn => {
      const m = Number(btn.getAttribute('data-oc'));
      btn.disabled = !p.hasManaCycle || b.over;
      btn.classList.toggle('active', p.hasManaCycle && p.overcastMode === m);
    });

    const primary = getPrimaryAliveEnemy(b);
    if (primary) {
      document.getElementById('b-emoji').textContent = primary.emoji || '';
      document.getElementById('b-ename').textContent = primary.name;
      document.getElementById('b-ehp').style.width = `${Math.max(0, primary.hp / primary.mhp * 100)}%`;
      document.getElementById('b-ehp-num').textContent = `${primary.hp}/${primary.mhp}`;
    }

    const showNextTendency = hasRelic(p, 'belmont_schedule');
    const eZone = document.getElementById('cb-enemy-zone');
    eZone.classList.toggle('multi-enemies', b.enemies.length > 1);
    eZone.innerHTML = b.enemies.map((e, idx) => {
      const intent = e.intent || { stance: 'STAGGERED', moveName: '已倒下', dmg: 0 };
      const sm = STANCE_META[intent.stance] || STANCE_META.HEAVY_WINDUP;
      const eImg = e.charId ? resolveCharImg(e.charId, 'normal', stageAge) : null;
      const eBuffs = [];
      if (e.shield > 0) eBuffs.push(`<span class="cb-buff-chip shield">护盾 ${e.shield}</span>`);
      if (e.fireAura > 0) eBuffs.push(`<span class="cb-buff-chip gold">烈焰斗气×${e.fireAura}</span>`);
      if (e.evadeCharges > 0) eBuffs.push(`<span class="cb-buff-chip">闪避层×${e.evadeCharges}</span>`);
      if (e.status.evadeSealed > 0) eBuffs.push(`<span class="cb-buff-chip debuff">风步已封(${e.status.evadeSealed})</span>`);
      if (e.flawToken > 0) eBuffs.push(`<span class="cb-buff-chip gold">下击破绽+20%</span>`);
      if (e.seepStacks > 0 && !e.seepSevered) eBuffs.push(`<span class="cb-buff-chip debuff">暗水线×${e.seepStacks}</span>`);
      if (e.seepSevered) eBuffs.push(`<span class="cb-buff-chip">暗流已冻绝</span>`);
      if (e.status.vuln > 0) eBuffs.push(`<span class="cb-buff-chip gold">易伤(${e.status.vuln})</span>`);
      if (e.status.chill > 0) eBuffs.push(`<span class="cb-buff-chip">寒颤(${e.status.chill})</span>`);

      const nextLine = (showNextTendency && e.hp > 0)
        ? `<div class="ib-next-tendency">✦ 下回合预判：${predictNextIntentTendency(e, b)}</div>`
        : '';

      return `
        <article class="cb-enemy-card${idx === b.targetIdx ? ' targeted' : ''}${e.hp <= 0 ? ' dead' : ''}${intent.stance === 'STAGGERED' ? ' staggered' : ''}" data-eidx="${idx}">
          <div class="cb-intent-banner stance-${intent.stance}">
            <div class="ib-top">
              <span>${sm.badge}</span>
              <span class="ib-dmg-pill">${intent.dmg > 0 ? `预计 ${intent.dmg}${intent.shatterPlayerShield ? ' · 碎盾' : ''}` : '蓄势 / 失衡'}</span>
            </div>
            <div class="ib-hint">招式：<b>${intent.moveName}</b> · ${sm.hint}</div>
            ${nextLine}
          </div>

          <div class="cb-e-stage">
            <div class="cb-magic-circle enemy" aria-hidden="true"></div>
            <div class="cb-e-avatar${eImg ? '' : ' is-svg'}">${eImg ? `<img src="${eImg}" alt="${e.name}"/>` : renderBeastCrestSVG(e.aiType || e.name)}</div>
          </div>

          <div class="cb-e-plate">
            <div class="cb-e-info">
              <div class="cb-e-name">
                <span>${e.name}</span>
                <span class="cb-elem-tag elem-${e.elem || 'phys'}">${ELEM_LABEL[e.elem] || '剑术'}</span>
              </div>
              <div class="cb-e-trait">${e.trait || ''}</div>
            </div>
            <div class="cb-bars-wrap">
              <div class="cb-stat-row">
                <div class="cb-stat-top"><span>${e.nonLethalSpar ? '切磋耐力（三击制决胜）' : '敌方生命'}</span><span>${e.nonLethalSpar ? '点到为止' : `${e.hp}/${e.mhp}`}${e.shield ? ` (+盾${e.shield})` : ''}</span></div>
                <div class="cb-stat-track">
                  <div class="cb-stat-fill ehp" style="width:${e.nonLethalSpar ? 100 : Math.max(0, e.hp / e.mhp * 100)}%"></div>
                  <div class="cb-ehp-preview" data-eidx="${idx}"></div>
                </div>
              </div>
              ${e.mmp != null ? `
              <div class="cb-stat-row">
                <div class="cb-stat-top"><span>敌方魔力</span><span>${e.mp}/${e.mmp}</span></div>
                <div class="cb-stat-track"><div class="cb-stat-fill emp" style="width:${Math.max(0, e.mp / e.mmp * 100)}%"></div></div>
              </div>` : ''}
            </div>
            <div class="cb-buff-list">${eBuffs.join('')}</div>
          </div>
        </article>
      `;
    }).join('');

    updateOvercastPreviewUI(b, hoveredSkillId);

    eZone.querySelectorAll('.cb-enemy-card').forEach(card => {
      card.onclick = () => {
        const idx = Number(card.getAttribute('data-eidx'));
        if (b.enemies[idx] && b.enemies[idx].hp > 0) {
          b.targetIdx = idx;
          renderCombatUI();
        }
      };
    });

    const logEl = document.getElementById('b-log');
    logEl.innerHTML = b.log.join('<br>');
    logEl.scrollTop = logEl.scrollHeight;

    const actGrid = document.getElementById('b-actions');
    actGrid.classList.toggle('cards-compact', p.skills.length > 6);
    actGrid.classList.toggle('cols-5', p.skills.length >= 9);
    const targetStance = primary && primary.intent ? primary.intent.stance : '';
    actGrid.innerHTML = p.skills.map((skId, slotIdx) => {
      const sk = TACTICAL_SKILLS[skId];
      if (!sk) return '';
      const pm = PATH_META[sk.path] || PATH_META.HAND;
      const apCost = computeSkillApCost(b, sk);
      const costMp = computeSkillMpCost(p, sk);
      const cd = p.cooldowns[skId] || 0;
      const usedUp = sk.maxUses && (p.usedMaxSkills[skId] || 0) >= sk.maxUses;
      const disabled = b.over || usedUp || cd > 0 || b.ap < apCost || p.mp < costMp;
      const est = sk.power > 0 ? estimateSkillDamage(b, sk, primary) : null;

      let oppBadge = '';
      if (!disabled && sk.path === 'REMOTE' && targetStance === 'DUAL_CAST') {
        oppBadge = '<span class="cb-opp-pill">✦ 可破招</span>';
      } else if (!disabled && sk.path === 'SWORD' && (sk.dodgeLunge || sk.counterLunge) && targetStance === 'CLOSE_LUNGE') {
        oppBadge = '<span class="cb-opp-pill">✦ 可闪反</span>';
      } else if (!disabled && sk.path === 'INSIGHT') {
        oppBadge = '<span class="cb-opp-pill">✦ 必杀看破</span>';
      } else if (!disabled && est && est.chainApplied) {
        oppBadge = '<span class="cb-opp-pill chain">✦ 连携1.35×</span>';
      }

      let expHint = '';
      if (b.witnessActive) {
        let expVal = (sk.exposure || 0) + (p.wandActive && sk.power > 0 && !sk.aoe && sk.atkKind === 'matk' ? 55 : 0);
        if (hasRelic(p, 'ebony_sword') && sk.path === 'SWORD') expVal = Math.min(0, expVal);
        expHint = expVal > 0
          ? `<span class="csc-exp-warn">暴露+${expVal}%</span>`
          : `<span class="csc-exp-safe">隐蔽安全</span>`;
      }

      const keyHint = slotIdx < 9 ? `<span class="cb-kbd">${slotIdx + 1}</span> ` : '';
      const compactPath = p.skills.length > 6 ? pm.short.slice(0, 2) : pm.short;

      return `
        <button class="cb-skill-card path-${sk.path}${oppBadge ? ' opp-glow' : ''}" data-sk="${sk.id}" ${disabled ? 'disabled' : ''}>
          ${oppBadge}
          <div>
            <div class="csc-head">
              <span class="csc-path">${keyHint}${compactPath}</span>
              <span class="csc-cost">AP ${apCost}${costMp > 0 ? ` · MP ${costMp}` : ''}</span>
            </div>
            <div class="csc-name">${sk.name}</div>
            <div class="csc-desc">${sk.desc}</div>
          </div>
          <div class="csc-foot">
            <span>${usedUp ? '已使用' : cd > 0 ? `冷却 ${cd} 回合` : est ? (est.mirrorBlocked ? '将被镜冰格挡' : `预计 ~${est.dmg}${sk.aoe ? ' (全体)' : ''}`) : '战术护卫 / 步法'}</span>
            ${expHint}
          </div>
        </button>
      `;
    }).join('');

    const syncHoverEnemyGlow = sid => {
      eZone.querySelectorAll('.cb-enemy-card').forEach(card => card.classList.remove('counter-target-glow'));
      if (!sid) return;
      const sk = TACTICAL_SKILLS[sid];
      if (!sk) return;
      const targets = sk.aoe ? b.enemies : (primary ? [primary] : []);
      targets.forEach(en => {
        if (!en || en.hp <= 0) return;
        const estH = sk.power > 0 ? estimateSkillDamage(b, sk, en) : null;
        const canBreak = (estH && (estH.willInterrupt || estH.willRiposte))
          || (sk.dodgeLunge && en.intent && en.intent.stance === 'CLOSE_LUNGE');
        if (canBreak) {
          const cardEl = eZone.querySelector(`.cb-enemy-card[data-eidx="${b.enemies.indexOf(en)}"]`);
          if (cardEl) cardEl.classList.add('counter-target-glow');
        }
      });
    };

    actGrid.querySelectorAll('.cb-skill-card').forEach(btn => {
      const sid = btn.getAttribute('data-sk');
      btn.onmouseenter = () => { hoveredSkillId = sid; updateOvercastPreviewUI(b, sid); syncHoverEnemyGlow(sid); };
      btn.onfocus = () => { hoveredSkillId = sid; updateOvercastPreviewUI(b, sid); syncHoverEnemyGlow(sid); };
      btn.onmouseleave = () => { hoveredSkillId = null; updateOvercastPreviewUI(b, null); syncHoverEnemyGlow(null); };
      btn.onclick = () => {
        if (btn.disabled) return;
        useSkill(sid);
      };
    });

    if (b._pendingHitPulses && b._pendingHitPulses.length) {
      const pulses = b._pendingHitPulses.slice();
      b._pendingHitPulses.length = 0;
      pulses.forEach(pt => {
        const el = pt.side === 'player'
          ? document.getElementById('cb-p-portrait')
          : eZone.querySelector(`.cb-enemy-card[data-eidx="${pt.enemyIdx}"] .cb-e-avatar`);
        if (el) {
          el.classList.remove('cb-unit-hit');
          void el.offsetWidth;
          el.classList.add('cb-unit-hit');
          setTimeout(() => el.classList.remove('cb-unit-hit'), 380);
        }
      });
    }

    document.getElementById('cb-btn-endturn').disabled = b.over;
  }

  function openIcePalaceModal() {
    const b = activeBattle;
    if (!b || !isPalaceReady(b) || typeof document === 'undefined') return;
    const slot = document.getElementById('cb-modal-slot');
    if (!slot) return;
    const battleRoot = document.getElementById('battle-screen');
    if (battleRoot) battleRoot.classList.add('palace-timestop');
    const pCfg = getCurrentPalaceConfig(b);
    const shuffledClues = shuffleCopy(pCfg.clues || []);

    const closeModal = () => {
      slot.innerHTML = '';
      if (battleRoot) battleRoot.classList.remove('palace-timestop');
    };

    const renderStep1 = () => {
      slot.innerHTML = `
        <div class="cb-palace-modal" id="cb-palace-modal">
          <div class="cb-palace-card" id="cb-palace-card">
            <div class="cp-kicker">ICE PALACE · TIME-STOP COGNITION</div>
            <h3 class="cp-title">冰晶宫殿 · 时停审视</h3>
            <div class="cp-scene-desc">${pCfg.sceneText}</div>
            <span class="cp-step-pill">第 1 / 2 步 · 锁定定格异常细节（选错将损耗 1 AP）</span>
            <div class="cp-options">
              ${shuffledClues.map((c, idx) => `
                <button class="cp-opt-btn" data-clue="${c.id}"><b>观察点 ${idx + 1}：</b>${c.text}</button>
              `).join('')}
            </div>
            <div class="end-btns" style="margin-top:14px">
              <button class="tbtn ghost" id="cp-cancel">暂不消耗（返回战局）</button>
            </div>
          </div>
        </div>
      `;
      slot.querySelector('#cp-cancel').onclick = () => closeModal();
      slot.querySelectorAll('[data-clue]').forEach(btn => {
        btn.onclick = () => {
          const cid = btn.getAttribute('data-clue');
          const picked = (pCfg.clues || []).find(x => x.id === cid);
          if (!picked || !picked.correct) {
            const res = inspectClue(cid, null, b);
            renderFinalFeedback(res);
            return;
          }
          // 一旦点击第 1 步即锁定扣除本波审视机会，防止进入第 2 步后按 Esc 零成本白嫖答案与重刷洗牌！
          b.player.palaceLeft = Math.max(0, b.player.palaceLeft - 1);
          b.palacePendingStep2 = { clueId: cid };
          renderCombatUI();
          renderStep2(cid, picked.feedback);
        };
      });
    };

    const renderStep2 = (clueId, step1Feedback) => {
      const shuffledDeds = shuffleCopy(pCfg.deductions || []);
      const card = slot.querySelector('#cb-palace-card');
      card.innerHTML = `
        <div class="cp-kicker">ICE PALACE · TACTICAL DEDUCTION</div>
        <h3 class="cp-title">冰晶宫殿 · 推演反制落点</h3>
        <div class="cp-scene-desc">${step1Feedback}</div>
        <span class="cp-step-pill">第 2 / 2 步 · 推导针对性破招手段</span>
        <div class="cp-options">
          ${shuffledDeds.map((d, idx) => `
            <button class="cp-opt-btn" data-ded="${d.id}"><b>战术推演 ${idx + 1}：</b>${d.text}</button>
          `).join('')}
        </div>
      `;
      card.querySelectorAll('[data-ded]').forEach(btn => {
        btn.onclick = () => {
          const did = btn.getAttribute('data-ded');
          const res = inspectClue(clueId, did, b);
          renderFinalFeedback(res);
        };
      });
    };

    const renderFinalFeedback = res => {
      const card = slot.querySelector('#cb-palace-card');
      if (!card) return;
      if (res.correct) {
        card.classList.add('shatter-win');
        triggerPalaceFlash();
      }
      card.innerHTML = `
        <div class="cp-kicker">${res.correct ? 'FLAW EXPOSED · 冰镜破局' : 'OBSERVATION · 推演受挫'}</div>
        <h3 class="cp-title">${res.correct ? '✦ 破绽推演完成' : '未能锁定真死角'}</h3>
        <div class="cp-scene-desc">${res.feedback || ''}</div>
        <div class="end-btns">
          <button class="tbtn" id="cp-confirm">回到交锋</button>
        </div>
      `;
      const confirmBtn = card.querySelector('#cp-confirm');
      confirmBtn.onclick = () => {
        closeModal();
        renderCombatUI();
      };
      confirmBtn.focus();
    };

    renderStep1();
  }

  function showResultModal(b) {
    if (typeof document === 'undefined') return;
    const slot = document.getElementById('cb-modal-slot');
    if (!slot) return;
    const rew = b.stageCfg.reward || {};
    const warnHtml = b.exposureWarningTriggered
      ? `<div class="cr-warn-box">⚠️ <b>行踪暴露代价触发：</b>耳目附近的外显冰系/晦轮杖波动已被「极光」小队察觉，「北林哑巴幽灵」传闻发酵，本次评级封顶为 B！</div>`
      : '';

    let rewardText = '';
    if (b.won) {
      if (b.fromArena) {
        rewardText = '独立演武沙盒挑战完成！战绩已记入演武榜（沙盒模式不改动主线存档数值）。';
      } else {
        rewardText = `获得实战收益：${rew.skillName ? `习得「<b>${rew.skillName}</b>」 · ` : ''}经验 +${rew.exp || 30}${rew.gold ? ` · 银币 +${rew.gold}` : ''}`;
      }
    } else {
      rewardText = b.endReason === 'rowan_escaped'
        ? '失利原因：未满 100% 合围封锁便打空罗文生命，致其借晦轮杖化雾遁逃！'
        : '战术提示：紧盯敌方架势预告，切忌无脑复读单招或原地龟缩叠盾！';
    }

    slot.innerHTML = `
      <div class="cb-result-modal" id="cb-result-modal">
        <div class="cb-result-card">
          <div style="font-size:11.5px;letter-spacing:.2em;color:var(--cb-ice)">${b.won ? 'TACTICAL VICTORY · 战术结算' : 'DEFEAT · 战局失利'}</div>
          <h2 style="margin:6px 0;color:#fff;font-size:21px;font-family:var(--font-serif,'Noto Serif SC',serif)">${b.stageCfg.title}</h2>
          <div class="cr-grade">${b.won ? b.grade : '败'}</div>
          <div class="cr-metrics">
            <div><span>战斗回合</span><b>${b.turn} 回合</b></div>
            <div><span>截断破招</span><b>${b.metrics.interrupts} 次</b></div>
            <div><span>剑步闪反</span><b>${b.metrics.ripostes} 次</b></div>
            <div><span>冰宫看破</span><b>${b.metrics.insights} 次</b></div>
            <div><span>魔战回蓝</span><b>+${b.metrics.manaRecycled} MP</b></div>
            <div><span>最高倾注</span><b>${b.metrics.maxOvercastMult.toFixed(2)}x</b></div>
          </div>
          ${warnHtml}
          <p style="font-size:13px;opacity:.88;margin-bottom:12px">${rewardText}</p>
          <div class="end-btns">
            <button class="tbtn ghost" id="cr-retry">再次演练</button>
            <button class="tbtn" id="cr-done">确认返回</button>
          </div>
        </div>
      </div>
    `;

    slot.querySelector('#cr-retry').onclick = () => {
      slot.innerHTML = '';
      if (STAGE_CONFIGS[b.id]) {
        startStage(b.id, { fromArena: b.fromArena, done: b.done });
      } else {
        startCustomOrStageBattle(b._customCfg || {}, b.done);
      }
    };
    const doneBtn = slot.querySelector('#cr-done');
    doneBtn.onclick = () => {
      slot.innerHTML = '';
      exitBattle(b.won);
    };
    doneBtn.focus();
  }

  function exitBattle(won, opts) {
    opts = opts || {};
    const b = activeBattle;
    activeBattle = null;
    hoveredSkillId = null;
    if (typeof global.B !== 'undefined') global.B = null;
    if (typeof document === 'undefined') return;

    const slot = document.getElementById('cb-modal-slot');
    if (slot) slot.innerHTML = '';
    const bs = document.getElementById('battle-screen');
    if (bs) {
      bs.classList.add('hidden');
      bs.classList.remove('palace-timestop', 'wand-refract', 'hit-shake', 'heavy-shake');
    }
    const ds = document.getElementById('duel-screen');
    if (ds) ds.classList.add('hidden');

    if (opts.silent) {
      const ao = document.getElementById('arena-overlay');
      if (ao) ao.classList.add('hidden');
      return;
    }

    if (b && b.fromArena) {
      if (arenaReturnToTitle) {
        if (typeof global.bgmStop === 'function') global.bgmStop(false);
        if (typeof global.setBG === 'function') global.setBG('bg-title');
      } else {
        if (typeof global.bgmRestoreScene === 'function') global.bgmRestoreScene();
        const curS = getGameS();
        if (curS && curS.freeRoam && typeof global.updateLocBar === 'function') global.updateLocBar();
      }
      openArenaHub({ fromTitle: arenaReturnToTitle });
      return;
    }

    if (typeof global.bgmEndBattle === 'function') global.bgmEndBattle();
    const curS = getGameS();
    if (curS && curS.freeRoam && typeof global.updateLocBar === 'function') {
      global.updateLocBar();
    }

    if (b && typeof b.done === 'function') {
      b.done(won);
      return;
    }
    if (curS && curS.freeRoam && typeof global.enterFreeRoam === 'function') {
      global.enterFreeRoam();
    }
  }

  /* =========================================================
     9. ⚔️ 战术演武场独立沙盒大厅
     ========================================================= */
  function openArenaHub(opts) {
    opts = opts || {};
    if (typeof document === 'undefined') return;
    const titleScr = document.getElementById('title-screen');
    if (opts.fromTitle !== undefined) {
      arenaReturnToTitle = !!opts.fromTitle;
    } else {
      arenaReturnToTitle = !!(titleScr && !titleScr.classList.contains('hidden'));
    }
    if (arenaReturnToTitle) arenaUseSaveStats = false;

    const ov = document.getElementById('arena-overlay');
    if (!ov) return;
    const records = loadArenaRecords();
    const list = Object.values(STAGE_CONFIGS).sort((a, b) => a.order - b.order);
    const api = getRelicsApi();
    const loadoutBarHtml = (!arenaUseSaveStats && api && api.renderArenaLoadoutBarHTML) ? api.renderArenaLoadoutBarHTML() : '';

    ov.innerHTML = `
      <div class="arena-hub-card">
        <div class="arena-hub-head">
          <div class="arena-title-row">
            <div class="arena-title-crest" aria-hidden="true">${CB_SVG.swords}</div>
            <div>
              <h2 class="arena-hub-title">战术演武场 · 七幕智斗试炼</h2>
              <p class="arena-hub-sub">按原著时间线还原 7 场代表性关卡 · 独立试炼沙盒（不污染主线存档等级与银币）</p>
            </div>
          </div>
          <div class="arena-mode-bar">
            <span class="arena-sandbox-pill">${CB_SVG.shield} 独立沙盒 · 零存档污染</span>
            <button class="arena-mode-chip${!arenaUseSaveStats ? ' active' : ''}" id="am-preset">${CB_SVG.scale} 原著时期标准配装</button>
            <button class="arena-mode-chip${arenaUseSaveStats ? ' active' : ''}" id="am-save" ${arenaReturnToTitle ? 'disabled title="进入存档后可检验当前构筑"' : ''}>${CB_SVG.chart} 当前存档属性试演</button>
            <button class="arena-close-x" id="am-close" title="关闭演武大厅" aria-label="关闭演武大厅">×</button>
          </div>
        </div>
        <div class="arena-scroll-body">
          ${loadoutBarHtml}
          <div class="arena-stage-grid" id="arena-stage-grid">
            ${list.map(st => {
              const rec = records[st.id];
              const stageAge = (st.presetPlayer && st.presetPlayer.age) || 14;
              const img = st.charId ? resolveCharImg(st.charId, 'normal', stageAge) : null;
              return `
                <button class="arena-stage-card" data-stage="${st.id}">
                  <div>
                    <div class="asc-top">
                      <div class="asc-avatar${img ? '' : ' is-svg'}">${img ? `<img src="${img}" alt="${st.title}"/>` : renderBeastCrestSVG('wolf')}</div>
                      <div class="asc-meta">
                        <div class="asc-chap">${st.chapter}</div>
                        <div class="asc-name">${st.order}. ${st.title}</div>
                        <div class="asc-stars">难度 ${st.stars}</div>
                      </div>
                      <div class="asc-rank-badge ${rec ? 'rank-' + rec.grade : ''}">${rec ? rec.grade : '—'}</div>
                    </div>
                    <div class="asc-tags">
                      ${st.tags.map(t => `<span class="asc-tag${t.includes('禁') || t.includes('失败') || t.includes('绕过') ? ' warn' : ''}">${t}</span>`).join('')}
                    </div>
                    <div class="asc-desc">${st.summary}</div>
                  </div>
                  <div class="asc-foot">
                    <span>${rec ? `最佳记录：${rec.grade} 级（${rec.turns} 回合）` : '尚未通关'}</span>
                    <span class="asc-go">开始演武 ▸</span>
                  </div>
                </button>
              `;
            }).join('')}
          </div>
        </div>
      </div>
    `;

    ov.classList.remove('hidden');
    if (typeof global.sfx === 'function') global.sfx('open');

    ov.querySelector('#am-preset').onclick = () => { arenaUseSaveStats = false; openArenaHub({ fromTitle: arenaReturnToTitle }); };
    ov.querySelector('#am-save').onclick = () => {
      if (arenaReturnToTitle) return;
      arenaUseSaveStats = true;
      openArenaHub({ fromTitle: false });
    };
    ov.querySelector('#am-close').onclick = () => closeArenaHub();
    const openLoadoutBtn = ov.querySelector('#am-open-loadout');
    if (openLoadoutBtn && api && api.openArenaLoadoutModal) {
      openLoadoutBtn.onclick = () => api.openArenaLoadoutModal(() => openArenaHub({ fromTitle: arenaReturnToTitle }));
    }
    const clearLoadoutBtn = ov.querySelector('#am-clear-loadout');
    if (clearLoadoutBtn && api) {
      clearLoadoutBtn.onclick = () => {
        if (api.setArenaSandboxRelics) api.setArenaSandboxRelics([]);
        if (api.setArenaSandboxAssist) api.setArenaSandboxAssist(null);
        openArenaHub({ fromTitle: arenaReturnToTitle });
      };
    }
    ov.querySelectorAll('[data-stage]').forEach(btn => {
      btn.onclick = () => {
        const sid = btn.getAttribute('data-stage');
        ov.classList.add('hidden');
        startStage(sid, { fromArena: true });
      };
    });
  }

  function closeArenaHub() {
    if (typeof document === 'undefined') return;
    const ov = document.getElementById('arena-overlay');
    if (ov) ov.classList.add('hidden');
    if (arenaReturnToTitle) {
      if (typeof global.bgmStop === 'function') global.bgmStop(false);
      if (typeof global.setBG === 'function') global.setBG('bg-title');
      const ts = document.getElementById('title-screen');
      if (ts) ts.classList.remove('hidden');
    }
  }

  /* =========================================================
     10. 启动入口、主线虚拟决斗原著门控与无头仿真器
     ========================================================= */
  function startStage(stageId, opts) {
    opts = opts || {};
    const sc = STAGE_CONFIGS[stageId];
    if (!sc) return null;

    const b = createBattleState(sc, opts);
    activeBattle = b;
    hoveredSkillId = null;
    if (typeof global !== 'undefined') global.B = b;

    if (!b.headless && typeof document !== 'undefined') {
      const ds = document.getElementById('duel-screen');
      if (ds) ds.classList.add('hidden');
      if (typeof global.setBG === 'function') global.setBG(sc.bg || 'bg-battle');
      if (typeof global.bgmPlayType === 'function') global.bgmPlayType('battle', { force: true });
      const bs = ensureBattleDOM();
      if (bs) {
        const slot = bs.querySelector('#cb-modal-slot');
        if (slot) slot.innerHTML = '';
        bs.classList.remove('hidden');
      }
      renderCombatUI();
    }
    return b;
  }

  function startCustomOrStageBattle(cfg, done) {
    cfg = cfg || {};
    if (cfg.stageId && STAGE_CONFIGS[cfg.stageId]) {
      return startStage(cfg.stageId, {
        done,
        fromArena: !!cfg.fromArena,
        usePreset: !!cfg.usePreset,
        fullRestore: !!cfg.fullRestore,
      });
    }
    const tplMap = getEnemyTplMap() || {};
    const t = tplMap[cfg.tpl] || cfg;
    const curS = getGameS();
    const lv = (curS && curS.lv) || 10;
    const scale = cfg.scale || 1;
    const customStage = {
      id: 'custom_' + (cfg.tpl || 'encounter'),
      order: 99,
      title: `${t.name || '魔物'} · 遭遇战`,
      chapter: '野外实战',
      stars: '★★☆☆☆',
      emoji: t.emoji || '🐺',
      bg: 'bg-battle',
      tags: ['架势博弈'],
      summary: t.desc || '野外魔物遭遇。',
      reward: { exp: t.exp || 30, gold: t.gold || 6 },
      waves: [
        {
          intro: `${t.name || '魔物'}拦住了去路！留意其架势预告徽章。`,
          enemies: [
            {
              id: 'enc_0',
              name: t.name || '魔物',
              emoji: t.emoji || '🐺',
              elem: t.elem || 'wind',
              hp: Math.max(70, Math.round(((t.hp || 55) + lv * 2) * scale)),
              mhp: Math.max(70, Math.round(((t.hp || 55) + lv * 2) * scale)),
              atk: Math.max(20, Math.round(((t.atk || 14) + lv * 0.6) * scale)),
              def: t.def || 5,
              mdef: t.mdef || 5,
              trait: t.desc || '留意双手蓄势空档与贴身扑击。',
              aiType: 'generic',
            },
          ],
        },
      ],
    };
    const b = createBattleState(customStage, { done, usePreset: false, fromArena: false });
    b._customCfg = cfg;
    activeBattle = b;
    global.B = b;
    if (typeof global.setBG === 'function') global.setBG('bg-battle');
    if (typeof global.bgmPlayType === 'function') global.bgmPlayType('battle', { force: true });
    const bs = ensureBattleDOM();
    if (bs) bs.classList.remove('hidden');
    renderCombatUI();
    return b;
  }

  function mapCharToStageId(charId) {
    if (charId === 'beatrice') return 'beatrice_11';
    if (charId === 'alice') return 'alice_9';
    if (charId === 'aino') return 'aino_sparring';
    if (charId === 'noelle') return 'noelle_14';
    return null;
  }

  function simulateBattle(stageId, policyFn, opts) {
    opts = opts || {};
    const maxTurns = opts.maxTurns || 26;
    const b = startStage(stageId, {
      headless: true,
      usePreset: opts.usePreset !== false,
      fromArena: true,
      relics: opts.relics,
      bondAssist: opts.bondAssist,
      forceCrit: opts.forceCrit,
    });
    if (opts.noPalace) {
      b.player.palaceMax = 0;
      b.player.palaceLeft = 0;
    }
    let safety = 0;
    while (!b.over && b.turn <= maxTurns && safety++ < 400) {
      const action = policyFn(b, CombatEngine);
      if (!action || action.type === 'endTurn') {
        endTurn(b);
      } else if (action.type === 'palace') {
        const pRes = inspectClue(action.clueId, action.deductionId, b);
        if (!pRes.ok) {
          endTurn(b);
        }
      } else if (action.type === 'overcast') {
        setOvercast(action.mode, b);
      } else if (action.type === 'wand' || action.type === 'eclipse') {
        const okWand = toggleEclipseWand(action.on, b);
        if (action.on && !okWand) {
          b._wandSkipTurn = b.turn;
        }
      } else if (action.type === 'assist') {
        const aRes = useBondAssist(b);
        if (!aRes.ok) {
          endTurn(b);
        }
      } else if (action.type === 'skill') {
        const res = useSkill(action.skillId, action.targetIdx, b);
        if (!res.ok) {
          endTurn(b);
        }
      } else {
        endTurn(b);
      }
    }
    if (!b.over) {
      finishBattle(b, false, 'timeout');
    }
    activeBattle = null;
    return {
      won: b.won,
      grade: b.grade,
      turns: b.turn,
      endReason: b.endReason,
      playerHits: b.playerHits,
      enemyHits: b.enemyHits,
      sealProgress: b.sealProgress,
      exposure: b.exposure,
      exposureWarned: b.exposureWarningTriggered,
      crateHp: b.crateHp,
      hpRemaining: b.player.hp,
      mpRemaining: b.player.mp,
      metrics: Object.assign({}, b.metrics),
      log: b.log.slice(),
    };
  }

  const CombatEngine = {
    STAGES: STAGE_CONFIGS,
    SKILLS: TACTICAL_SKILLS,
    PATH_META,
    STANCE_META,
    openArenaHub,
    closeArenaHub,
    startStage,
    startBattle: startCustomOrStageBattle,
    setOvercast,
    toggleEclipseWand,
    useBondAssist,
    isPalaceReady,
    inspectClue,
    useSkill,
    endTurn,
    exitBattle,
    simulateBattle,
    computeSkillApCost,
    computeSkillMpCost,
    computeManaCycleMultiplier,
    estimateSkillDamage,
    computeTacticalForecast,
    predictNextIntentTendency,
    getCurrentPalaceConfig,
    getState: () => activeBattle,
    loadArenaRecords,
  };

  global.CombatEngine = CombatEngine;
  global.openArenaHub = openArenaHub;
  global.startBattle = startCustomOrStageBattle;

  // 故事内虚拟决斗：严格保留原著「已习得 virtual_duel 且了解度 >= 90%」门控！
  global.openDuelMenu = function () {
    const curS = getGameS();
    if (!curS || !(curS.skills || []).includes('virtual_duel')) {
      if (typeof global.toast === 'function') global.toast('尚未掌握「虚拟决斗」（可点右上角 ⚔️ 进入独立战术演武沙盒）');
      return false;
    }
    const cMap = getCharMap() || {};
    const ready = Object.keys(curS.know || {}).filter(id => (curS.know[id] || 0) >= 90);
    if (!ready.length) {
      if (typeof global.toast === 'function') global.toast('尚无了解度≥90%的可挑战对象');
      return false;
    }
    const choices = ready.map(id => ({
      text: `梦中挑战 ${cMap[id]?.short || id}（了解度 ${curS.know[id]}%）`,
      do: () => global.runDuel(id),
    }));
    choices.push({ text: '暂不决斗', do: () => { if (typeof global.enterFreeRoam === 'function') global.enterFreeRoam(); } });
    if (typeof global.playLines === 'function') {
      global.playLines([{ text: '意识沉入梦境虚空，要挑战哪位对手？', choices }]);
    }
    return true;
  };

  global.runDuel = function (charId) {
    const mapped = mapCharToStageId(charId);
    if (mapped) {
      startStage(mapped, {
        fromArena: false,
        usePreset: false,
        fullRestore: true,
        done: () => {
          const curS = getGameS();
          if (curS && curS.freeRoam && typeof global.enterFreeRoam === 'function') {
            global.enterFreeRoam();
          }
        },
      });
      return;
    }
    const cMap = getCharMap();
    const ch = (cMap && cMap[charId]) || { name: charId };
    startCustomOrStageBattle({
      name: ch.name,
      emoji: '⚔️',
      elem: 'water',
      hp: 210,
      atk: 34,
      def: 10,
      mdef: 12,
      exp: 45,
      gold: 0,
      desc: '梦境重构的对手投影。',
    }, () => {
      const curS = getGameS();
      if (curS && curS.freeRoam && typeof global.enterFreeRoam === 'function') {
        global.enterFreeRoam();
      }
    });
  };

  if (typeof document !== 'undefined') {
    const bindButtons = () => {
      const btnTitle = document.getElementById('btn-arena-title');
      if (btnTitle) btnTitle.onclick = () => openArenaHub({ fromTitle: true });
      const btnHud = document.getElementById('btn-arena');
      if (btnHud) btnHud.onclick = () => openArenaHub({ fromTitle: false });
    };
    bindButtons();
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', bindButtons);
    }

    // 键盘系统：绝不吞掉焦点按钮原生的 Enter/Space，同时支持 1~9 / Q / W / R / E 战术热键与防穿透
    document.addEventListener('keydown', e => {
      const bs = document.getElementById('battle-screen');
      const ao = document.getElementById('arena-overlay');
      const battleVis = bs && !bs.classList.contains('hidden');
      const arenaVis = ao && !ao.classList.contains('hidden');
      if (!battleVis && !arenaVis) return;

      const tgt = e.target;
      const isInteractiveEl = tgt && tgt.closest && tgt.closest('button, a, input, select, textarea, [tabindex]');

      if (e.key === 'Escape') {
        const alm = document.getElementById('arena-loadout-modal');
        if (alm && !alm.classList.contains('hidden')) {
          alm.classList.add('hidden');
          e.stopPropagation();
          return;
        }
        const pm = document.getElementById('cb-palace-modal');
        if (pm && pm.parentNode) {
          if (activeBattle && activeBattle.palacePendingStep2) {
            delete activeBattle.palacePendingStep2;
            pushLog(activeBattle, `<span style="color:#ffb8c0">❄️【冰晶宫殿·中断】你在第 2 步主动散去了冰镜推演（本波审视机会已消耗）。</span>`);
            renderCombatUI();
          }
          pm.parentNode.innerHTML = '';
          if (bs) bs.classList.remove('palace-timestop');
          e.stopPropagation();
          return;
        }
        if (arenaVis) {
          closeArenaHub();
          e.stopPropagation();
          return;
        }
      }

      // 若焦点已在按钮等可交互控件上，放行原生 Enter/Space 点击，仅阻止冒泡到底层 game.js 的全局 keydown！
      if (e.key === ' ' || e.key === 'Enter') {
        if (isInteractiveEl) {
          e.stopPropagation();
          return;
        }
        const confirmDone = document.getElementById('cr-done');
        if (confirmDone) {
          confirmDone.click();
        }
        e.stopPropagation();
        e.preventDefault();
        return;
      }

      // 战斗进行中且无模态弹窗时的战术快捷键
      if (battleVis && activeBattle && !activeBattle.over && !document.getElementById('cb-palace-modal')) {
        if (e.key >= '1' && e.key <= '9') {
          const cards = bs.querySelectorAll('#b-actions .cb-skill-card');
          const pick = cards[Number(e.key) - 1];
          if (pick && !pick.disabled) {
            pick.click();
            e.stopPropagation();
          }
        } else if (e.key === 'q' || e.key === 'Q') {
          const pb = document.getElementById('cb-btn-palace');
          if (pb && !pb.disabled) { pb.click(); e.stopPropagation(); }
        } else if (e.key === 'w' || e.key === 'W') {
          if (activeBattle.player.hasManaCycle) {
            setOvercast((activeBattle.player.overcastMode + 1) % 3);
            e.stopPropagation();
          }
        } else if (e.key === 'r' || e.key === 'R') {
          const wb = document.getElementById('cb-btn-wand');
          if (wb && !wb.classList.contains('hidden') && !wb.disabled) { wb.click(); e.stopPropagation(); }
        } else if (e.key === 'f' || e.key === 'F') {
          const ab = document.getElementById('cb-btn-assist');
          if (ab && !ab.classList.contains('hidden') && !ab.disabled) { ab.click(); e.stopPropagation(); }
        } else if (e.key === 'e' || e.key === 'E') {
          endTurn();
          e.stopPropagation();
        }
      }
    }, true);
  }
})(typeof window !== 'undefined' ? window : globalThis);
