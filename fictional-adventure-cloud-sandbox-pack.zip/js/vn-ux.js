/* =========================================================================
   转生千金 · 商业级 Galgame 基础体验组件 (js/vn-ux.js)
   包含：
   1. 对话历史回看（Backlog，支持 L 键 / HUD / 对话框入口，至多 200 条）
   2. 6 槽位手动存档 / 读档系统 + 自动存档镜像（完整序列化因果、铭记与奇遇状态）
   3. 章节速览与快速重温 / 快捷试玩跳转（覆盖第一、二、三卷全部核心篇章）
   ========================================================================= */
(function (root) {
  'use strict';

  var MAX_BACKLOG = 200;
  var MANUAL_SLOTS_KEY = 'ojousama_manual_slots_v1';
  var AUTO_META_KEY = 'ojousama_auto_meta_v1';
  var UNLOCKED_CHAPTERS_KEY = 'ojousama_unlocked_chapters_v1';

  var backlogList = [];
  var backlogSeq = 0;

  function escapeHtml(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function getS() {
    if (typeof S !== 'undefined' && S) return S;
    return root && root.S ? root.S : null;
  }

  function getLocName(st) {
    if (!st || !st.loc) return '未知地点';
    var locs = typeof LOCS !== 'undefined' ? LOCS : (root.__LOCS || {});
    return (locs[st.loc] && locs[st.loc].name) || st.loc;
  }

  function getDateLabel(st) {
    if (typeof dateStr === 'function') {
      try { return dateStr(); } catch (e) {}
    }
    if (!st) return '';
    var sns = ['春', '夏', '秋', '冬'];
    return (st.year || 0) + '年 · ' + (sns[st.season || 0] || '春');
  }

  function getPhaseLabel(st) {
    if (typeof phaseName === 'function') {
      try { return phaseName(); } catch (e) {}
    }
    var map = { prologue: '序章', childhood: '童年', youth: '少女期', academy: '学院篇', journey: '旅途篇', finale: '终章' };
    return (st && map[st.phase]) || '';
  }

  function getAgeLabel(st) {
    if (typeof ageStr === 'function') {
      try { return ageStr(); } catch (e) {}
    }
    if (!st) return '0岁';
    return st.ageY <= 0 ? (st.ageD || 0) + '天' : st.ageY + '岁';
  }

  function getChapterTitleForState(st, scId) {
    var chaps = typeof STORY_CHAPTERS !== 'undefined' ? STORY_CHAPTERS : (root.__STORY_CHAPTERS || []);
    var cid = scId || (typeof currentScene !== 'undefined' ? currentScene : null);
    if (cid) {
      var found = chaps.find(function (c) { return c && c.id === cid; });
      if (found) return (found.vol ? found.vol + ' · ' : '') + found.title;
      var scenes = typeof SCENES !== 'undefined' ? SCENES : (root.SCENES || {});
      if (scenes[cid] && scenes[cid].card) {
        return (scenes[cid].card.vol || '') + ' · ' + (scenes[cid].card.s || scenes[cid].card.t || cid);
      }
      return cid;
    }
    return '自由探索 · ' + getLocName(st);
  }

  function formatTimestamp(ts) {
    var d = new Date(ts || Date.now());
    var pad = function (n) { return n < 10 ? '0' + n : String(n); };
    return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()) + ' ' + pad(d.getHours()) + ':' + pad(d.getMinutes());
  }

  function deepClone(obj) {
    try { return JSON.parse(JSON.stringify(obj)); } catch (e) { return null; }
  }

  /* =========================================================================
     一、对话历史回看（Backlog）
     ========================================================================= */
  function recordLine(entry, optText) {
    if (optText !== undefined || typeof entry === 'string' || entry == null) {
      entry = { speaker: entry || '', text: optText == null ? '' : String(optText) };
    }
    if (!entry) return false;
    var rawText = String(entry.text || '').trim();
    if (!rawText || rawText === '◇') return false;
    var st = getS();
    var spk = entry.speaker ? String(entry.speaker).trim() : '';
    var kind = entry.kind || 'line';
    var last = backlogList.length ? backlogList[backlogList.length - 1] : null;
    if (last && last.text === rawText && last.speaker === spk && last.kind === kind) {
      return false;
    }
    backlogSeq += 1;
    backlogList.push({
      seq: backlogSeq,
      kind: kind,
      speaker: spk,
      charId: entry.charId || null,
      text: rawText,
      locName: getLocName(st),
      dateStr: getDateLabel(st)
    });
    if (backlogList.length > MAX_BACKLOG) {
      backlogList.splice(0, backlogList.length - MAX_BACKLOG);
    }
    return true;
  }

  function recordChoice(choiceText) {
    var clean = String(choiceText || '').replace(/<[^>]+>/g, '').trim();
    if (!clean) return false;
    return recordLine({
      kind: 'choice',
      speaker: '抉择',
      text: '▸ ' + clean
    });
  }

  function clearBacklog() {
    backlogList = [];
    backlogSeq = 0;
  }

  function getBacklog() {
    return backlogList.slice();
  }

  function setBacklog(arr) {
    if (!Array.isArray(arr)) {
      clearBacklog();
      return;
    }
    backlogList = arr.slice(-MAX_BACKLOG).map(function (it, idx) {
      return {
        seq: it.seq || idx + 1,
        kind: it.kind || 'line',
        speaker: it.speaker || '',
        charId: it.charId || null,
        text: String(it.text || ''),
        locName: it.locName || '',
        dateStr: it.dateStr || ''
      };
    });
    backlogSeq = backlogList.length ? backlogList[backlogList.length - 1].seq : 0;
  }

  function closeBacklogModal() {
    if (typeof document === 'undefined') return;
    var ov = document.getElementById('vn-backlog-modal');
    if (ov) ov.classList.add('hidden');
  }

  function openBacklogModal() {
    if (typeof document === 'undefined') return null;
    var ov = document.getElementById('vn-backlog-modal');
    if (!ov) {
      ov = document.createElement('section');
      ov.id = 'vn-backlog-modal';
      ov.className = 'overlay hidden';
      document.body.appendChild(ov);
    }
    var rowsHtml = backlogList.length
      ? backlogList.map(function (item) {
          var portraitSrc = '';
          if (item.charId && typeof resolvePortrait === 'function') {
            try { portraitSrc = resolvePortrait(item.charId, 'normal') || ''; } catch (e) {}
          }
          var avatarHtml = portraitSrc
            ? '<img class="vb-av" src="' + escapeHtml(portraitSrc) + '" alt=""/>'
            : '<span class="vb-av-ph">' + (item.kind === 'choice' ? '✦' : item.kind === 'cg' ? '🎞️' : item.speaker ? '💬' : '❄️') + '</span>';
          return (
            '<div class="vb-row kind-' + escapeHtml(item.kind) + '">' +
              '<div class="vb-left">' + avatarHtml + '</div>' +
              '<div class="vb-main">' +
                '<div class="vb-meta">' +
                  '<span class="vb-spk">' + escapeHtml(item.speaker || '旁白') + '</span>' +
                  '<span class="vb-ctx">' + escapeHtml([item.dateStr, item.locName].filter(Boolean).join(' · ')) + '</span>' +
                '</div>' +
                '<div class="vb-text">' + escapeHtml(item.text).replace(/\n/g, '<br>') + '</div>' +
              '</div>' +
            '</div>'
          );
        }).join('')
      : '<p class="vb-empty">尚未记录对白。开启剧情或与角色交谈后，过往台词与抉择都会留在这里供随时翻阅。</p>';

    ov.innerHTML =
      '<div class="end-card vn-modal-card">' +
        '<div class="vn-modal-head">' +
          '<div>' +
            '<h2>📜 对话回看 · Backlog</h2>' +
            '<p class="vn-modal-sub">共保留最近 ' + backlogList.length + ' / ' + MAX_BACKLOG + ' 条对白、心声与选项抉择（快捷键 L）</p>' +
          '</div>' +
          '<button type="button" class="tbtn ghost" id="vb-close" style="min-width:86px;padding:6px 14px">关闭</button>' +
        '</div>' +
        '<div class="vn-modal-scroll" id="vb-scroll">' + rowsHtml + '</div>' +
      '</div>';

    ov.classList.remove('hidden');
    var sc = ov.querySelector('#vb-scroll');
    if (sc) sc.scrollTop = sc.scrollHeight;
    ov.querySelector('#vb-close').onclick = closeBacklogModal;
    return ov;
  }

  function toggleBacklogModal() {
    if (typeof document === 'undefined') return;
    var ov = document.getElementById('vn-backlog-modal');
    if (ov && !ov.classList.contains('hidden')) closeBacklogModal();
    else openBacklogModal();
  }

  /* =========================================================================
     二、6 槽位手动存档 / 读档系统（含 1 个自动存档槽）
     ========================================================================= */
  function readManualSlots() {
    try {
      var raw = JSON.parse(localStorage.getItem(MANUAL_SLOTS_KEY) || '{}');
      return raw && typeof raw === 'object' ? raw : {};
    } catch (e) {
      return {};
    }
  }

  function writeManualSlots(slotsObj) {
    try { localStorage.setItem(MANUAL_SLOTS_KEY, JSON.stringify(slotsObj || {})); } catch (e) {}
  }

  function buildMeta(st, scId, ts) {
    return {
      name: (!st.flags || !st.flags.named) ? '？？？' : (st.alias || st.name || '希尔维亚'),
      ageStr: getAgeLabel(st),
      phaseName: getPhaseLabel(st),
      locName: getLocName(st),
      chapterTitle: getChapterTitleForState(st, scId),
      lv: st.lv || 1,
      gold: st.gold || 0,
      savedAt: formatTimestamp(ts)
    };
  }

  function onAutoSave(st) {
    if (!st) return;
    var meta = buildMeta(st, typeof currentScene !== 'undefined' ? currentScene : null, Date.now());
    try { localStorage.setItem(AUTO_META_KEY, JSON.stringify(meta)); } catch (e) {}
  }

  function saveToSlot(slotId) {
    var sid = Number(slotId);
    if (!(sid >= 1 && sid <= 6)) return { ok: false, reason: 'bad_slot' };
    var st = getS();
    if (!st) return { ok: false, reason: 'no_state' };
    if (root.RelicsAndEvents && root.RelicsAndEvents.ensureRelicsState) {
      root.RelicsAndEvents.ensureRelicsState(st);
    }
    if (root.BranchingDirector && root.BranchingDirector.ensureCausalState) {
      root.BranchingDirector.ensureCausalState(st);
    }
    var ts = Date.now();
    var curSc = typeof currentScene !== 'undefined' ? currentScene : null;
    var curChain = typeof storyChain !== 'undefined' && storyChain ? deepClone(storyChain) : null;
    var payload = {
      version: 2,
      slotId: sid,
      ts: ts,
      meta: buildMeta(st, curSc, ts),
      state: deepClone(st),
      currentScene: curSc,
      storyChain: curChain,
      backlog: deepClone(backlogList)
    };
    var all = readManualSlots();
    all[String(sid)] = payload;
    writeManualSlots(all);
    if (typeof toast === 'function') toast('💾 已覆盖保存至存档槽 ' + sid);
    return { ok: true, slot: payload };
  }

  function applyRestoredPayload(rawState, curSc, curChain, restoredBacklog) {
    if (!rawState || typeof rawState !== 'object') return false;
    var restored = typeof migrateStorySave === 'function' ? migrateStorySave(deepClone(rawState)) : deepClone(rawState);
    if (typeof baseState === 'function') {
      restored = Object.assign(baseState(), restored);
    }
    if (root.BranchingDirector && root.BranchingDirector.ensureCausalState) {
      root.BranchingDirector.ensureCausalState(restored);
    }
    if (root.RelicsAndEvents && root.RelicsAndEvents.ensureRelicsState) {
      root.RelicsAndEvents.ensureRelicsState(restored);
    }
    if (typeof root.__vnApplyLoadedState === 'function') {
      root.__vnApplyLoadedState(restored, curSc, curChain);
    } else {
      root.S = restored;
    }
    if (Array.isArray(restoredBacklog)) {
      setBacklog(restoredBacklog);
    }
    if (typeof document !== 'undefined') {
      if (typeof show === 'function') {
        show('title-screen', 0);
        show('game-screen', 1);
        show('panel', 0);
        show('map-overlay', 0);
        show('stats-overlay', 0);
      }
      closeSaveLoadModal();
      closeBacklogModal();
      closeChaptersModal();
    }
    // 清理残余弹窗/战斗/AI抽屉
    if (root.AIChatPanel && typeof root.AIChatPanel.closeDrawer === 'function') {
      root.AIChatPanel.closeDrawer({ wipePending: true });
    }
    if (root.CombatEngine && typeof root.CombatEngine.exitBattle === 'function') {
      root.CombatEngine.exitBattle(false, { silent: true });
    }
    if (typeof updateHUD === 'function') updateHUD();
    if (typeof updateLocBar === 'function') updateLocBar();

    if (curSc && typeof SCENES !== 'undefined' && SCENES[curSc]) {
      if (curChain && Array.isArray(curChain.queue) && curChain.queue.length && typeof runSceneQueue === 'function') {
        var resumeIdx = Math.max(0, (curChain.idx || 1) - 1);
        runSceneQueue(curChain.queue, resumeIdx);
      } else if (typeof runScene === 'function') {
        runScene(curSc);
      }
    } else if (typeof resumePendingStories === 'function' && resumePendingStories()) {
      // resumed pending
    } else if (typeof checkStoryGates === 'function' && checkStoryGates()) {
      // triggered due gates
    } else if (typeof enterFreeRoam === 'function') {
      enterFreeRoam();
    }
    return true;
  }

  function loadFromSlot(slotId) {
    var sid = Number(slotId);
    if (sid === 0) {
      // 自动存档槽
      try {
        var autoRaw = localStorage.getItem(typeof SAVE_KEY !== 'undefined' ? SAVE_KEY : 'ojousama_save_v1');
        if (!autoRaw) return { ok: false, reason: 'empty' };
        var parsedAuto = JSON.parse(autoRaw);
        applyRestoredPayload(parsedAuto, null, null, null);
        if (typeof toast === 'function') toast('⏩ 已读取自动存档');
        return { ok: true };
      } catch (e) {
        return { ok: false, reason: 'corrupt' };
      }
    }
    if (!(sid >= 1 && sid <= 6)) return { ok: false, reason: 'bad_slot' };
    var all = readManualSlots();
    var slot = all[String(sid)];
    if (!slot || !slot.state) return { ok: false, reason: 'empty' };
    applyRestoredPayload(slot.state, slot.currentScene, slot.storyChain, slot.backlog);
    if (typeof toast === 'function') toast('📂 已读取存档槽 ' + sid);
    return { ok: true, slot: slot };
  }

  function deleteSlot(slotId) {
    var sid = Number(slotId);
    if (!(sid >= 1 && sid <= 6)) return false;
    var all = readManualSlots();
    if (!all[String(sid)]) return false;
    delete all[String(sid)];
    writeManualSlots(all);
    if (typeof toast === 'function') toast('🗑️ 已删除存档槽 ' + sid);
    return true;
  }

  function getSlotList() {
    var all = readManualSlots();
    var list = [];
    // 自动存档槽 0
    var autoExists = false;
    var autoMeta = null;
    try {
      var autoKey = typeof SAVE_KEY !== 'undefined' ? SAVE_KEY : 'ojousama_save_v1';
      var rawAuto = localStorage.getItem(autoKey);
      if (rawAuto) {
        autoExists = true;
        var mRaw = localStorage.getItem(AUTO_META_KEY);
        if (mRaw) autoMeta = JSON.parse(mRaw);
        if (!autoMeta) {
          var parsed = JSON.parse(rawAuto);
          autoMeta = buildMeta(parsed, null, Date.now());
        }
      }
    } catch (e) {}
    list.push({ slotId: 0, isAuto: true, empty: !autoExists, meta: autoMeta });

    for (var i = 1; i <= 6; i++) {
      var s = all[String(i)];
      list.push({
        slotId: i,
        isAuto: false,
        empty: !(s && s.state),
        meta: s && s.meta ? s.meta : null,
        ts: s ? s.ts : 0
      });
    }
    return list;
  }

  function closeSaveLoadModal() {
    if (typeof document === 'undefined') return;
    var ov = document.getElementById('vn-saveload-modal');
    if (ov) ov.classList.add('hidden');
  }

  function openSaveLoadModal(mode) {
    if (typeof document === 'undefined') return null;
    var ov = document.getElementById('vn-saveload-modal');
    if (!ov) {
      ov = document.createElement('section');
      ov.id = 'vn-saveload-modal';
      ov.className = 'overlay hidden';
      document.body.appendChild(ov);
    }
    var gs = document.getElementById('game-screen');
    var inGame = !!(gs && !gs.classList.contains('hidden'));
    var slots = getSlotList();

    var cardsHtml = slots.map(function (sl) {
      var title = sl.isAuto ? '⚡ 自动存档位' : ('📁 手动槽位 0' + sl.slotId);
      var body = sl.empty
        ? '<div class="sl-empty">── 空置槽位 ──</div>'
        : '<div class="sl-meta">' +
            '<div class="sl-line1"><b>' + escapeHtml(sl.meta.name) + '</b> · ' + escapeHtml(sl.meta.ageStr) + ' · Lv.' + (sl.meta.lv || 1) + '</div>' +
            '<div class="sl-line2">' + escapeHtml(sl.meta.phaseName) + ' · ' + escapeHtml(sl.meta.locName) + '</div>' +
            '<div class="sl-chap">' + escapeHtml(sl.meta.chapterTitle) + '</div>' +
            '<div class="sl-time">' + escapeHtml(sl.meta.savedAt) + '</div>' +
          '</div>';

      var btns = [];
      if (!sl.isAuto && inGame) {
        btns.push('<button type="button" class="sl-btn save" data-sl-save="' + sl.slotId + '">' + (sl.empty ? '保存至此' : '覆盖保存') + '</button>');
      }
      if (!sl.empty) {
        btns.push('<button type="button" class="sl-btn load" data-sl-load="' + sl.slotId + '">读取</button>');
      }
      if (!sl.isAuto && !sl.empty) {
        btns.push('<button type="button" class="sl-btn del" data-sl-del="' + sl.slotId + '">删除</button>');
      }

      return (
        '<article class="sl-card' + (sl.isAuto ? ' auto' : '') + (sl.empty ? ' empty' : '') + '" data-slot="' + sl.slotId + '">' +
          '<div class="sl-head"><span>' + title + '</span></div>' +
          body +
          '<div class="sl-actions">' + btns.join('') + '</div>' +
        '</article>'
      );
    }).join('');

    ov.innerHTML =
      '<div class="end-card vn-modal-card">' +
        '<div class="vn-modal-head">' +
          '<div>' +
            '<h2>💾 存档与读档中心（6 槽位 + 自动存档）</h2>' +
            '<p class="vn-modal-sub">' + (inGame ? '完整保留属性、命运暗流、随身铭记配装与对话回看记录' : '可从标题页直接读取任意手动槽位或自动存档继续游玩') + '</p>' +
          '</div>' +
          '<button type="button" class="tbtn ghost" id="sl-close" style="min-width:86px;padding:6px 14px">关闭</button>' +
        '</div>' +
        '<div class="vn-modal-scroll"><div class="sl-grid">' + cardsHtml + '</div></div>' +
      '</div>';

    ov.classList.remove('hidden');
    ov.querySelector('#sl-close').onclick = closeSaveLoadModal;
    ov.querySelectorAll('[data-sl-save]').forEach(function (b) {
      b.onclick = function () {
        saveToSlot(Number(b.getAttribute('data-sl-save')));
        openSaveLoadModal(mode);
      };
    });
    ov.querySelectorAll('[data-sl-load]').forEach(function (b) {
      b.onclick = function () {
        loadFromSlot(Number(b.getAttribute('data-sl-load')));
      };
    });
    ov.querySelectorAll('[data-sl-del]').forEach(function (b) {
      b.onclick = function () {
        deleteSlot(Number(b.getAttribute('data-sl-del')));
        openSaveLoadModal(mode);
      };
    });
    return ov;
  }

  /* =========================================================================
     三、章节速览与快速重温 / 快捷试玩跳转
     ========================================================================= */
  var FEATURED_QUICK_JUMPS = [
    { id: 's_start', label: '第一卷 · 银与蓝（开篇）', desc: '转生公爵家，开启银发蓝眸的新生。' },
    { id: 's_micro', label: '第一卷 · 微服出行（8岁）', desc: '三姐妹溜进集市的轻喜剧日常。' },
    { id: 's_opening_ceremony', label: '第二卷 · 魔法大学入学（12岁）', desc: '踏入阿斯拉魔法大学，初遇同窗。' },
    { id: 's_aino_sparring', label: '第二卷 · 艾诺冰上实战（12岁冬）', desc: '领悟不经手隔空凝冰与三击切磋。' },
    { id: 's_turnpoint', label: '第二卷 · 转折点一（15岁冬）', desc: '黑夜突袭、东逃抉择与命运暗流汇合。' },
    { id: 's_north_forest', label: '第三卷 · 北林与霁馆（15岁春）', desc: '化名眷寒渔，在澄岚镇练就生根步与送刀。' },
    { id: 's_distant_wind_1', label: '第三卷 · 远行的风（上）', desc: '辞别霁馆父女，带乌木铁剑与木牌北行。' },
    { id: 's_distant_wind_2', label: '第三卷 · 冰封峡谷前线（下）', desc: '护药入赫兰，雪地重逢艾诺并迎战冰蜥。' }
  ];

  function loadUnlockedChapters() {
    var base = { s_start: true };
    try {
      var raw = JSON.parse(localStorage.getItem(UNLOCKED_CHAPTERS_KEY) || '{}');
      if (raw && typeof raw === 'object') return Object.assign(base, raw);
    } catch (e) {}
    return base;
  }

  function markChapterUnlocked(sceneId) {
    if (!sceneId) return;
    var map = loadUnlockedChapters();
    if (!map[sceneId]) {
      map[sceneId] = true;
      try { localStorage.setItem(UNLOCKED_CHAPTERS_KEY, JSON.stringify(map)); } catch (e) {}
    }
  }

  function prepareChapterState(sceneId) {
    var st = typeof baseState === 'function' ? baseState() : (getS() || {});
    var locs = typeof LOCS !== 'undefined' ? LOCS : (root.__LOCS || {});
    Object.values(locs).forEach(function (L) { L.unlock = false; });

    var chaps = typeof STORY_CHAPTERS !== 'undefined' ? STORY_CHAPTERS : (root.__STORY_CHAPTERS || []);
    var idx = chaps.findIndex(function (c) { return c && c.id === sceneId; });
    st.storyGateVersion = 3;
    var gateMap = typeof STORY_GATE_BY_SCENE !== 'undefined' ? STORY_GATE_BY_SCENE : (root.STORY_GATE_BY_SCENE || {});
    if (idx > 0) {
      for (var gi = 0; gi < idx; gi++) {
        var cidPrev = chaps[gi] && chaps[gi].id;
        var gKeys = (cidPrev && gateMap[cidPrev]) || [];
        gKeys.forEach(function (k) { st.flags[k] = 1; });
      }
    }

    var isVol3 = /^s_(black_name|jikan_arrive|north_forest|glow_sheep|distant_wind_1|words_to_wind|eye_of_storm|leaky_cup|distant_wind_2)$/.test(sceneId);
    var isVol2 = !isVol3 && (sceneId === 's_academy_start' || (idx >= chaps.findIndex(function (c) { return c && c.id === 's_opening_ceremony'; }) && idx >= 0));

    if (sceneId === 's_start') {
      st.ageY = 0; st.year = 0; st.month = 3; st.day = 1; st.phase = 'prologue'; st.loc = 'nursery';
      if (locs.nursery) locs.nursery.unlock = true;
    } else if (isVol3) {
      st.flags.named = 1;
      st.flags.ch_first_word = 1; st.flags.ch_alice_born = 1; st.flags.ch_beatrice_leaves = 1;
      st.flags.ch_academy = 1; st.flags.did_turnpoint = 1; st.flags.arrived_jikan = 1; st.flags.ch_black_name = 1;
      st.alias = sceneId === 's_black_name' ? null : '眷寒渔';
      st.phase = 'journey';
      st.ageY = (sceneId === 's_black_name' || sceneId === 's_jikan_arrive') ? 14 : (sceneId === 's_distant_wind_2' ? 16 : 15);
      st.year = st.ageY === 14 ? 15 : 16;
      st.month = sceneId === 's_distant_wind_2' ? 12 : (sceneId === 's_distant_wind_1' ? 6 : 3);
      st.season = Math.floor(((st.month - 3 + 12) % 12) / 3);
      st.tier = 3;
      st.lv = 36; st.mhp = 240; st.hp = 240; st.mmp = 385; st.mp = 385;
      st.atk = 42; st.mag = 128; st.pdef = 38; st.mdef = 44; st.gold = 35;
      st.skills = ['virtual_duel', 'ice_palace', 'mana_cycle', 'water_ball', 'ice_crystal', 'root_step', 'soft_cut'];
      st.loc = sceneId === 's_distant_wind_2' ? 'road' : 'jikan';
      ['road', 'jikan', 'chenglan_guild', 'northforest'].forEach(function (k) { if (locs[k]) locs[k].unlock = true; });
      if (sceneId === 's_distant_wind_2') {
        st.flags.ch_distant_wind_1 = 1;
        if (locs.ice_canyon) locs.ice_canyon.unlock = true;
      }
    } else if (isVol2) {
      st.flags.named = 1;
      st.flags.ch_first_word = 1; st.flags.ch_alice_born = 1; st.flags.ch_beatrice_leaves = 1;
      st.flags.ch_academy = 1;
      st.phase = 'academy';
      var lateAcad = ['s_star_festival', 's_turnpoint', 's_tree', 's_beach'].indexOf(sceneId) !== -1;
      st.ageY = lateAcad ? 15 : (['s_ice_melt_1', 's_seven_mountains', 's_ice_melt_2'].indexOf(sceneId) !== -1 ? 13 : 12);
      st.year = st.ageY;
      st.month = sceneId === 's_turnpoint' ? 12 : (sceneId === 's_aino_sparring' ? 12 : 9);
      st.season = Math.floor(((st.month - 3 + 12) % 12) / 3);
      st.tier = st.ageY >= 14 ? 2 : 1;
      st.lv = st.ageY >= 15 ? 34 : 28;
      st.mhp = 190; st.hp = 190; st.mmp = 320; st.mp = 320;
      st.atk = 22; st.mag = 95; st.pdef = 24; st.mdef = 28; st.gold = 40;
      st.skills = ['virtual_duel', 'ice_palace', 'water_ball', 'ice_crystal'];
      if (st.ageY >= 14) st.skills.push('mana_cycle');
      if (sceneId !== 's_opening_ceremony' && sceneId !== 's_academy_start') {
        st.flags.met_noelle = 1; st.flags.met_aino = 1; st.flags.met_charlotte = 1;
      }
      st.loc = 'dorm';
      Object.values(locs).forEach(function (L) {
        if (L.area === '魔法大学' || L.area === '公爵府') L.unlock = true;
      });
    } else {
      // 第一卷（非 s_start）
      st.flags.named = 1;
      var ageGuess = sceneId === 's_micro' ? 8 : (sceneId === 's_beatrice_day' || sceneId === 's_alice_affinity' ? 7 : (sceneId === 's_reno_arrive' ? 6 : 4));
      st.ageY = ageGuess; st.year = ageGuess; st.month = 6; st.season = 1;
      st.phase = ageGuess >= 6 ? 'youth' : 'childhood';
      st.flags.ch_first_word = 1;
      if (ageGuess >= 3) st.flags.ch_alice_born = 1;
      st.tier = ageGuess >= 8 ? 1 : 0;
      st.lv = ageGuess >= 8 ? 15 : 8;
      st.mhp = ageGuess >= 8 ? 105 : 55; st.hp = st.mhp;
      st.mmp = ageGuess >= 8 ? 155 : 80; st.mp = st.mmp;
      st.atk = ageGuess >= 8 ? 12 : 5; st.mag = ageGuess >= 8 ? 48 : 24;
      st.skills = ageGuess >= 8 ? ['virtual_duel', 'ice_palace', 'water_ball', 'ice_crystal'] : ['virtual_duel', 'ice_crystal'];
      st.loc = ageGuess >= 8 ? 'ownroom' : 'nursery';
      Object.values(locs).forEach(function (L) {
        if (L.area === '公爵府' || L.area === '领地') L.unlock = true;
      });
    }

    if (typeof syncStatsToAge === 'function') {
      root.S = st;
      try { syncStatsToAge(); } catch (e) {}
    }
    return st;
  }

  function jumpToChapter(sceneId) {
    var scenes = typeof SCENES !== 'undefined' ? SCENES : (root.SCENES || {});
    if (!scenes[sceneId]) return false;
    markChapterUnlocked(sceneId);

    var curS = getS();
    var preservedRelics = curS && curS.relicsUnlocked ? deepClone(curS.relicsUnlocked) : {};
    var preservedEq = curS && Array.isArray(curS.equippedRelics) ? curS.equippedRelics.slice() : [];
    var prepared = prepareChapterState(sceneId);
    prepared.relicsUnlocked = preservedRelics || {};
    prepared.equippedRelics = preservedEq;

    if (root.BranchingDirector && root.BranchingDirector.ensureCausalState) {
      root.BranchingDirector.ensureCausalState(prepared);
    }
    if (root.RelicsAndEvents && root.RelicsAndEvents.ensureRelicsState) {
      root.RelicsAndEvents.ensureRelicsState(prepared);
    }

    clearBacklog();
    if (typeof root.__vnApplyLoadedState === 'function') {
      root.__vnApplyLoadedState(prepared, null, null);
    } else {
      root.S = prepared;
    }

    if (typeof document !== 'undefined') {
      if (typeof show === 'function') {
        show('title-screen', 0);
        show('game-screen', 1);
        show('panel', 0);
        show('map-overlay', 0);
        show('stats-overlay', 0);
      }
      closeChaptersModal();
      closeSaveLoadModal();
      closeBacklogModal();
    }
    if (root.AIChatPanel && typeof root.AIChatPanel.closeDrawer === 'function') {
      root.AIChatPanel.closeDrawer({ wipePending: true });
    }
    if (root.CombatEngine && typeof root.CombatEngine.exitBattle === 'function') {
      root.CombatEngine.exitBattle(false, { silent: true });
    }
    if (typeof runScene === 'function') runScene(sceneId);
    return true;
  }

  function closeChaptersModal() {
    if (typeof document === 'undefined') return;
    var ov = document.getElementById('vn-chapters-modal');
    if (ov) ov.classList.add('hidden');
  }

  function openChaptersModal() {
    if (typeof document === 'undefined') return null;
    var ov = document.getElementById('vn-chapters-modal');
    if (!ov) {
      ov = document.createElement('section');
      ov.id = 'vn-chapters-modal';
      ov.className = 'overlay hidden';
      document.body.appendChild(ov);
    }
    var unlocked = loadUnlockedChapters();
    var chaps = (typeof STORY_CHAPTERS !== 'undefined' ? STORY_CHAPTERS : (root.__STORY_CHAPTERS || []))
      .filter(function (c) { return c && c.id && c.id !== 's_ending_menu'; });

    var quickHtml = FEATURED_QUICK_JUMPS.map(function (q) {
      return (
        '<button type="button" class="chap-quick-card" data-jump-chap="' + q.id + '">' +
          '<div class="cqc-title">✦ ' + escapeHtml(q.label) + '</div>' +
          '<div class="cqc-desc">' + escapeHtml(q.desc) + '</div>' +
        '</button>'
      );
    }).join('');

    var listHtml = chaps.map(function (c) {
      var isOpen = !!unlocked[c.id];
      return (
        '<button type="button" class="chap-row' + (isOpen ? ' unlocked' : ' locked') + '" ' +
          (isOpen ? 'data-jump-chap="' + c.id + '"' : 'disabled') + '>' +
          '<span class="cr-vol">' + escapeHtml(c.vol || '篇章') + '</span>' +
          '<span class="cr-tit">' + escapeHtml(c.title) + '</span>' +
          '<span class="cr-tag">' + (isOpen ? '▶ 重温' : '🔒 未阅读') + '</span>' +
        '</button>'
      );
    }).join('');

    ov.innerHTML =
      '<div class="end-card vn-modal-card">' +
        '<div class="vn-modal-head">' +
          '<div>' +
            '<h2>🔖 章节速览与快速重温</h2>' +
            '<p class="vn-modal-sub">随时重温已解锁章节，或通过快捷试玩直达各卷核心舞台</p>' +
          '</div>' +
          '<button type="button" class="tbtn ghost" id="vc-close" style="min-width:86px;padding:6px 14px">关闭</button>' +
        '</div>' +
        '<div class="vn-modal-scroll">' +
          '<h4 class="rel-sec-title" style="margin-top:0">✦ 快捷试玩直达入口</h4>' +
          '<div class="chap-quick-grid">' + quickHtml + '</div>' +
          '<h4 class="rel-sec-title">📖 全卷章节记录</h4>' +
          '<div class="chap-list">' + listHtml + '</div>' +
        '</div>' +
      '</div>';

    ov.classList.remove('hidden');
    ov.querySelector('#vc-close').onclick = closeChaptersModal;
    ov.querySelectorAll('[data-jump-chap]').forEach(function (btn) {
      btn.onclick = function () {
        jumpToChapter(btn.getAttribute('data-jump-chap'));
      };
    });
    return ov;
  }

  /* =========================================================================
     四、UI 按钮挂载与键盘绑定
     ========================================================================= */
  function ensureVNUIButtons() {
    if (typeof document === 'undefined') return;

    var SVG_SAVE = '<svg viewBox="0 0 18 18" width="15" height="15" fill="none" stroke="currentColor" stroke-width="1.45" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 3h8.5L15 5.5V15H4V3z"/><path d="M6.2 3v4h5.2V3"/><rect x="6.2" y="10.2" width="5.6" height="4.8"/></svg>';
    var SVG_CHAP = '<svg viewBox="0 0 18 18" width="15" height="15" fill="none" stroke="currentColor" stroke-width="1.45" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 3.2h8v12l-4-2.8-4 2.8v-12z"/></svg>';
    var SVG_LOG = '<svg viewBox="0 0 18 18" width="15" height="15" fill="none" stroke="currentColor" stroke-width="1.45" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3.5" y="3" width="11" height="12" rx="1.6"/><line x1="6.2" y1="6.8" x2="11.8" y2="6.8"/><line x1="6.2" y1="9.6" x2="11.8" y2="9.6"/><line x1="6.2" y1="12.4" x2="9.6" y2="12.4"/></svg>';

    var hudRight = document.querySelector('#hud .hud-right');
    if (hudRight) {
      if (!document.getElementById('btn-backlog')) {
        var bLog = document.createElement('button');
        bLog.id = 'btn-backlog';
        bLog.className = 'chip chip-vn';
        bLog.title = '对话回看 (L)';
        bLog.innerHTML = SVG_LOG;
        bLog.onclick = function () { toggleBacklogModal(); };
        hudRight.insertBefore(bLog, document.getElementById('btn-ui') || hudRight.firstChild);
      } else {
        // 统一接管主界面已有 #btn-backlog，使其直接打开 200 条增强回看弹窗且避免重复按钮
        var existingLog = document.getElementById('btn-backlog');
        existingLog.onclick = function (e) {
          if (e && e.stopPropagation) e.stopPropagation();
          toggleBacklogModal();
        };
      }
      if (!document.getElementById('btn-saveload')) {
        var bSl = document.createElement('button');
        bSl.id = 'btn-saveload';
        bSl.className = 'chip chip-vn';
        bSl.title = '存档 / 读档（6槽位）';
        bSl.innerHTML = SVG_SAVE;
        bSl.onclick = function () { openSaveLoadModal('save'); };
        hudRight.insertBefore(bSl, document.getElementById('btn-ui') || hudRight.firstChild);
      }
      if (!document.getElementById('btn-chapters')) {
        var bCh = document.createElement('button');
        bCh.id = 'btn-chapters';
        bCh.className = 'chip chip-vn';
        bCh.title = '章节速览与快速试玩';
        bCh.innerHTML = SVG_CHAP;
        bCh.onclick = function () { openChaptersModal(); };
        hudRight.insertBefore(bCh, document.getElementById('btn-ui') || hudRight.firstChild);
      }
    }

    // 仅在 #text-box 尚无任何回看按钮时补充入口，防止与 #btn-backlog 双重堆叠
    var tb = document.getElementById('text-box');
    if (tb && !document.getElementById('tb-backlog-btn') && !tb.querySelector('#btn-backlog')) {
      var tbBtn = document.createElement('button');
      tbBtn.type = 'button';
      tbBtn.id = 'tb-backlog-btn';
      tbBtn.className = 'tb-backlog-btn';
      tbBtn.title = '对话历史回看 (L)';
      tbBtn.innerHTML = SVG_LOG + ' <span>回看 L</span>';
      tbBtn.onclick = function (e) {
        if (e && e.stopPropagation) e.stopPropagation();
        openBacklogModal();
      };
      tb.appendChild(tbBtn);
    }

    var titleMenu = document.querySelector('#title-screen .title-menu');
    if (titleMenu) {
      var anchor = document.getElementById('btn-arena-title') || document.getElementById('btn-codex');
      if (!document.getElementById('btn-title-loads')) {
        var tLoad = document.createElement('button');
        tLoad.id = 'btn-title-loads';
        tLoad.className = 'tbtn';
        tLoad.innerHTML = '<span class="tbtn-ico" aria-hidden="true">' + SVG_SAVE + '</span><span class="tbtn-txt">存档档案</span><span class="tbtn-en">ARCHIVE</span>';
        tLoad.onclick = function () { openSaveLoadModal('load'); };
        titleMenu.insertBefore(tLoad, anchor);
      }
      if (!document.getElementById('btn-title-chapters')) {
        var tChap = document.createElement('button');
        tChap.id = 'btn-title-chapters';
        tChap.className = 'tbtn';
        tChap.innerHTML = '<span class="tbtn-ico" aria-hidden="true">' + SVG_CHAP + '</span><span class="tbtn-txt">章节速览</span><span class="tbtn-en">CHAPTERS</span>';
        tChap.onclick = function () { openChaptersModal(); };
        titleMenu.insertBefore(tChap, anchor);
      }
    }
  }

  function bindHotkeys() {
    if (typeof document === 'undefined' || root.__vnUxKeyBound) return;
    root.__vnUxKeyBound = true;
    document.addEventListener('keydown', function (e) {
      var tgt = e.target;
      var tag = tgt && tgt.tagName ? tgt.tagName.toUpperCase() : '';
      if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT' || (tgt && tgt.isContentEditable)) return;

      var bm = document.getElementById('vn-backlog-modal');
      var sm = document.getElementById('vn-saveload-modal');
      var cm = document.getElementById('vn-chapters-modal');
      var rm = document.getElementById('rumor-overlay');

      if (e.key === 'Escape') {
        if (bm && !bm.classList.contains('hidden')) { closeBacklogModal(); return; }
        if (sm && !sm.classList.contains('hidden')) { closeSaveLoadModal(); return; }
        if (cm && !cm.classList.contains('hidden')) { closeChaptersModal(); return; }
        if (rm && !rm.classList.contains('hidden')) { rm.classList.add('hidden'); return; }
        return;
      }

      var ai = document.getElementById('ai-drawer');
      if (ai && !ai.classList.contains('hidden')) return;
      var bs = document.getElementById('battle-screen');
      if (bs && !bs.classList.contains('hidden')) return;

      if (e.key === 'l' || e.key === 'L') {
        var gs = document.getElementById('game-screen');
        if (gs && !gs.classList.contains('hidden')) {
          e.preventDefault();
          toggleBacklogModal();
        }
      }
    });
  }

  function init() {
    ensureVNUIButtons();
    bindHotkeys();
  }

  var API = {
    MAX_BACKLOG: MAX_BACKLOG,
    FEATURED_QUICK_JUMPS: FEATURED_QUICK_JUMPS,
    init: init,
    recordLine: recordLine,
    recordChoice: recordChoice,
    clearBacklog: clearBacklog,
    getBacklog: getBacklog,
    setBacklog: setBacklog,
    openBacklogModal: openBacklogModal,
    closeBacklogModal: closeBacklogModal,
    toggleBacklogModal: toggleBacklogModal,
    onAutoSave: onAutoSave,
    saveToSlot: saveToSlot,
    loadFromSlot: loadFromSlot,
    deleteSlot: deleteSlot,
    getSlotList: getSlotList,
    openSaveLoadModal: openSaveLoadModal,
    closeSaveLoadModal: closeSaveLoadModal,
    markChapterUnlocked: markChapterUnlocked,
    loadUnlockedChapters: loadUnlockedChapters,
    prepareChapterState: prepareChapterState,
    jumpToChapter: jumpToChapter,
    openChaptersModal: openChaptersModal,
    closeChaptersModal: closeChaptersModal,
    onSceneStart: markChapterUnlocked
  };

  root.VNUx = API;
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = API;
  }

  if (typeof document !== 'undefined') {
    init();
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', init);
    }
  }
})(typeof globalThis !== 'undefined' ? globalThis : (typeof window !== 'undefined' ? window : this));
